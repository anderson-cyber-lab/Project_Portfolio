-- MySQL dump 10.13  Distrib 8.0.39, for Linux (x86_64)
--
-- Host: localhost    Database: itop_db
-- ------------------------------------------------------
-- Server version	8.0.39-0ubuntu0.24.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `applicationsolution`
--

DROP TABLE IF EXISTS `applicationsolution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `applicationsolution` (
  `id` int NOT NULL AUTO_INCREMENT,
  `status` enum('active','inactive') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `redundancy` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'disabled',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `applicationsolution`
--

LOCK TABLES `applicationsolution` WRITE;
/*!40000 ALTER TABLE `applicationsolution` DISABLE KEYS */;
/*!40000 ALTER TABLE `applicationsolution` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `asnumber`
--

DROP TABLE IF EXISTS `asnumber`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `asnumber` (
  `id` int NOT NULL AUTO_INCREMENT,
  `number` decimal(10,0) DEFAULT NULL,
  `registrar_id` int DEFAULT '0',
  `whois` varchar(2048) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `validity_end` date DEFAULT NULL,
  `renewal_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `registrar_id` (`registrar_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `asnumber`
--

LOCK TABLES `asnumber` WRITE;
/*!40000 ALTER TABLE `asnumber` DISABLE KEYS */;
/*!40000 ALTER TABLE `asnumber` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attachment`
--

DROP TABLE IF EXISTS `attachment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `attachment` (
  `id` int NOT NULL AUTO_INCREMENT,
  `expire` datetime DEFAULT NULL,
  `temp_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `item_class` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `item_id` int DEFAULT '0',
  `item_org_id` int DEFAULT '0',
  `contents_data` longblob,
  `contents_mimetype` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contents_filename` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contents_downloads_count` int unsigned DEFAULT NULL,
  `creation_date` datetime DEFAULT NULL,
  `user_id` int DEFAULT '0',
  `contact_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `temp_id` (`temp_id`(95)),
  KEY `item_class` (`item_class`(95)),
  KEY `user_id` (`user_id`),
  KEY `contact_id` (`contact_id`),
  KEY `item_class_item_id` (`item_class`(95),`item_id`),
  KEY `item_org_id` (`item_org_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attachment`
--

LOCK TABLES `attachment` WRITE;
/*!40000 ALTER TABLE `attachment` DISABLE KEYS */;
/*!40000 ALTER TABLE `attachment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `brand`
--

DROP TABLE IF EXISTS `brand`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `brand` (
  `id` int NOT NULL AUTO_INCREMENT,
  `logo_data` longblob,
  `logo_mimetype` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo_filename` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo_downloads_count` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `brand`
--

LOCK TABLES `brand` WRITE;
/*!40000 ALTER TABLE `brand` DISABLE KEYS */;
INSERT INTO `brand` VALUES (7,'','','',0),(8,'','','',0),(9,'','','',0),(10,'','','',0),(11,'','','',0),(12,'','','',0),(13,'','','',0),(14,'','','',0),(15,'','','',0),(16,'','','',0),(17,'','','',0),(18,'','','',0),(19,'','','',0);
/*!40000 ALTER TABLE `brand` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `businessprocess`
--

DROP TABLE IF EXISTS `businessprocess`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `businessprocess` (
  `id` int NOT NULL AUTO_INCREMENT,
  `status` enum('active','inactive') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `businessprocess`
--

LOCK TABLES `businessprocess` WRITE;
/*!40000 ALTER TABLE `businessprocess` DISABLE KEYS */;
/*!40000 ALTER TABLE `businessprocess` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `connectableci`
--

DROP TABLE IF EXISTS `connectableci`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `connectableci` (
  `id` int NOT NULL AUTO_INCREMENT,
  `finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'ConnectableCI',
  PRIMARY KEY (`id`),
  KEY `finalclass` (`finalclass`(95))
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `connectableci`
--

LOCK TABLES `connectableci` WRITE;
/*!40000 ALTER TABLE `connectableci` DISABLE KEYS */;
INSERT INTO `connectableci` VALUES (1,'NetworkDevice'),(2,'NetworkDevice'),(3,'Server'),(5,'PC'),(6,'PC'),(7,'PC'),(8,'PC'),(9,'PC'),(10,'PC'),(11,'PC'),(12,'PC'),(13,'PC'),(14,'PC'),(15,'PC'),(16,'PC'),(17,'NetworkDevice'),(18,'NetworkDevice'),(19,'Server'),(20,'Server'),(21,'Server'),(22,'PC'),(23,'NetworkDevice');
/*!40000 ALTER TABLE `connectableci` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contact`
--

DROP TABLE IF EXISTS `contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contact` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `status` enum('active','inactive') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `org_id` int DEFAULT '0',
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `notify` enum('no','yes') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'yes',
  `function` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Contact',
  `obsolescence_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95)),
  KEY `org_id` (`org_id`),
  KEY `finalclass` (`finalclass`(95))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact`
--

LOCK TABLES `contact` WRITE;
/*!40000 ALTER TABLE `contact` DISABLE KEYS */;
INSERT INTO `contact` VALUES (1,'Admin Account','active',1,'my.email@foo.org','','yes','','Person',NULL);
/*!40000 ALTER TABLE `contact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contacttype`
--

DROP TABLE IF EXISTS `contacttype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contacttype` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contacttype`
--

LOCK TABLES `contacttype` WRITE;
/*!40000 ALTER TABLE `contacttype` DISABLE KEYS */;
/*!40000 ALTER TABLE `contacttype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contract`
--

DROP TABLE IF EXISTS `contract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contract` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `org_id` int DEFAULT '0',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `cost` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `cost_currency` enum('dollars','euros') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contracttype_id` int DEFAULT '0',
  `billing_frequency` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `cost_unit` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `provider_id` int DEFAULT '0',
  `status` enum('implementation','production','obsolete') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Contract',
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95)),
  KEY `org_id` (`org_id`),
  KEY `contracttype_id` (`contracttype_id`),
  KEY `provider_id` (`provider_id`),
  KEY `finalclass` (`finalclass`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contract`
--

LOCK TABLES `contract` WRITE;
/*!40000 ALTER TABLE `contract` DISABLE KEYS */;
/*!40000 ALTER TABLE `contract` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contracttype`
--

DROP TABLE IF EXISTS `contracttype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contracttype` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contracttype`
--

LOCK TABLES `contracttype` WRITE;
/*!40000 ALTER TABLE `contracttype` DISABLE KEYS */;
/*!40000 ALTER TABLE `contracttype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customercontract`
--

DROP TABLE IF EXISTS `customercontract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customercontract` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customercontract`
--

LOCK TABLES `customercontract` WRITE;
/*!40000 ALTER TABLE `customercontract` DISABLE KEYS */;
/*!40000 ALTER TABLE `customercontract` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `databaseschema`
--

DROP TABLE IF EXISTS `databaseschema`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `databaseschema` (
  `id` int NOT NULL AUTO_INCREMENT,
  `dbserver_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `dbserver_id` (`dbserver_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `databaseschema`
--

LOCK TABLES `databaseschema` WRITE;
/*!40000 ALTER TABLE `databaseschema` DISABLE KEYS */;
/*!40000 ALTER TABLE `databaseschema` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datacenterdevice`
--

DROP TABLE IF EXISTS `datacenterdevice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `datacenterdevice` (
  `id` int NOT NULL AUTO_INCREMENT,
  `rack_id` int DEFAULT '0',
  `enclosure_id` int DEFAULT '0',
  `nb_u` int DEFAULT NULL,
  `managementip` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `powera_id` int DEFAULT '0',
  `powerB_id` int DEFAULT '0',
  `redundancy` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '1',
  `finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'DatacenterDevice',
  `managementip_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `rack_id` (`rack_id`),
  KEY `enclosure_id` (`enclosure_id`),
  KEY `powera_id` (`powera_id`),
  KEY `powerB_id` (`powerB_id`),
  KEY `finalclass` (`finalclass`(95)),
  KEY `managementip_id` (`managementip_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datacenterdevice`
--

LOCK TABLES `datacenterdevice` WRITE;
/*!40000 ALTER TABLE `datacenterdevice` DISABLE KEYS */;
INSERT INTO `datacenterdevice` VALUES (1,0,0,NULL,'',0,0,'1','NetworkDevice',0),(2,0,0,NULL,'',0,0,'1','NetworkDevice',0),(3,0,0,NULL,'',0,0,'1','Server',0),(17,0,0,NULL,'',0,0,'1','NetworkDevice',0),(18,0,0,NULL,'',0,0,'1','NetworkDevice',0),(19,0,0,NULL,'',0,0,'1','Server',39),(20,0,0,NULL,'',0,0,'1','Server',40),(21,0,0,NULL,'',0,0,'1','Server',41),(23,0,0,NULL,'',0,0,'1','NetworkDevice',78);
/*!40000 ALTER TABLE `datacenterdevice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbserver`
--

DROP TABLE IF EXISTS `dbserver`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dbserver` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbserver`
--

LOCK TABLES `dbserver` WRITE;
/*!40000 ALTER TABLE `dbserver` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbserver` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deliverymodel`
--

DROP TABLE IF EXISTS `deliverymodel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deliverymodel` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `org_id` int DEFAULT '0',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95)),
  KEY `org_id` (`org_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deliverymodel`
--

LOCK TABLES `deliverymodel` WRITE;
/*!40000 ALTER TABLE `deliverymodel` DISABLE KEYS */;
/*!40000 ALTER TABLE `deliverymodel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dnsobject`
--

DROP TABLE IF EXISTS `dnsobject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dnsobject` (
  `id` int NOT NULL AUTO_INCREMENT,
  `org_id` int DEFAULT '0',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `comment` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'DNSObject',
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`),
  KEY `name` (`name`(95)),
  KEY `finalclass` (`finalclass`(95))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dnsobject`
--

LOCK TABLES `dnsobject` WRITE;
/*!40000 ALTER TABLE `dnsobject` DISABLE KEYS */;
INSERT INTO `dnsobject` VALUES (1,1,'megaquagga.local.','Domain Controller','Domain');
/*!40000 ALTER TABLE `dnsobject` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document`
--

DROP TABLE IF EXISTS `document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `document` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `org_id` int DEFAULT '0',
  `documenttype_id` int DEFAULT '0',
  `version` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `status` enum('draft','published','obsolete') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Document',
  `obsolescence_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`),
  KEY `documenttype_id` (`documenttype_id`),
  KEY `finalclass` (`finalclass`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document`
--

LOCK TABLES `document` WRITE;
/*!40000 ALTER TABLE `document` DISABLE KEYS */;
/*!40000 ALTER TABLE `document` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documentfile`
--

DROP TABLE IF EXISTS `documentfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `documentfile` (
  `id` int NOT NULL AUTO_INCREMENT,
  `file_data` longblob,
  `file_mimetype` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_filename` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_downloads_count` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documentfile`
--

LOCK TABLES `documentfile` WRITE;
/*!40000 ALTER TABLE `documentfile` DISABLE KEYS */;
/*!40000 ALTER TABLE `documentfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documentnote`
--

DROP TABLE IF EXISTS `documentnote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `documentnote` (
  `id` int NOT NULL AUTO_INCREMENT,
  `text` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documentnote`
--

LOCK TABLES `documentnote` WRITE;
/*!40000 ALTER TABLE `documentnote` DISABLE KEYS */;
/*!40000 ALTER TABLE `documentnote` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documenttype`
--

DROP TABLE IF EXISTS `documenttype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `documenttype` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documenttype`
--

LOCK TABLES `documenttype` WRITE;
/*!40000 ALTER TABLE `documenttype` DISABLE KEYS */;
/*!40000 ALTER TABLE `documenttype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documentweb`
--

DROP TABLE IF EXISTS `documentweb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `documentweb` (
  `id` int NOT NULL AUTO_INCREMENT,
  `url` varchar(2048) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documentweb`
--

LOCK TABLES `documentweb` WRITE;
/*!40000 ALTER TABLE `documentweb` DISABLE KEYS */;
/*!40000 ALTER TABLE `documentweb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `domain`
--

DROP TABLE IF EXISTS `domain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `domain` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parent_org_id` int DEFAULT '0',
  `parent_id` int DEFAULT '0',
  `parent_id_left` int DEFAULT '0',
  `parent_id_right` int DEFAULT '0',
  `requestor_id` int DEFAULT '0',
  `release_date` datetime DEFAULT NULL,
  `registrar_id` int DEFAULT '0',
  `validity_start` date DEFAULT NULL,
  `validity_end` date DEFAULT NULL,
  `renewal` enum('automatic','manual','na') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'na',
  PRIMARY KEY (`id`),
  KEY `parent_org_id` (`parent_org_id`),
  KEY `parent_id` (`parent_id`),
  KEY `parent_id_left` (`parent_id_left`),
  KEY `parent_id_right` (`parent_id_right`),
  KEY `requestor_id` (`requestor_id`),
  KEY `registrar_id` (`registrar_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `domain`
--

LOCK TABLES `domain` WRITE;
/*!40000 ALTER TABLE `domain` DISABLE KEYS */;
INSERT INTO `domain` VALUES (1,0,0,1,2,0,NULL,0,NULL,NULL,'na');
/*!40000 ALTER TABLE `domain` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `enclosure`
--

DROP TABLE IF EXISTS `enclosure`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `enclosure` (
  `id` int NOT NULL AUTO_INCREMENT,
  `rack_id` int DEFAULT '0',
  `nb_u` int DEFAULT NULL,
  `macaddress` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `ipaddress_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `rack_id` (`rack_id`),
  KEY `ipaddress_id` (`ipaddress_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enclosure`
--

LOCK TABLES `enclosure` WRITE;
/*!40000 ALTER TABLE `enclosure` DISABLE KEYS */;
/*!40000 ALTER TABLE `enclosure` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `farm`
--

DROP TABLE IF EXISTS `farm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `farm` (
  `id` int NOT NULL AUTO_INCREMENT,
  `redundancy` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `farm`
--

LOCK TABLES `farm` WRITE;
/*!40000 ALTER TABLE `farm` DISABLE KEYS */;
/*!40000 ALTER TABLE `farm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fiberchannelinterface`
--

DROP TABLE IF EXISTS `fiberchannelinterface`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fiberchannelinterface` (
  `id` int NOT NULL AUTO_INCREMENT,
  `speed` decimal(6,2) DEFAULT NULL,
  `topology` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `wwn` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `datacenterdevice_id` int DEFAULT '0',
  `status` enum('active','inactive') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  PRIMARY KEY (`id`),
  KEY `datacenterdevice_id` (`datacenterdevice_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fiberchannelinterface`
--

LOCK TABLES `fiberchannelinterface` WRITE;
/*!40000 ALTER TABLE `fiberchannelinterface` DISABLE KEYS */;
/*!40000 ALTER TABLE `fiberchannelinterface` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `functionalci`
--

DROP TABLE IF EXISTS `functionalci`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `functionalci` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `org_id` int DEFAULT '0',
  `business_criticity` enum('high','medium','low') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'low',
  `move2production` date DEFAULT NULL,
  `finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'FunctionalCI',
  `obsolescence_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95)),
  KEY `org_id` (`org_id`),
  KEY `finalclass` (`finalclass`(95))
) ENGINE=InnoDB AUTO_INCREMENT=110 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `functionalci`
--

LOCK TABLES `functionalci` WRITE;
/*!40000 ALTER TABLE `functionalci` DISABLE KEYS */;
INSERT INTO `functionalci` VALUES (1,'vyos-sw-dmz','',1,'high',NULL,'NetworkDevice',NULL),(2,'vyos-sw-lan','',1,'high',NULL,'NetworkDevice',NULL),(3,'mysql-web-server','',1,'medium',NULL,'Server',NULL),(4,'Apache Web Server','',1,'medium',NULL,'WebServer',NULL),(5,'student-host-windows.megaquagga.local','',1,'low',NULL,'PC',NULL),(6,'kali.megaquagga.local','',1,'low',NULL,'PC',NULL),(7,'financeteamashia.megaquagga.local','',1,'low',NULL,'PC',NULL),(8,'benitadesk.megaquagga.local','',1,'low',NULL,'PC',NULL),(9,'patpris-pc.megaquagga.local','',1,'low',NULL,'PC',NULL),(10,'adrian-laptop.megaquagga.local','',1,'low',NULL,'PC',NULL),(11,'shielcatiedesktop.megaquagga.local','',1,'low',NULL,'PC',NULL),(12,'julia_workstation.megaquagga.local','',1,'low',NULL,'PC',NULL),(13,'kipwinstation.megaquagga.local','',1,'low',NULL,'PC',NULL),(14,'susyit.megaquagga.local','',1,'low',NULL,'PC',NULL),(15,'clovisfromit.megaquagga.local','',1,'low',NULL,'PC',NULL),(16,'brookcomputer.megaquagga.local','',1,'low',NULL,'PC',NULL),(17,'internal_fw','',1,'high',NULL,'NetworkDevice',NULL),(18,'external.fw','',1,'high',NULL,'NetworkDevice',NULL),(19,'ad01.megaquagga.local','',1,'low',NULL,'Server',NULL),(20,'observer.megaquagga.local','',1,'low',NULL,'Server',NULL),(21,'wazuh-siem.megaquagga.local','',1,'low',NULL,'Server',NULL),(22,'USERENDPOINT.megaquagga.local','',1,'low',NULL,'PC',NULL),(23,'cloudshare','',1,'high',NULL,'NetworkDevice',NULL),(24,'Apache (Web Server)','',1,'low',NULL,'WebServer',NULL),(25,'domain','',1,'low',NULL,'Middleware',NULL),(26,'kerberos-sec','',1,'low',NULL,'Middleware',NULL),(27,'msrpc','',1,'low',NULL,'Middleware',NULL),(28,'netbios-ssn','',1,'low',NULL,'Middleware',NULL),(29,'LDAP','',1,'low',NULL,'Middleware',NULL),(30,'microsoft-ds','',1,'low',NULL,'Middleware',NULL),(31,'ssl/http','',1,'low',NULL,'WebServer',NULL),(32,'Apache httpd 2.4.58 (Web Server)','',1,'low',NULL,'WebServer',NULL),(33,'Microsoft IIS (Web Server)','',1,'low',NULL,'WebServer',NULL),(34,'kpasswd5','',1,'low',NULL,'Middleware',NULL),(35,'ncacn_http','',1,'low',NULL,'Middleware',NULL),(36,'ms-wbt-server','',1,'low',NULL,'Middleware',NULL),(37,'wsdapi','',1,'low',NULL,'Middleware',NULL),(38,'ssh','',1,'low',NULL,'Middleware',NULL),(39,'LDAP','',1,'low',NULL,'Middleware',NULL),(40,'CUPS 2.4','',1,'low',NULL,'Middleware',NULL),(41,'Golang (Web Server)','',1,'low',NULL,'WebServer',NULL),(42,'ssh','',1,'low',NULL,'Middleware',NULL),(43,'msrpc','',1,'low',NULL,'Middleware',NULL),(44,'netbios-ssn','',1,'low',NULL,'Middleware',NULL),(45,'microsoft-ds','',1,'low',NULL,'Middleware',NULL),(46,'ms-wbt-server','',1,'low',NULL,'Middleware',NULL),(47,'msrpc','',1,'low',NULL,'Middleware',NULL),(48,'netbios-ssn','',1,'low',NULL,'Middleware',NULL),(49,'microsoft-ds','',1,'low',NULL,'Middleware',NULL),(50,'ms-wbt-server','',1,'low',NULL,'Middleware',NULL),(51,'msrpc','',1,'low',NULL,'Middleware',NULL),(52,'netbios-ssn','',1,'low',NULL,'Middleware',NULL),(53,'microsoft-ds','',1,'low',NULL,'Middleware',NULL),(54,'VNC','',1,'low',NULL,'Middleware',NULL),(55,'ms-wbt-server','',1,'low',NULL,'Middleware',NULL),(56,'VNC','',1,'low',NULL,'Middleware',NULL),(57,'msrpc','',1,'low',NULL,'Middleware',NULL),(58,'netbios-ssn','',1,'low',NULL,'Middleware',NULL),(59,'microsoft-ds','',1,'low',NULL,'Middleware',NULL),(60,'microsoft-ds','',1,'low',NULL,'Middleware',NULL),(61,'VNC','',1,'low',NULL,'Middleware',NULL),(62,'msrpc','',1,'low',NULL,'Middleware',NULL),(63,'netbios-ssn','',1,'low',NULL,'Middleware',NULL),(64,'microsoft-ds','',1,'low',NULL,'Middleware',NULL),(65,'ms-wbt-server','',1,'low',NULL,'Middleware',NULL),(66,'VNC','',1,'low',NULL,'Middleware',NULL),(67,'msrpc','',1,'low',NULL,'Middleware',NULL),(68,'netbios-ssn','',1,'low',NULL,'Middleware',NULL),(69,'microsoft-ds','',1,'low',NULL,'Middleware',NULL),(70,'ms-wbt-server','',1,'low',NULL,'Middleware',NULL),(71,'VNC','',1,'low',NULL,'Middleware',NULL),(72,'msrpc','',1,'low',NULL,'Middleware',NULL),(73,'netbios-ssn','',1,'low',NULL,'Middleware',NULL),(74,'microsoft-ds','',1,'low',NULL,'Middleware',NULL),(75,'ms-wbt-server','',1,'low',NULL,'Middleware',NULL),(76,'VNC','',1,'low',NULL,'Middleware',NULL),(77,'ssh','',1,'low',NULL,'Middleware',NULL),(78,'ms-wbt-server','',1,'low',NULL,'Middleware',NULL),(79,'msrpc','',1,'low',NULL,'Middleware',NULL),(80,'netbios-ssn','',1,'low',NULL,'Middleware',NULL),(81,'microsoft-ds','',1,'low',NULL,'Middleware',NULL),(82,'ms-wbt-server','',1,'low',NULL,'Middleware',NULL),(83,'VNC','',1,'low',NULL,'Middleware',NULL),(84,'msrpc','',1,'low',NULL,'Middleware',NULL),(85,'netbios-ssn','',1,'low',NULL,'Middleware',NULL),(86,'microsoft-ds','',1,'low',NULL,'Middleware',NULL),(87,'ms-wbt-server','',1,'low',NULL,'Middleware',NULL),(88,'VNC','',1,'low',NULL,'Middleware',NULL),(89,'msrpc','',1,'low',NULL,'Middleware',NULL),(90,'netbios-ssn','',1,'low',NULL,'Middleware',NULL),(91,'microsoft-ds','',1,'low',NULL,'Middleware',NULL),(92,'ms-wbt-server','',1,'low',NULL,'Middleware',NULL),(93,'VNC','',1,'low',NULL,'Middleware',NULL),(94,'msrpc','',1,'low',NULL,'Middleware',NULL),(95,'netbios-ssn','',1,'low',NULL,'Middleware',NULL),(96,'microsoft-ds','',1,'low',NULL,'Middleware',NULL),(97,'ms-wbt-server','',1,'low',NULL,'Middleware',NULL),(98,'msrpc','',1,'low',NULL,'Middleware',NULL),(99,'netbios-ssn','',1,'low',NULL,'Middleware',NULL),(100,'ms-wbt-server','',1,'low',NULL,'Middleware',NULL),(101,'microsoft-ds','',1,'low',NULL,'Middleware',NULL),(102,'VNC','',1,'low',NULL,'Middleware',NULL),(103,'Itop','',1,'high',NULL,'WebApplication',NULL),(104,'Zabbix','',1,'high',NULL,'WebApplication',NULL),(105,'Nagios XI','',1,'high',NULL,'WebApplication',NULL),(106,'Prometheus','',1,'high',NULL,'WebApplication',NULL),(107,'Icinga Web 2','',1,'high',NULL,'WebApplication',NULL),(108,'Grafana','',1,'high',NULL,'WebApplication',NULL),(109,'Wazuh SIEM','',1,'high',NULL,'WebApplication',NULL);
/*!40000 ALTER TABLE `functionalci` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group`
--

DROP TABLE IF EXISTS `group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `group` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `status` enum('implementation','production','obsolete') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'implementation',
  `org_id` int DEFAULT '0',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `parent_id` int DEFAULT '0',
  `parent_id_left` int DEFAULT '0',
  `parent_id_right` int DEFAULT '0',
  `obsolescence_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95)),
  KEY `org_id` (`org_id`),
  KEY `parent_id` (`parent_id`),
  KEY `parent_id_left` (`parent_id_left`),
  KEY `parent_id_right` (`parent_id_right`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group`
--

LOCK TABLES `group` WRITE;
/*!40000 ALTER TABLE `group` DISABLE KEYS */;
/*!40000 ALTER TABLE `group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hypervisor`
--

DROP TABLE IF EXISTS `hypervisor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hypervisor` (
  `id` int NOT NULL AUTO_INCREMENT,
  `farm_id` int DEFAULT '0',
  `server_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `farm_id` (`farm_id`),
  KEY `server_id` (`server_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hypervisor`
--

LOCK TABLES `hypervisor` WRITE;
/*!40000 ALTER TABLE `hypervisor` DISABLE KEYS */;
/*!40000 ALTER TABLE `hypervisor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inline_image`
--

DROP TABLE IF EXISTS `inline_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inline_image` (
  `id` int NOT NULL AUTO_INCREMENT,
  `expire` datetime DEFAULT NULL,
  `temp_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `item_class` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `item_id` int DEFAULT '0',
  `item_org_id` int DEFAULT '0',
  `contents_data` longblob,
  `contents_mimetype` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contents_filename` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contents_downloads_count` int unsigned DEFAULT NULL,
  `secret` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `temp_id` (`temp_id`(95)),
  KEY `item_class` (`item_class`(95)),
  KEY `item_class_item_id` (`item_class`(95),`item_id`),
  KEY `item_org_id` (`item_org_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inline_image`
--

LOCK TABLES `inline_image` WRITE;
/*!40000 ALTER TABLE `inline_image` DISABLE KEYS */;
/*!40000 ALTER TABLE `inline_image` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `iosversion`
--

DROP TABLE IF EXISTS `iosversion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `iosversion` (
  `id` int NOT NULL AUTO_INCREMENT,
  `brand_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `brand_id` (`brand_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `iosversion`
--

LOCK TABLES `iosversion` WRITE;
/*!40000 ALTER TABLE `iosversion` DISABLE KEYS */;
/*!40000 ALTER TABLE `iosversion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipaddress`
--

DROP TABLE IF EXISTS `ipaddress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ipaddress` (
  `id` int NOT NULL AUTO_INCREMENT,
  `short_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `domain_id` int DEFAULT '0',
  `fqdn` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `aliases` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `usage_id` int DEFAULT '0',
  `ip_allow_duplicate_name` enum('default','ipdup_dualstack','ipdup_no','ipdup_yes') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'default',
  `ping_before_assign` enum('default','ping_no','ping_yes') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'default',
  `finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'IPAddress',
  PRIMARY KEY (`id`),
  KEY `domain_id` (`domain_id`),
  KEY `usage_id` (`usage_id`),
  KEY `finalclass` (`finalclass`(95))
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipaddress`
--

LOCK TABLES `ipaddress` WRITE;
/*!40000 ALTER TABLE `ipaddress` DISABLE KEYS */;
INSERT INTO `ipaddress` VALUES (33,'student-host-windows',1,'student-host-windows.megaquagga.local.','',43,'default','default','IPv4Address'),(34,'vyos-sw-lan',1,'vyos-sw-lan.megaquagga.local.','10.171.0.254\r\n10.172.0.254\r\n10.173.0.254\r\n192.168.11.254',44,'default','default','IPv4Address'),(35,'kali',1,'kali.megaquagga.local.','',43,'default','default','IPv4Address'),(38,'USERENDPOINT',1,'USERENDPOINT.megaquagga.local.','10.172.0.2\r\n10.173.0.2',43,'default','default','IPv4Address'),(39,'AD01',1,'AD01.megaquagga.local.','',43,'default','default','IPv4Address'),(40,'observer',1,'observer.megaquagga.local.','',43,'default','default','IPv4Address'),(41,'wazuh_siem',1,'wazuh_siem.megaquagga.local.','',43,'default','default','IPv4Address'),(42,'vyos-sw-dmz',1,'vyos-sw-dmz.megaquagga.local.','172.16.20.254\r\n172.16.21.254',44,'default','default','IPv4Address'),(44,'financeteamashia',1,'financeteamashia.megaquagga.local.','',43,'default','default','IPv4Address'),(45,'benitadesk',1,'benitadesk.megaquagga.local.','',43,'default','default','IPv4Address'),(48,'patpris-pc',1,'patpris-pc.megaquagga.local.','',0,'default','default','IPv4Address'),(49,'adrian-laptop',1,'adrian-laptop.megaquagga.local.','',43,'default','default','IPv4Address'),(50,'shielcatiedesktop',1,'shielcatiedesktop.megaquagga.local.','',43,'default','default','IPv4Address'),(51,'julia_workstation',1,'julia_workstation.megaquagga.local.','',43,'default','default','IPv4Address'),(53,'kipwinstation',1,'kipwinstation.megaquagga.local.','',43,'default','default','IPv4Address'),(55,'susyit',1,'susyit.megaquagga.local.','',43,'default','default','IPv4Address'),(56,'clovisfromit',1,'clovisfromit.megaquagga.local.','',43,'default','default','IPv4Address'),(57,'brookcomputer',1,'brookcomputer.megaquagga.local.','',43,'default','default','IPv4Address'),(60,'internal-fw',1,'internal-fw.megaquagga.local.','',44,'default','default','IPv4Address'),(69,'external-fw192-168-100',1,'external-fw192-168-100.megaquagga.local.','172.16.20.200\r\n172.16.21.200',44,'default','default','IPv4Address'),(70,'',0,'','',0,'default','default','IPv4Address'),(71,'',0,'','',0,'default','default','IPv4Address'),(72,'',0,'','',0,'default','default','IPv4Address'),(73,'',0,'','',0,'default','default','IPv4Address'),(74,'',0,'','',0,'default','default','IPv4Address'),(75,'',0,'','',0,'default','default','IPv4Address'),(76,'',0,'','',0,'default','default','IPv4Address'),(77,'',0,'','',0,'default','default','IPv4Address'),(78,'cloudshare',1,'cloudshare.megaquagga.local.','10.160.0.1\r\n10.170.0.1\r\n10.171.0.1\r\n10.172.0.1\r\n10.173.0.1\r\n172.16.20.1\r\n172.16.21.1\r\n192.168.11.1',45,'default','default','IPv4Address');
/*!40000 ALTER TABLE `ipaddress` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipaddressv4`
--

DROP TABLE IF EXISTS `ipaddressv4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ipaddressv4` (
  `id` int NOT NULL AUTO_INCREMENT,
  `subnet_id` int DEFAULT '0',
  `range_id` int DEFAULT '0',
  `ip` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `subnet_id` (`subnet_id`),
  KEY `range_id` (`range_id`),
  KEY `ip` (`ip`(95))
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipaddressv4`
--

LOCK TABLES `ipaddressv4` WRITE;
/*!40000 ALTER TABLE `ipaddressv4` DISABLE KEYS */;
INSERT INTO `ipaddressv4` VALUES (33,19,0,'10.160.0.100'),(34,19,0,'10.160.0.254'),(35,19,0,'10.160.0.10'),(38,21,0,'10.171.0.2'),(39,17,0,'10.170.0.10'),(40,17,0,'10.170.0.20'),(41,17,0,'10.170.0.99'),(42,17,0,'10.170.0.254'),(44,21,0,'10.171.0.90'),(45,21,0,'10.171.0.91'),(48,23,0,'10.172.0.50'),(49,23,0,'10.172.0.51'),(50,23,0,'10.172.0.53'),(51,23,0,'10.172.0.54'),(53,25,0,'10.173.0.70'),(55,25,0,'10.173.0.71'),(56,25,0,'10.173.0.72'),(57,25,0,'10.173.0.73'),(60,31,0,'192.168.11.200'),(69,15,0,'192.168.100.200'),(70,27,0,'172.16.20.254'),(71,29,0,'172.16.21.254'),(72,31,0,'192.168.11.254'),(73,23,0,'10.172.0.254'),(74,25,0,'10.173.0.254'),(75,21,0,'10.171.0.254'),(76,29,0,'172.16.21.200'),(77,27,0,'172.16.20.200'),(78,15,0,'192.168.100.1');
/*!40000 ALTER TABLE `ipaddressv4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipaddressv6`
--

DROP TABLE IF EXISTS `ipaddressv6`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ipaddressv6` (
  `id` int NOT NULL AUTO_INCREMENT,
  `subnet_id` int DEFAULT '0',
  `range_id` int DEFAULT '0',
  `ip_text` char(39) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip_comp` char(39) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `subnet_id` (`subnet_id`),
  KEY `range_id` (`range_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipaddressv6`
--

LOCK TABLES `ipaddressv6` WRITE;
/*!40000 ALTER TABLE `ipaddressv6` DISABLE KEYS */;
/*!40000 ALTER TABLE `ipaddressv6` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipapplication`
--

DROP TABLE IF EXISTS `ipapplication`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ipapplication` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `status` enum('implementation','obsolete','production') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `location_id` (`location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipapplication`
--

LOCK TABLES `ipapplication` WRITE;
/*!40000 ALTER TABLE `ipapplication` DISABLE KEYS */;
/*!40000 ALTER TABLE `ipapplication` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipblock`
--

DROP TABLE IF EXISTS `ipblock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ipblock` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `ipblocktype_id` int DEFAULT '0',
  `parent_org_id` int DEFAULT '0',
  `write_reason` enum('expand','is_delete','none','parent_is_delete','shrink','split') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'none',
  `occupancy` int DEFAULT '0',
  `children_occupancy` int DEFAULT '0',
  `subnet_occupancy` int DEFAULT '0',
  `origin` enum('lir','other','rir') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'other',
  `registrar_id` int DEFAULT '0',
  `finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'IPBlock',
  PRIMARY KEY (`id`),
  KEY `ipblocktype_id` (`ipblocktype_id`),
  KEY `parent_org_id` (`parent_org_id`),
  KEY `registrar_id` (`registrar_id`),
  KEY `finalclass` (`finalclass`(95))
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipblock`
--

LOCK TABLES `ipblock` WRITE;
/*!40000 ALTER TABLE `ipblock` DISABLE KEYS */;
INSERT INTO `ipblock` VALUES (14,'mgmt',0,0,'none',0,0,0,'other',0,'IPv4Block'),(16,'Server_Network',0,0,'none',0,0,0,'other',0,'IPv4Block'),(18,'0x2ASec_Network',0,0,'none',0,0,0,'other',0,'IPv4Block'),(20,'Financial_Network',0,0,'none',0,0,0,'other',0,'IPv4Block'),(22,'HHRR_network',0,0,'none',0,0,0,'other',0,'IPv4Block'),(24,'IT_network',0,0,'none',0,0,0,'other',0,'IPv4Block'),(26,'DMZ_to_LAN',0,0,'none',0,0,0,'other',0,'IPv4Block'),(28,'DMZ_to_WAN',0,0,'none',0,0,0,'other',0,'IPv4Block'),(30,'LAN_to_DMZ',0,0,'none',0,0,0,'other',0,'IPv4Block');
/*!40000 ALTER TABLE `ipblock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipblocktype`
--

DROP TABLE IF EXISTS `ipblocktype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ipblocktype` (
  `id` int NOT NULL AUTO_INCREMENT,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipblocktype`
--

LOCK TABLES `ipblocktype` WRITE;
/*!40000 ALTER TABLE `ipblocktype` DISABLE KEYS */;
INSERT INTO `ipblocktype` VALUES (46,'');
/*!40000 ALTER TABLE `ipblocktype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipblockv4`
--

DROP TABLE IF EXISTS `ipblockv4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ipblockv4` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parent_id` int DEFAULT '0',
  `parent_id_left` int DEFAULT '0',
  `parent_id_right` int DEFAULT '0',
  `firstip` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `lastip` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `ipv4_block_min_size` int DEFAULT NULL,
  `ipv4_block_cidr_aligned` enum('bca_no','bca_yes','default') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'default',
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`),
  KEY `parent_id_left` (`parent_id_left`),
  KEY `parent_id_right` (`parent_id_right`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipblockv4`
--

LOCK TABLES `ipblockv4` WRITE;
/*!40000 ALTER TABLE `ipblockv4` DISABLE KEYS */;
INSERT INTO `ipblockv4` VALUES (14,0,1,2,'192.168.100.0','192.168.100.255',NULL,'default'),(16,0,3,4,'10.170.0.0','10.170.0.255',NULL,'default'),(18,0,5,6,'10.160.0.0','10.160.0.255',NULL,'default'),(20,0,7,8,'10.171.0.0','10.171.0.255',NULL,'default'),(22,0,9,10,'10.172.0.0','10.172.0.255',NULL,'default'),(24,0,11,12,'10.173.0.0','10.173.0.255',NULL,'default'),(26,0,13,14,'172.16.20.0','172.16.20.255',NULL,'default'),(28,0,15,16,'172.16.21.0','172.16.21.255',NULL,'default'),(30,0,17,18,'192.168.11.0','192.168.11.255',NULL,'default');
/*!40000 ALTER TABLE `ipblockv4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipblockv6`
--

DROP TABLE IF EXISTS `ipblockv6`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ipblockv6` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parent_id` int DEFAULT '0',
  `parent_id_left` int DEFAULT '0',
  `parent_id_right` int DEFAULT '0',
  `firstip_text` char(39) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `firstip_comp` char(39) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastip_text` char(39) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastip_comp` char(39) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ipv6_block_min_prefix` enum('48','49','50','51','52','53','54','55','56','57','58','59','60','61','62','63','64','default') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'default',
  `ipv6_block_cidr_aligned` enum('bca_no','bca_yes','default') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'default',
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`),
  KEY `parent_id_left` (`parent_id_left`),
  KEY `parent_id_right` (`parent_id_right`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipblockv6`
--

LOCK TABLES `ipblockv6` WRITE;
/*!40000 ALTER TABLE `ipblockv6` DISABLE KEYS */;
/*!40000 ALTER TABLE `ipblockv6` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipconfig`
--

DROP TABLE IF EXISTS `ipconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ipconfig` (
  `id` int NOT NULL AUTO_INCREMENT,
  `org_id` int DEFAULT '0',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'IP Settings',
  `requestor_id` int DEFAULT '0',
  `ipv4_block_min_size` int DEFAULT '256',
  `ipv6_block_min_prefix` enum('48','49','50','51','52','53','54','55','56','57','58','59','60','61','62','63','64') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '64',
  `ipv4_block_cidr_aligned` enum('bca_no','bca_yes') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'bca_yes',
  `ipv6_block_cidr_aligned` enum('bca_no','bca_yes') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'bca_yes',
  `delegate_to_children_only` enum('dtc_no','dtc_yes') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'dtc_yes',
  `reserve_subnet_IPs` enum('reserve_no','reserve_yes') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'reserve_no',
  `ipv4_gateway_ip_format` enum('broadcastip_minus_1','free_setup','subnetip_plus_1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'subnetip_plus_1',
  `ipv6_gateway_ip_format` enum('free_setup','lastip','subnetip_plus_1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'subnetip_plus_1',
  `subnet_symetrical_nat` enum('no','yes') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `subnet_low_watermark` int DEFAULT '60',
  `subnet_high_watermark` int DEFAULT '80',
  `iprange_low_watermark` int DEFAULT '60',
  `iprange_high_watermark` int DEFAULT '80',
  `ip_allow_duplicate_name` enum('ipdup_dualstack','ipdup_no','ipdup_yes') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'ipdup_no',
  `ping_before_assign` enum('ping_no','ping_yes') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'ping_no',
  `ip_copy_ci_name_to_shortname` enum('no','yes') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `allow_fqdn_with_empty_shortname` enum('no','yes') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `ip_symetrical_nat` enum('no','yes') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `ip_allocate_on_ci_production` enum('no','yes') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'yes',
  `ip_release_on_ci_obsolete` enum('no','yes') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `ip_unassign_on_no_ci` enum('no','yes') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `ip_release_on_subnet_release` enum('no','yes') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'yes',
  `delegate_domain_to_children_only` enum('dtc_no','dtc_yes') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'dtc_yes',
  `attach_already_allocated_ips` enum('no','yes') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `detach_released_ip_from_cis` enum('no','yes') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'yes',
  `mac_address_format` enum('colons','dots','hyphens') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'colons',
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`),
  KEY `name` (`name`(95)),
  KEY `requestor_id` (`requestor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipconfig`
--

LOCK TABLES `ipconfig` WRITE;
/*!40000 ALTER TABLE `ipconfig` DISABLE KEYS */;
INSERT INTO `ipconfig` VALUES (1,1,'IP Settings',0,250,'64','bca_no','bca_yes','dtc_yes','reserve_no','subnetip_plus_1','subnetip_plus_1','no',60,80,60,80,'ipdup_no','ping_no','no','no','no','yes','no','no','yes','dtc_yes','no','yes','colons');
/*!40000 ALTER TABLE `ipconfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipinterface`
--

DROP TABLE IF EXISTS `ipinterface`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ipinterface` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ipaddress` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `macaddress` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `comment` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `ipgateway` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `ipmask` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `speed` decimal(12,2) DEFAULT NULL,
  `finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'IPInterface',
  PRIMARY KEY (`id`),
  KEY `finalclass` (`finalclass`(95))
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipinterface`
--

LOCK TABLES `ipinterface` WRITE;
/*!40000 ALTER TABLE `ipinterface` DISABLE KEYS */;
INSERT INTO `ipinterface` VALUES (1,'','','','','',NULL,'PhysicalInterface'),(2,'','00:50:56:91:1f:95','','','',NULL,'PhysicalInterface'),(3,'','00:50:56:91:15:07','','','',NULL,'PhysicalInterface'),(4,'','00:50:56:91:92:cf','','','',NULL,'PhysicalInterface'),(5,'','00:50:56:ba:e9:05','','','',NULL,'PhysicalInterface'),(6,'','00:50:56:ba:18:5b','','','',NULL,'PhysicalInterface'),(7,'','00:50:56:ba:9c:4a','','','',NULL,'PhysicalInterface'),(8,'','00:50:56:ba:82:30','','','',NULL,'PhysicalInterface'),(9,'','00:50:56:ba:ba:34','','','',NULL,'PhysicalInterface'),(10,'','00:50:56:9e:dc:64','','','',NULL,'PhysicalInterface'),(11,'','00:50:56:9e:26:ee','','','',NULL,'PhysicalInterface'),(12,'','00:50:56:91:9f:62','','','',NULL,'PhysicalInterface'),(13,'','00:50:56:91:f4:f0','','','',NULL,'PhysicalInterface');
/*!40000 ALTER TABLE `ipinterface` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipobject`
--

DROP TABLE IF EXISTS `ipobject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ipobject` (
  `id` int NOT NULL AUTO_INCREMENT,
  `org_id` int DEFAULT '0',
  `status` enum('reserved','allocated','released','unassigned') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'allocated',
  `comment` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `requestor_id` int DEFAULT '0',
  `allocation_date` datetime DEFAULT NULL,
  `release_date` datetime DEFAULT NULL,
  `ipconfig_id` int DEFAULT '0',
  `finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'IPObject',
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`),
  KEY `requestor_id` (`requestor_id`),
  KEY `ipconfig_id` (`ipconfig_id`),
  KEY `finalclass` (`finalclass`(95))
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipobject`
--

LOCK TABLES `ipobject` WRITE;
/*!40000 ALTER TABLE `ipobject` DISABLE KEYS */;
INSERT INTO `ipobject` VALUES (14,1,'allocated','',0,'2024-12-21 23:29:36',NULL,1,'IPv4Block'),(15,1,'allocated','',0,'2024-12-21 23:30:34',NULL,1,'IPv4Subnet'),(16,1,'allocated','',0,'2024-12-21 23:41:03',NULL,1,'IPv4Block'),(17,1,'allocated','',0,'2024-12-21 23:41:41',NULL,1,'IPv4Subnet'),(18,1,'allocated','',0,'2024-12-21 23:46:14',NULL,1,'IPv4Block'),(19,1,'allocated','',0,'2024-12-21 23:46:28',NULL,1,'IPv4Subnet'),(20,1,'allocated','',0,'2024-12-21 23:47:34',NULL,1,'IPv4Block'),(21,1,'allocated','',0,'2024-12-21 23:47:48',NULL,1,'IPv4Subnet'),(22,1,'allocated','',0,'2024-12-21 23:48:25',NULL,1,'IPv4Block'),(23,1,'allocated','',0,'2024-12-21 23:48:38',NULL,1,'IPv4Subnet'),(24,1,'allocated','',0,'2024-12-21 23:49:32',NULL,1,'IPv4Block'),(25,1,'allocated','',0,'2024-12-21 23:49:51',NULL,1,'IPv4Subnet'),(26,1,'allocated','',0,'2024-12-21 23:51:06',NULL,1,'IPv4Block'),(27,1,'allocated','',0,'2024-12-21 23:51:17',NULL,1,'IPv4Subnet'),(28,1,'allocated','',0,'2024-12-21 23:52:45',NULL,1,'IPv4Block'),(29,1,'allocated','',0,'2024-12-21 23:52:54',NULL,1,'IPv4Subnet'),(30,1,'allocated','',0,'2024-12-21 23:53:31',NULL,1,'IPv4Block'),(31,1,'allocated','',0,'2024-12-21 23:53:39',NULL,1,'IPv4Subnet'),(33,1,'allocated','',0,'2025-01-02 03:54:36',NULL,1,'IPv4Address'),(34,1,'allocated','',0,'2025-01-02 22:19:43',NULL,1,'IPv4Address'),(35,1,'allocated','',0,'2025-01-02 03:57:39',NULL,1,'IPv4Address'),(38,1,'allocated','',0,'2025-01-02 22:53:41',NULL,1,'IPv4Address'),(39,1,'allocated','',0,'2025-01-02 22:42:51',NULL,1,'IPv4Address'),(40,1,'allocated','',0,'2025-01-02 22:45:22',NULL,1,'IPv4Address'),(41,1,'allocated','',0,'2025-01-02 22:46:20',NULL,1,'IPv4Address'),(42,1,'allocated','',0,'2025-01-02 04:52:14',NULL,1,'IPv4Address'),(44,1,'allocated','',0,'2025-01-02 03:59:03',NULL,1,'IPv4Address'),(45,1,'allocated','',0,'2025-01-02 04:00:38',NULL,1,'IPv4Address'),(48,1,'allocated','',0,'2025-01-02 04:01:35',NULL,1,'IPv4Address'),(49,1,'allocated','',0,'2025-01-02 04:02:17',NULL,1,'IPv4Address'),(50,1,'allocated','',0,'2025-01-02 04:02:47',NULL,1,'IPv4Address'),(51,1,'allocated','',0,'2025-01-02 04:03:29',NULL,1,'IPv4Address'),(53,1,'allocated','',0,'2025-01-02 04:04:19',NULL,1,'IPv4Address'),(55,1,'allocated','',0,'2025-01-02 04:05:05',NULL,1,'IPv4Address'),(56,1,'allocated','',0,'2025-01-02 04:05:43',NULL,1,'IPv4Address'),(57,1,'allocated','',0,'2025-01-02 04:08:42',NULL,1,'IPv4Address'),(60,1,'allocated','',0,'2025-01-02 22:34:17',NULL,1,'IPv4Address'),(69,1,'allocated','',0,'2025-01-02 22:30:29',NULL,1,'IPv4Address'),(70,1,'allocated','',0,'2025-01-02 04:55:52',NULL,1,'IPv4Address'),(71,1,'allocated','',0,'2025-01-02 04:57:21',NULL,1,'IPv4Address'),(72,1,'allocated','',0,'2025-01-02 22:18:04',NULL,1,'IPv4Address'),(73,1,'allocated','',0,'2025-01-02 22:21:21',NULL,1,'IPv4Address'),(74,1,'allocated','',0,'2025-01-02 22:22:39',NULL,1,'IPv4Address'),(75,1,'allocated','',0,'2025-01-02 22:23:27',NULL,1,'IPv4Address'),(76,1,'allocated','',0,'2025-01-02 22:31:34',NULL,1,'IPv4Address'),(77,1,'allocated','',0,'2025-01-02 22:32:50',NULL,1,'IPv4Address'),(78,1,'allocated','',0,'2025-01-02 23:46:01',NULL,1,'IPv4Address');
/*!40000 ALTER TABLE `ipobject` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipphone`
--

DROP TABLE IF EXISTS `ipphone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ipphone` (
  `id` int NOT NULL AUTO_INCREMENT,
  `macaddress` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `ipaddress_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `ipaddress_id` (`ipaddress_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipphone`
--

LOCK TABLES `ipphone` WRITE;
/*!40000 ALTER TABLE `ipphone` DISABLE KEYS */;
/*!40000 ALTER TABLE `ipphone` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `iprange`
--

DROP TABLE IF EXISTS `iprange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `iprange` (
  `id` int NOT NULL AUTO_INCREMENT,
  `range` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `usage_id` int DEFAULT '0',
  `dhcp` enum('dhcp_no','dhcp_yes') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'dhcp_no',
  `write_reason` enum('expand','is_delete','none','shrink','split') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'none',
  `occupancy` int DEFAULT '0',
  `alarm_water_mark` enum('high_sent','low_sent','no_alarm') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'no_alarm',
  `finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'IPRange',
  PRIMARY KEY (`id`),
  KEY `usage_id` (`usage_id`),
  KEY `finalclass` (`finalclass`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `iprange`
--

LOCK TABLES `iprange` WRITE;
/*!40000 ALTER TABLE `iprange` DISABLE KEYS */;
/*!40000 ALTER TABLE `iprange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `iprangeusage`
--

DROP TABLE IF EXISTS `iprangeusage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `iprangeusage` (
  `id` int NOT NULL AUTO_INCREMENT,
  `org_id` int DEFAULT '0',
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `iprangeusage`
--

LOCK TABLES `iprangeusage` WRITE;
/*!40000 ALTER TABLE `iprangeusage` DISABLE KEYS */;
/*!40000 ALTER TABLE `iprangeusage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `iprangev4`
--

DROP TABLE IF EXISTS `iprangev4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `iprangev4` (
  `id` int NOT NULL AUTO_INCREMENT,
  `subnet_id` int DEFAULT '0',
  `firstip` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `lastip` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `subnet_id` (`subnet_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `iprangev4`
--

LOCK TABLES `iprangev4` WRITE;
/*!40000 ALTER TABLE `iprangev4` DISABLE KEYS */;
/*!40000 ALTER TABLE `iprangev4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `iprangev6`
--

DROP TABLE IF EXISTS `iprangev6`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `iprangev6` (
  `id` int NOT NULL AUTO_INCREMENT,
  `subnet_id` int DEFAULT '0',
  `firstip_text` char(39) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `firstip_comp` char(39) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastip_text` char(39) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastip_comp` char(39) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `subnet_id` (`subnet_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `iprangev6`
--

LOCK TABLES `iprangev6` WRITE;
/*!40000 ALTER TABLE `iprangev6` DISABLE KEYS */;
/*!40000 ALTER TABLE `iprangev6` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipsubnet`
--

DROP TABLE IF EXISTS `ipsubnet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ipsubnet` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `write_reason` enum('expand','is_delete','none','shrink','split') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'none',
  `ip_occupancy` int DEFAULT '0',
  `range_occupancy` int DEFAULT '0',
  `alarm_water_mark` enum('high_sent','low_sent','no_alarm') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'no_alarm',
  `reserve_subnet_ips` enum('default','reserve_no','reserve_yes') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'default',
  `finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'IPSubnet',
  PRIMARY KEY (`id`),
  KEY `finalclass` (`finalclass`(95))
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipsubnet`
--

LOCK TABLES `ipsubnet` WRITE;
/*!40000 ALTER TABLE `ipsubnet` DISABLE KEYS */;
INSERT INTO `ipsubnet` VALUES (15,'mgmt','','none',0,0,'no_alarm','default','IPv4Subnet'),(17,'Server_Network','','none',0,0,'no_alarm','default','IPv4Subnet'),(19,'0x2ASec_Network','','none',0,0,'no_alarm','default','IPv4Subnet'),(21,'Financial_Network','','none',0,0,'no_alarm','default','IPv4Subnet'),(23,'HHRR_network','','none',0,0,'no_alarm','default','IPv4Subnet'),(25,'IT_network','','none',0,0,'no_alarm','default','IPv4Subnet'),(27,'DMZ_to_LAN','','none',0,0,'no_alarm','default','IPv4Subnet'),(29,'DMZ_to_WAN','','none',0,0,'no_alarm','default','IPv4Subnet'),(31,'LAN_to_DMZ','','none',0,0,'no_alarm','default','IPv4Subnet');
/*!40000 ALTER TABLE `ipsubnet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipsubnetv4`
--

DROP TABLE IF EXISTS `ipsubnetv4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ipsubnetv4` (
  `id` int NOT NULL AUTO_INCREMENT,
  `block_id` int DEFAULT '0',
  `ip` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `mask` enum('255.255.0.0','255.255.128.0','255.255.192.0','255.255.224.0','255.255.240.0','255.255.248.0','255.255.252.0','255.255.254.0','255.255.255.0','255.255.255.128','255.255.255.192','255.255.255.224','255.255.255.240','255.255.255.248','255.255.255.252','255.255.255.254','255.255.255.255') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gatewayip` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `broadcastip` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `ipv4_gateway_ip_format` enum('broadcastip_minus_1','default','free_setup','subnetip_plus_1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'default',
  PRIMARY KEY (`id`),
  KEY `block_id` (`block_id`),
  KEY `ip` (`ip`(95))
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipsubnetv4`
--

LOCK TABLES `ipsubnetv4` WRITE;
/*!40000 ALTER TABLE `ipsubnetv4` DISABLE KEYS */;
INSERT INTO `ipsubnetv4` VALUES (15,14,'192.168.100.0','255.255.255.0','192.168.100.1','192.168.100.255','default'),(17,16,'10.170.0.0','255.255.255.0','10.170.0.1','10.170.0.255','default'),(19,18,'10.160.0.0','255.255.255.0','10.160.0.1','10.160.0.255','default'),(21,20,'10.171.0.0','255.255.255.0','10.171.0.1','10.171.0.255','default'),(23,22,'10.172.0.0','255.255.255.0','10.172.0.1','10.172.0.255','default'),(25,24,'10.173.0.0','255.255.255.0','10.173.0.1','10.173.0.255','default'),(27,26,'172.16.20.0','255.255.255.0','172.16.20.1','172.16.20.255','default'),(29,28,'172.16.21.0','255.255.255.0','172.16.21.1','172.16.21.255','default'),(31,30,'192.168.11.0','255.255.255.0','192.168.11.1','192.168.11.255','default');
/*!40000 ALTER TABLE `ipsubnetv4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipsubnetv6`
--

DROP TABLE IF EXISTS `ipsubnetv6`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ipsubnetv6` (
  `id` int NOT NULL AUTO_INCREMENT,
  `block_id` int DEFAULT '0',
  `ip_text` char(39) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip_comp` char(39) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mask` enum('64','65','66','67','68','69','70','71','72','73','74','75','76','77','78','79','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94','95','96','97','98','99','100','101','102','103','104','105','106','107','108','109','110','111','112','113','114','115','116','117','118','119','120','121','122','123','124','125','126','127','128') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gatewayip_text` char(39) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gatewayip_comp` char(39) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastip_text` char(39) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastip_comp` char(39) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ipv6_gateway_ip_format` enum('default','free_setup','lastip','subnetip_plus_1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'default',
  PRIMARY KEY (`id`),
  KEY `block_id` (`block_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipsubnetv6`
--

LOCK TABLES `ipsubnetv6` WRITE;
/*!40000 ALTER TABLE `ipsubnetv6` DISABLE KEYS */;
/*!40000 ALTER TABLE `ipsubnetv6` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipusage`
--

DROP TABLE IF EXISTS `ipusage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ipusage` (
  `id` int NOT NULL AUTO_INCREMENT,
  `org_id` int DEFAULT '0',
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipusage`
--

LOCK TABLES `ipusage` WRITE;
/*!40000 ALTER TABLE `ipusage` DISABLE KEYS */;
INSERT INTO `ipusage` VALUES (43,1,'Subnet IP'),(44,1,'Gateway IP'),(45,1,'');
/*!40000 ALTER TABLE `ipusage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `key_value_store`
--

DROP TABLE IF EXISTS `key_value_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `key_value_store` (
  `id` int NOT NULL AUTO_INCREMENT,
  `namespace` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `key_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `value` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `key_name` (`key_name`(95)),
  KEY `key_name_namespace` (`key_name`(95),`namespace`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `key_value_store`
--

LOCK TABLES `key_value_store` WRITE;
/*!40000 ALTER TABLE `key_value_store` DISABLE KEYS */;
/*!40000 ALTER TABLE `key_value_store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `licence`
--

DROP TABLE IF EXISTS `licence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `licence` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `org_id` int DEFAULT '0',
  `usage_limit` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `licence_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `perpetual` enum('no','yes') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Licence',
  `obsolescence_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95)),
  KEY `org_id` (`org_id`),
  KEY `finalclass` (`finalclass`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `licence`
--

LOCK TABLES `licence` WRITE;
/*!40000 ALTER TABLE `licence` DISABLE KEYS */;
/*!40000 ALTER TABLE `licence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkapplicationsolutiontobusinessprocess`
--

DROP TABLE IF EXISTS `lnkapplicationsolutiontobusinessprocess`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkapplicationsolutiontobusinessprocess` (
  `id` int NOT NULL AUTO_INCREMENT,
  `businessprocess_id` int DEFAULT '0',
  `applicationsolution_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `businessprocess_id` (`businessprocess_id`),
  KEY `applicationsolution_id` (`applicationsolution_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkapplicationsolutiontobusinessprocess`
--

LOCK TABLES `lnkapplicationsolutiontobusinessprocess` WRITE;
/*!40000 ALTER TABLE `lnkapplicationsolutiontobusinessprocess` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkapplicationsolutiontobusinessprocess` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkapplicationsolutiontofunctionalci`
--

DROP TABLE IF EXISTS `lnkapplicationsolutiontofunctionalci`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkapplicationsolutiontofunctionalci` (
  `id` int NOT NULL AUTO_INCREMENT,
  `applicationsolution_id` int DEFAULT '0',
  `functionalci_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `applicationsolution_id` (`applicationsolution_id`),
  KEY `functionalci_id` (`functionalci_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkapplicationsolutiontofunctionalci`
--

LOCK TABLES `lnkapplicationsolutiontofunctionalci` WRITE;
/*!40000 ALTER TABLE `lnkapplicationsolutiontofunctionalci` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkapplicationsolutiontofunctionalci` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkconnectablecitonetworkdevice`
--

DROP TABLE IF EXISTS `lnkconnectablecitonetworkdevice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkconnectablecitonetworkdevice` (
  `id` int NOT NULL AUTO_INCREMENT,
  `networkdevice_id` int DEFAULT '0',
  `connectableci_id` int DEFAULT '0',
  `network_port` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `device_port` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `type` enum('downlink','uplink') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'downlink',
  PRIMARY KEY (`id`),
  KEY `networkdevice_id` (`networkdevice_id`),
  KEY `connectableci_id` (`connectableci_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkconnectablecitonetworkdevice`
--

LOCK TABLES `lnkconnectablecitonetworkdevice` WRITE;
/*!40000 ALTER TABLE `lnkconnectablecitonetworkdevice` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkconnectablecitonetworkdevice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkcontacttocontract`
--

DROP TABLE IF EXISTS `lnkcontacttocontract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkcontacttocontract` (
  `id` int NOT NULL AUTO_INCREMENT,
  `contract_id` int DEFAULT '0',
  `contact_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `contract_id` (`contract_id`),
  KEY `contact_id` (`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkcontacttocontract`
--

LOCK TABLES `lnkcontacttocontract` WRITE;
/*!40000 ALTER TABLE `lnkcontacttocontract` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkcontacttocontract` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkcontacttofunctionalci`
--

DROP TABLE IF EXISTS `lnkcontacttofunctionalci`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkcontacttofunctionalci` (
  `id` int NOT NULL AUTO_INCREMENT,
  `functionalci_id` int DEFAULT '0',
  `contact_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `functionalci_id` (`functionalci_id`),
  KEY `contact_id` (`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkcontacttofunctionalci`
--

LOCK TABLES `lnkcontacttofunctionalci` WRITE;
/*!40000 ALTER TABLE `lnkcontacttofunctionalci` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkcontacttofunctionalci` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkcontacttoipobject`
--

DROP TABLE IF EXISTS `lnkcontacttoipobject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkcontacttoipobject` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ipobject_id` int DEFAULT '0',
  `contact_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `ipobject_id` (`ipobject_id`),
  KEY `contact_id` (`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkcontacttoipobject`
--

LOCK TABLES `lnkcontacttoipobject` WRITE;
/*!40000 ALTER TABLE `lnkcontacttoipobject` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkcontacttoipobject` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkcontacttoservice`
--

DROP TABLE IF EXISTS `lnkcontacttoservice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkcontacttoservice` (
  `id` int NOT NULL AUTO_INCREMENT,
  `service_id` int DEFAULT '0',
  `contact_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `service_id` (`service_id`),
  KEY `contact_id` (`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkcontacttoservice`
--

LOCK TABLES `lnkcontacttoservice` WRITE;
/*!40000 ALTER TABLE `lnkcontacttoservice` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkcontacttoservice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkcontacttoticket`
--

DROP TABLE IF EXISTS `lnkcontacttoticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkcontacttoticket` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ticket_id` int DEFAULT '0',
  `contact_id` int DEFAULT '0',
  `role` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `impact_code` enum('computed','do_not_notify','manual') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'manual',
  PRIMARY KEY (`id`),
  KEY `ticket_id` (`ticket_id`),
  KEY `contact_id` (`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkcontacttoticket`
--

LOCK TABLES `lnkcontacttoticket` WRITE;
/*!40000 ALTER TABLE `lnkcontacttoticket` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkcontacttoticket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkcontracttodocument`
--

DROP TABLE IF EXISTS `lnkcontracttodocument`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkcontracttodocument` (
  `id` int NOT NULL AUTO_INCREMENT,
  `contract_id` int DEFAULT '0',
  `document_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `contract_id` (`contract_id`),
  KEY `document_id` (`document_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkcontracttodocument`
--

LOCK TABLES `lnkcontracttodocument` WRITE;
/*!40000 ALTER TABLE `lnkcontracttodocument` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkcontracttodocument` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkcustomercontracttoservice`
--

DROP TABLE IF EXISTS `lnkcustomercontracttoservice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkcustomercontracttoservice` (
  `id` int NOT NULL AUTO_INCREMENT,
  `customercontract_id` int DEFAULT '0',
  `service_id` int DEFAULT '0',
  `sla_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `customercontract_id` (`customercontract_id`),
  KEY `service_id` (`service_id`),
  KEY `sla_id` (`sla_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkcustomercontracttoservice`
--

LOCK TABLES `lnkcustomercontracttoservice` WRITE;
/*!40000 ALTER TABLE `lnkcustomercontracttoservice` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkcustomercontracttoservice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkdatacenterdevicetosan`
--

DROP TABLE IF EXISTS `lnkdatacenterdevicetosan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkdatacenterdevicetosan` (
  `id` int NOT NULL AUTO_INCREMENT,
  `san_id` int DEFAULT '0',
  `datacenterdevice_id` int DEFAULT '0',
  `san_port` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `datacenterdevice_port` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `san_id` (`san_id`),
  KEY `datacenterdevice_id` (`datacenterdevice_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkdatacenterdevicetosan`
--

LOCK TABLES `lnkdatacenterdevicetosan` WRITE;
/*!40000 ALTER TABLE `lnkdatacenterdevicetosan` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkdatacenterdevicetosan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkdeliverymodeltocontact`
--

DROP TABLE IF EXISTS `lnkdeliverymodeltocontact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkdeliverymodeltocontact` (
  `id` int NOT NULL AUTO_INCREMENT,
  `deliverymodel_id` int DEFAULT '0',
  `contact_id` int DEFAULT '0',
  `role_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `deliverymodel_id` (`deliverymodel_id`),
  KEY `contact_id` (`contact_id`),
  KEY `role_id` (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkdeliverymodeltocontact`
--

LOCK TABLES `lnkdeliverymodeltocontact` WRITE;
/*!40000 ALTER TABLE `lnkdeliverymodeltocontact` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkdeliverymodeltocontact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkdoctoipobject`
--

DROP TABLE IF EXISTS `lnkdoctoipobject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkdoctoipobject` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ipobject_id` int DEFAULT '0',
  `document_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `ipobject_id` (`ipobject_id`),
  KEY `document_id` (`document_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkdoctoipobject`
--

LOCK TABLES `lnkdoctoipobject` WRITE;
/*!40000 ALTER TABLE `lnkdoctoipobject` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkdoctoipobject` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkdocumenttofunctionalci`
--

DROP TABLE IF EXISTS `lnkdocumenttofunctionalci`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkdocumenttofunctionalci` (
  `id` int NOT NULL AUTO_INCREMENT,
  `functionalci_id` int DEFAULT '0',
  `document_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `functionalci_id` (`functionalci_id`),
  KEY `document_id` (`document_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkdocumenttofunctionalci`
--

LOCK TABLES `lnkdocumenttofunctionalci` WRITE;
/*!40000 ALTER TABLE `lnkdocumenttofunctionalci` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkdocumenttofunctionalci` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkdocumenttolicence`
--

DROP TABLE IF EXISTS `lnkdocumenttolicence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkdocumenttolicence` (
  `id` int NOT NULL AUTO_INCREMENT,
  `licence_id` int DEFAULT '0',
  `document_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `licence_id` (`licence_id`),
  KEY `document_id` (`document_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkdocumenttolicence`
--

LOCK TABLES `lnkdocumenttolicence` WRITE;
/*!40000 ALTER TABLE `lnkdocumenttolicence` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkdocumenttolicence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkdocumenttopatch`
--

DROP TABLE IF EXISTS `lnkdocumenttopatch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkdocumenttopatch` (
  `id` int NOT NULL AUTO_INCREMENT,
  `patch_id` int DEFAULT '0',
  `document_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `patch_id` (`patch_id`),
  KEY `document_id` (`document_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkdocumenttopatch`
--

LOCK TABLES `lnkdocumenttopatch` WRITE;
/*!40000 ALTER TABLE `lnkdocumenttopatch` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkdocumenttopatch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkdocumenttoservice`
--

DROP TABLE IF EXISTS `lnkdocumenttoservice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkdocumenttoservice` (
  `id` int NOT NULL AUTO_INCREMENT,
  `service_id` int DEFAULT '0',
  `document_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `service_id` (`service_id`),
  KEY `document_id` (`document_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkdocumenttoservice`
--

LOCK TABLES `lnkdocumenttoservice` WRITE;
/*!40000 ALTER TABLE `lnkdocumenttoservice` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkdocumenttoservice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkdocumenttosoftware`
--

DROP TABLE IF EXISTS `lnkdocumenttosoftware`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkdocumenttosoftware` (
  `id` int NOT NULL AUTO_INCREMENT,
  `software_id` int DEFAULT '0',
  `document_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `software_id` (`software_id`),
  KEY `document_id` (`document_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkdocumenttosoftware`
--

LOCK TABLES `lnkdocumenttosoftware` WRITE;
/*!40000 ALTER TABLE `lnkdocumenttosoftware` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkdocumenttosoftware` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkfunctionalcitoiprange`
--

DROP TABLE IF EXISTS `lnkfunctionalcitoiprange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkfunctionalcitoiprange` (
  `id` int NOT NULL AUTO_INCREMENT,
  `functionalci_id` int DEFAULT '0',
  `iprange_id` int DEFAULT '0',
  `role` enum('active','primary','secondary','single','split_scope') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'primary',
  PRIMARY KEY (`id`),
  KEY `functionalci_id` (`functionalci_id`),
  KEY `iprange_id` (`iprange_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkfunctionalcitoiprange`
--

LOCK TABLES `lnkfunctionalcitoiprange` WRITE;
/*!40000 ALTER TABLE `lnkfunctionalcitoiprange` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkfunctionalcitoiprange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkfunctionalcitoospatch`
--

DROP TABLE IF EXISTS `lnkfunctionalcitoospatch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkfunctionalcitoospatch` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ospatch_id` int DEFAULT '0',
  `functionalci_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `ospatch_id` (`ospatch_id`),
  KEY `functionalci_id` (`functionalci_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkfunctionalcitoospatch`
--

LOCK TABLES `lnkfunctionalcitoospatch` WRITE;
/*!40000 ALTER TABLE `lnkfunctionalcitoospatch` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkfunctionalcitoospatch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkfunctionalcitoprovidercontract`
--

DROP TABLE IF EXISTS `lnkfunctionalcitoprovidercontract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkfunctionalcitoprovidercontract` (
  `id` int NOT NULL AUTO_INCREMENT,
  `providercontract_id` int DEFAULT '0',
  `functionalci_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `providercontract_id` (`providercontract_id`),
  KEY `functionalci_id` (`functionalci_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkfunctionalcitoprovidercontract`
--

LOCK TABLES `lnkfunctionalcitoprovidercontract` WRITE;
/*!40000 ALTER TABLE `lnkfunctionalcitoprovidercontract` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkfunctionalcitoprovidercontract` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkfunctionalcitoservice`
--

DROP TABLE IF EXISTS `lnkfunctionalcitoservice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkfunctionalcitoservice` (
  `id` int NOT NULL AUTO_INCREMENT,
  `service_id` int DEFAULT '0',
  `functionalci_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `service_id` (`service_id`),
  KEY `functionalci_id` (`functionalci_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkfunctionalcitoservice`
--

LOCK TABLES `lnkfunctionalcitoservice` WRITE;
/*!40000 ALTER TABLE `lnkfunctionalcitoservice` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkfunctionalcitoservice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkfunctionalcitoticket`
--

DROP TABLE IF EXISTS `lnkfunctionalcitoticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkfunctionalcitoticket` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ticket_id` int DEFAULT '0',
  `functionalci_id` int DEFAULT '0',
  `impact` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `impact_code` enum('computed','manual','not_impacted') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'manual',
  PRIMARY KEY (`id`),
  KEY `ticket_id` (`ticket_id`),
  KEY `functionalci_id` (`functionalci_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkfunctionalcitoticket`
--

LOCK TABLES `lnkfunctionalcitoticket` WRITE;
/*!40000 ALTER TABLE `lnkfunctionalcitoticket` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkfunctionalcitoticket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkgrouptoci`
--

DROP TABLE IF EXISTS `lnkgrouptoci`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkgrouptoci` (
  `id` int NOT NULL AUTO_INCREMENT,
  `group_id` int DEFAULT '0',
  `ci_id` int DEFAULT '0',
  `reason` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `group_id` (`group_id`),
  KEY `ci_id` (`ci_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkgrouptoci`
--

LOCK TABLES `lnkgrouptoci` WRITE;
/*!40000 ALTER TABLE `lnkgrouptoci` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkgrouptoci` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkipaddresstoipaddress`
--

DROP TABLE IF EXISTS `lnkipaddresstoipaddress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkipaddresstoipaddress` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ip1_id` int DEFAULT '0',
  `ip2_id` int DEFAULT '0',
  `external_service_port` int DEFAULT NULL,
  `map_to_port` int DEFAULT NULL,
  `protocol` enum('both','icmp','sctp','tcp','udp') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ip1_id` (`ip1_id`),
  KEY `ip2_id` (`ip2_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkipaddresstoipaddress`
--

LOCK TABLES `lnkipaddresstoipaddress` WRITE;
/*!40000 ALTER TABLE `lnkipaddresstoipaddress` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkipaddresstoipaddress` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkipblocktolocation`
--

DROP TABLE IF EXISTS `lnkipblocktolocation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkipblocktolocation` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ipblock_id` int DEFAULT '0',
  `location_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `ipblock_id` (`ipblock_id`),
  KEY `location_id` (`location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkipblocktolocation`
--

LOCK TABLES `lnkipblocktolocation` WRITE;
/*!40000 ALTER TABLE `lnkipblocktolocation` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkipblocktolocation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkipinterfacetoipaddress`
--

DROP TABLE IF EXISTS `lnkipinterfacetoipaddress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkipinterfacetoipaddress` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ipinterface_id` int DEFAULT '0',
  `ipaddress_id` int DEFAULT '0',
  `ipaddress_ip` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `ipinterface_id` (`ipinterface_id`),
  KEY `ipaddress_id` (`ipaddress_id`),
  KEY `ipaddress_ip` (`ipaddress_ip`(95))
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkipinterfacetoipaddress`
--

LOCK TABLES `lnkipinterfacetoipaddress` WRITE;
/*!40000 ALTER TABLE `lnkipinterfacetoipaddress` DISABLE KEYS */;
INSERT INTO `lnkipinterfacetoipaddress` VALUES (1,2,42,'10.170.0.254'),(2,3,70,'172.16.20.254'),(3,4,71,'172.16.21.254'),(4,9,72,'192.168.11.254'),(5,5,34,'10.160.0.254'),(6,7,73,'10.172.0.254'),(7,6,74,'10.173.0.254'),(8,8,75,'10.171.0.254'),(9,12,69,'192.168.100.200'),(10,13,76,'172.16.21.200'),(11,10,77,'172.16.20.200'),(12,11,60,'192.168.11.200');
/*!40000 ALTER TABLE `lnkipinterfacetoipaddress` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkipobjecttoticket`
--

DROP TABLE IF EXISTS `lnkipobjecttoticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkipobjecttoticket` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ipobject_id` int DEFAULT '0',
  `ticket_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `ipobject_id` (`ipobject_id`),
  KEY `ticket_id` (`ticket_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkipobjecttoticket`
--

LOCK TABLES `lnkipobjecttoticket` WRITE;
/*!40000 ALTER TABLE `lnkipobjecttoticket` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkipobjecttoticket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkipsubnettoipsubnet`
--

DROP TABLE IF EXISTS `lnkipsubnettoipsubnet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkipsubnettoipsubnet` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ipsubnet1_id` int DEFAULT '0',
  `ipsubnet2_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `ipsubnet1_id` (`ipsubnet1_id`),
  KEY `ipsubnet2_id` (`ipsubnet2_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkipsubnettoipsubnet`
--

LOCK TABLES `lnkipsubnettoipsubnet` WRITE;
/*!40000 ALTER TABLE `lnkipsubnettoipsubnet` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkipsubnettoipsubnet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkipsubnettolocation`
--

DROP TABLE IF EXISTS `lnkipsubnettolocation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkipsubnettolocation` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ipsubnet_id` int DEFAULT '0',
  `location_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `ipsubnet_id` (`ipsubnet_id`),
  KEY `location_id` (`location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkipsubnettolocation`
--

LOCK TABLES `lnkipsubnettolocation` WRITE;
/*!40000 ALTER TABLE `lnkipsubnettolocation` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkipsubnettolocation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkipsubnettovlan`
--

DROP TABLE IF EXISTS `lnkipsubnettovlan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkipsubnettovlan` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ipsubnet_id` int DEFAULT '0',
  `vlan_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `ipsubnet_id` (`ipsubnet_id`),
  KEY `vlan_id` (`vlan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkipsubnettovlan`
--

LOCK TABLES `lnkipsubnettovlan` WRITE;
/*!40000 ALTER TABLE `lnkipsubnettovlan` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkipsubnettovlan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkipsubnettovrf`
--

DROP TABLE IF EXISTS `lnkipsubnettovrf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkipsubnettovrf` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ipsubnet_id` int DEFAULT '0',
  `vrf_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `ipsubnet_id` (`ipsubnet_id`),
  KEY `vrf_id` (`vrf_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkipsubnettovrf`
--

LOCK TABLES `lnkipsubnettovrf` WRITE;
/*!40000 ALTER TABLE `lnkipsubnettovrf` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkipsubnettovrf` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnklogicalinterfacetovlan`
--

DROP TABLE IF EXISTS `lnklogicalinterfacetovlan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnklogicalinterfacetovlan` (
  `id` int NOT NULL AUTO_INCREMENT,
  `logicalinterface_id` int DEFAULT '0',
  `vlan_id` int DEFAULT '0',
  `mode` enum('tagged','untagged') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'untagged',
  PRIMARY KEY (`id`),
  KEY `logicalinterface_id` (`logicalinterface_id`),
  KEY `vlan_id` (`vlan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnklogicalinterfacetovlan`
--

LOCK TABLES `lnklogicalinterfacetovlan` WRITE;
/*!40000 ALTER TABLE `lnklogicalinterfacetovlan` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnklogicalinterfacetovlan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnklogicalinterfacetovrf`
--

DROP TABLE IF EXISTS `lnklogicalinterfacetovrf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnklogicalinterfacetovrf` (
  `id` int NOT NULL AUTO_INCREMENT,
  `logicalinterface_id` int DEFAULT '0',
  `vrf_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `logicalinterface_id` (`logicalinterface_id`),
  KEY `vrf_id` (`vrf_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnklogicalinterfacetovrf`
--

LOCK TABLES `lnklogicalinterfacetovrf` WRITE;
/*!40000 ALTER TABLE `lnklogicalinterfacetovrf` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnklogicalinterfacetovrf` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnknetworkdevicevirtualinterfacetovlan`
--

DROP TABLE IF EXISTS `lnknetworkdevicevirtualinterfacetovlan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnknetworkdevicevirtualinterfacetovlan` (
  `id` int NOT NULL AUTO_INCREMENT,
  `networkdevicevirtualinterface_id` int DEFAULT '0',
  `vlan_id` int DEFAULT '0',
  `mode` enum('tagged','untagged') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'untagged',
  PRIMARY KEY (`id`),
  KEY `networkdevicevirtualinterface_id` (`networkdevicevirtualinterface_id`),
  KEY `vlan_id` (`vlan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnknetworkdevicevirtualinterfacetovlan`
--

LOCK TABLES `lnknetworkdevicevirtualinterfacetovlan` WRITE;
/*!40000 ALTER TABLE `lnknetworkdevicevirtualinterfacetovlan` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnknetworkdevicevirtualinterfacetovlan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnknetworkdevicevirtualinterfacetovrf`
--

DROP TABLE IF EXISTS `lnknetworkdevicevirtualinterfacetovrf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnknetworkdevicevirtualinterfacetovrf` (
  `id` int NOT NULL AUTO_INCREMENT,
  `networkdevicevirtualinterface_id` int DEFAULT '0',
  `vrf_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `networkdevicevirtualinterface_id` (`networkdevicevirtualinterface_id`),
  KEY `vrf_id` (`vrf_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnknetworkdevicevirtualinterfacetovrf`
--

LOCK TABLES `lnknetworkdevicevirtualinterfacetovrf` WRITE;
/*!40000 ALTER TABLE `lnknetworkdevicevirtualinterfacetovrf` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnknetworkdevicevirtualinterfacetovrf` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkpersontoteam`
--

DROP TABLE IF EXISTS `lnkpersontoteam`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkpersontoteam` (
  `id` int NOT NULL AUTO_INCREMENT,
  `team_id` int DEFAULT '0',
  `person_id` int DEFAULT '0',
  `role_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `team_id` (`team_id`),
  KEY `person_id` (`person_id`),
  KEY `role_id` (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkpersontoteam`
--

LOCK TABLES `lnkpersontoteam` WRITE;
/*!40000 ALTER TABLE `lnkpersontoteam` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkpersontoteam` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkphysicalinterfacetovlan`
--

DROP TABLE IF EXISTS `lnkphysicalinterfacetovlan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkphysicalinterfacetovlan` (
  `id` int NOT NULL AUTO_INCREMENT,
  `physicalinterface_id` int DEFAULT '0',
  `vlan_id` int DEFAULT '0',
  `mode` enum('tagged','untagged') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'untagged',
  PRIMARY KEY (`id`),
  KEY `physicalinterface_id` (`physicalinterface_id`),
  KEY `vlan_id` (`vlan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkphysicalinterfacetovlan`
--

LOCK TABLES `lnkphysicalinterfacetovlan` WRITE;
/*!40000 ALTER TABLE `lnkphysicalinterfacetovlan` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkphysicalinterfacetovlan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkphysicalinterfacetovrf`
--

DROP TABLE IF EXISTS `lnkphysicalinterfacetovrf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkphysicalinterfacetovrf` (
  `id` int NOT NULL AUTO_INCREMENT,
  `physicalinterface_id` int DEFAULT '0',
  `vrf_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `physicalinterface_id` (`physicalinterface_id`),
  KEY `vrf_id` (`vrf_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkphysicalinterfacetovrf`
--

LOCK TABLES `lnkphysicalinterfacetovrf` WRITE;
/*!40000 ALTER TABLE `lnkphysicalinterfacetovrf` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkphysicalinterfacetovrf` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkprovidercontracttoservice`
--

DROP TABLE IF EXISTS `lnkprovidercontracttoservice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkprovidercontracttoservice` (
  `id` int NOT NULL AUTO_INCREMENT,
  `providercontract_id` int DEFAULT '0',
  `service_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `providercontract_id` (`providercontract_id`),
  KEY `service_id` (`service_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkprovidercontracttoservice`
--

LOCK TABLES `lnkprovidercontracttoservice` WRITE;
/*!40000 ALTER TABLE `lnkprovidercontracttoservice` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkprovidercontracttoservice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkservertovolume`
--

DROP TABLE IF EXISTS `lnkservertovolume`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkservertovolume` (
  `id` int NOT NULL AUTO_INCREMENT,
  `volume_id` int DEFAULT '0',
  `server_id` int DEFAULT '0',
  `size_used` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `volume_id` (`volume_id`),
  KEY `server_id` (`server_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkservertovolume`
--

LOCK TABLES `lnkservertovolume` WRITE;
/*!40000 ALTER TABLE `lnkservertovolume` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkservertovolume` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkslatoslt`
--

DROP TABLE IF EXISTS `lnkslatoslt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkslatoslt` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sla_id` int DEFAULT '0',
  `slt_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sla_id` (`sla_id`),
  KEY `slt_id` (`slt_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkslatoslt`
--

LOCK TABLES `lnkslatoslt` WRITE;
/*!40000 ALTER TABLE `lnkslatoslt` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkslatoslt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnksoftwareinstancetosoftwarepatch`
--

DROP TABLE IF EXISTS `lnksoftwareinstancetosoftwarepatch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnksoftwareinstancetosoftwarepatch` (
  `id` int NOT NULL AUTO_INCREMENT,
  `softwarepatch_id` int DEFAULT '0',
  `softwareinstance_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `softwarepatch_id` (`softwarepatch_id`),
  KEY `softwareinstance_id` (`softwareinstance_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnksoftwareinstancetosoftwarepatch`
--

LOCK TABLES `lnksoftwareinstancetosoftwarepatch` WRITE;
/*!40000 ALTER TABLE `lnksoftwareinstancetosoftwarepatch` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnksoftwareinstancetosoftwarepatch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnksubnettovlan`
--

DROP TABLE IF EXISTS `lnksubnettovlan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnksubnettovlan` (
  `id` int NOT NULL AUTO_INCREMENT,
  `subnet_id` int DEFAULT '0',
  `vlan_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `subnet_id` (`subnet_id`),
  KEY `vlan_id` (`vlan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnksubnettovlan`
--

LOCK TABLES `lnksubnettovlan` WRITE;
/*!40000 ALTER TABLE `lnksubnettovlan` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnksubnettovlan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkvirtualdevicetovolume`
--

DROP TABLE IF EXISTS `lnkvirtualdevicetovolume`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkvirtualdevicetovolume` (
  `id` int NOT NULL AUTO_INCREMENT,
  `volume_id` int DEFAULT '0',
  `virtualdevice_id` int DEFAULT '0',
  `size_used` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `volume_id` (`volume_id`),
  KEY `virtualdevice_id` (`virtualdevice_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkvirtualdevicetovolume`
--

LOCK TABLES `lnkvirtualdevicetovolume` WRITE;
/*!40000 ALTER TABLE `lnkvirtualdevicetovolume` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkvirtualdevicetovolume` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location`
--

DROP TABLE IF EXISTS `location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `location` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `status` enum('active','inactive') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `org_id` int DEFAULT '0',
  `address` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `postal_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `city` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `country` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `obsolescence_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95)),
  KEY `org_id` (`org_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location`
--

LOCK TABLES `location` WRITE;
/*!40000 ALTER TABLE `location` DISABLE KEYS */;
INSERT INTO `location` VALUES (1,'MegaQuagga DataCenter','active',1,'','','','',NULL);
/*!40000 ALTER TABLE `location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logicalinterface`
--

DROP TABLE IF EXISTS `logicalinterface`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `logicalinterface` (
  `id` int NOT NULL AUTO_INCREMENT,
  `virtualmachine_id` int DEFAULT '0',
  `status` enum('active','inactive') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  PRIMARY KEY (`id`),
  KEY `virtualmachine_id` (`virtualmachine_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logicalinterface`
--

LOCK TABLES `logicalinterface` WRITE;
/*!40000 ALTER TABLE `logicalinterface` DISABLE KEYS */;
/*!40000 ALTER TABLE `logicalinterface` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logicalvolume`
--

DROP TABLE IF EXISTS `logicalvolume`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `logicalvolume` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `lun_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `raid_level` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `size` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `storagesystem_id` int DEFAULT '0',
  `obsolescence_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95)),
  KEY `storagesystem_id` (`storagesystem_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logicalvolume`
--

LOCK TABLES `logicalvolume` WRITE;
/*!40000 ALTER TABLE `logicalvolume` DISABLE KEYS */;
/*!40000 ALTER TABLE `logicalvolume` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `middleware`
--

DROP TABLE IF EXISTS `middleware`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `middleware` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `middleware`
--

LOCK TABLES `middleware` WRITE;
/*!40000 ALTER TABLE `middleware` DISABLE KEYS */;
INSERT INTO `middleware` VALUES (25),(26),(27),(28),(29),(30),(34),(35),(36),(37),(38),(39),(40),(42),(43),(44),(45),(46),(47),(48),(49),(50),(51),(52),(53),(54),(55),(56),(57),(58),(59),(60),(61),(62),(63),(64),(65),(66),(67),(68),(69),(70),(71),(72),(73),(74),(75),(76),(77),(78),(79),(80),(81),(82),(83),(84),(85),(86),(87),(88),(89),(90),(91),(92),(93),(94),(95),(96),(97),(98),(99),(100),(101),(102);
/*!40000 ALTER TABLE `middleware` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `middlewareinstance`
--

DROP TABLE IF EXISTS `middlewareinstance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `middlewareinstance` (
  `id` int NOT NULL AUTO_INCREMENT,
  `middleware_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `middleware_id` (`middleware_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `middlewareinstance`
--

LOCK TABLES `middlewareinstance` WRITE;
/*!40000 ALTER TABLE `middlewareinstance` DISABLE KEYS */;
/*!40000 ALTER TABLE `middlewareinstance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mobilephone`
--

DROP TABLE IF EXISTS `mobilephone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mobilephone` (
  `id` int NOT NULL AUTO_INCREMENT,
  `imei` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `hw_pin` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `macaddress` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `ipaddress_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `ipaddress_id` (`ipaddress_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mobilephone`
--

LOCK TABLES `mobilephone` WRITE;
/*!40000 ALTER TABLE `mobilephone` DISABLE KEYS */;
/*!40000 ALTER TABLE `mobilephone` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model`
--

DROP TABLE IF EXISTS `model`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `model` (
  `id` int NOT NULL AUTO_INCREMENT,
  `brand_id` int DEFAULT '0',
  `picture_data` longblob,
  `picture_mimetype` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `picture_filename` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `picture_downloads_count` int unsigned DEFAULT NULL,
  `type` enum('DiskArray','Enclosure','IPPhone','MobilePhone','NAS','NetworkDevice','PC','PDU','Peripheral','Phone','PowerSource','Printer','Rack','SANSwitch','Server','StorageSystem','Tablet','TapeLibrary') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `brand_id` (`brand_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model`
--

LOCK TABLES `model` WRITE;
/*!40000 ALTER TABLE `model` DISABLE KEYS */;
/*!40000 ALTER TABLE `model` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nas`
--

DROP TABLE IF EXISTS `nas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nas` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nas`
--

LOCK TABLES `nas` WRITE;
/*!40000 ALTER TABLE `nas` DISABLE KEYS */;
/*!40000 ALTER TABLE `nas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nasfilesystem`
--

DROP TABLE IF EXISTS `nasfilesystem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nasfilesystem` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `raid_level` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `size` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `nas_id` int DEFAULT '0',
  `obsolescence_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95)),
  KEY `nas_id` (`nas_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nasfilesystem`
--

LOCK TABLES `nasfilesystem` WRITE;
/*!40000 ALTER TABLE `nasfilesystem` DISABLE KEYS */;
/*!40000 ALTER TABLE `nasfilesystem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `networkdevice`
--

DROP TABLE IF EXISTS `networkdevice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `networkdevice` (
  `id` int NOT NULL AUTO_INCREMENT,
  `networkdevicetype_id` int DEFAULT '0',
  `iosversion_id` int DEFAULT '0',
  `ram` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `networkdevicetype_id` (`networkdevicetype_id`),
  KEY `iosversion_id` (`iosversion_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `networkdevice`
--

LOCK TABLES `networkdevice` WRITE;
/*!40000 ALTER TABLE `networkdevice` DISABLE KEYS */;
INSERT INTO `networkdevice` VALUES (1,47,0,''),(2,47,0,''),(17,47,0,''),(18,47,0,''),(23,47,0,'');
/*!40000 ALTER TABLE `networkdevice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `networkdevicetype`
--

DROP TABLE IF EXISTS `networkdevicetype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `networkdevicetype` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `networkdevicetype`
--

LOCK TABLES `networkdevicetype` WRITE;
/*!40000 ALTER TABLE `networkdevicetype` DISABLE KEYS */;
INSERT INTO `networkdevicetype` VALUES (47);
/*!40000 ALTER TABLE `networkdevicetype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `networkdevicevirtualinterface`
--

DROP TABLE IF EXISTS `networkdevicevirtualinterface`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `networkdevicevirtualinterface` (
  `id` int NOT NULL AUTO_INCREMENT,
  `networkdevice_id` int DEFAULT '0',
  `status` enum('active','inactive') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  PRIMARY KEY (`id`),
  KEY `networkdevice_id` (`networkdevice_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `networkdevicevirtualinterface`
--

LOCK TABLES `networkdevicevirtualinterface` WRITE;
/*!40000 ALTER TABLE `networkdevicevirtualinterface` DISABLE KEYS */;
/*!40000 ALTER TABLE `networkdevicevirtualinterface` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `networkinterface`
--

DROP TABLE IF EXISTS `networkinterface`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `networkinterface` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'NetworkInterface',
  `obsolescence_date` date DEFAULT NULL,
  `operational_status` enum('active','inactive') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95)),
  KEY `finalclass` (`finalclass`(95)),
  KEY `operational_status` (`operational_status`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `networkinterface`
--

LOCK TABLES `networkinterface` WRITE;
/*!40000 ALTER TABLE `networkinterface` DISABLE KEYS */;
INSERT INTO `networkinterface` VALUES (1,'eth0','PhysicalInterface',NULL,'active'),(2,'ETH3','PhysicalInterface',NULL,'active'),(3,'ETH4','PhysicalInterface',NULL,'active'),(4,'ETH5','PhysicalInterface',NULL,'active'),(5,'ETH11','PhysicalInterface',NULL,'active'),(6,'ETH5','PhysicalInterface',NULL,'active'),(7,'ETH12','PhysicalInterface',NULL,'active'),(8,'ETH8','PhysicalInterface',NULL,'active'),(9,'ETH10','PhysicalInterface',NULL,'active'),(10,'EM0','PhysicalInterface',NULL,'active'),(11,'EM1','PhysicalInterface',NULL,'active'),(12,'EM0','PhysicalInterface',NULL,'active'),(13,'EM1','PhysicalInterface',NULL,'active');
/*!40000 ALTER TABLE `networkinterface` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `organization`
--

DROP TABLE IF EXISTS `organization`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `organization` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `status` enum('active','inactive') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `parent_id` int DEFAULT '0',
  `parent_id_left` int DEFAULT '0',
  `parent_id_right` int DEFAULT '0',
  `deliverymodel_id` int DEFAULT '0',
  `obsolescence_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95)),
  KEY `parent_id` (`parent_id`),
  KEY `parent_id_left` (`parent_id_left`),
  KEY `parent_id_right` (`parent_id_right`),
  KEY `deliverymodel_id` (`deliverymodel_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organization`
--

LOCK TABLES `organization` WRITE;
/*!40000 ALTER TABLE `organization` DISABLE KEYS */;
INSERT INTO `organization` VALUES (1,'MegaQuagga Publishing','SOMECODE','active',0,1,2,0,NULL);
/*!40000 ALTER TABLE `organization` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `osfamily`
--

DROP TABLE IF EXISTS `osfamily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `osfamily` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `osfamily`
--

LOCK TABLES `osfamily` WRITE;
/*!40000 ALTER TABLE `osfamily` DISABLE KEYS */;
INSERT INTO `osfamily` VALUES (20),(21),(22),(23),(24),(25),(26),(27),(28);
/*!40000 ALTER TABLE `osfamily` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oslicence`
--

DROP TABLE IF EXISTS `oslicence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oslicence` (
  `id` int NOT NULL AUTO_INCREMENT,
  `osversion_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `osversion_id` (`osversion_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oslicence`
--

LOCK TABLES `oslicence` WRITE;
/*!40000 ALTER TABLE `oslicence` DISABLE KEYS */;
/*!40000 ALTER TABLE `oslicence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospatch`
--

DROP TABLE IF EXISTS `ospatch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospatch` (
  `id` int NOT NULL AUTO_INCREMENT,
  `osversion_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `osversion_id` (`osversion_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospatch`
--

LOCK TABLES `ospatch` WRITE;
/*!40000 ALTER TABLE `ospatch` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospatch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `osversion`
--

DROP TABLE IF EXISTS `osversion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `osversion` (
  `id` int NOT NULL AUTO_INCREMENT,
  `osfamily_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `osfamily_id` (`osfamily_id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `osversion`
--

LOCK TABLES `osversion` WRITE;
/*!40000 ALTER TABLE `osversion` DISABLE KEYS */;
INSERT INTO `osversion` VALUES (42,20),(31,21),(41,22),(40,23),(33,24),(37,24),(32,25),(34,25),(38,25),(48,25),(39,26),(29,27),(30,27),(35,28),(36,28);
/*!40000 ALTER TABLE `osversion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `othersoftware`
--

DROP TABLE IF EXISTS `othersoftware`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `othersoftware` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `othersoftware`
--

LOCK TABLES `othersoftware` WRITE;
/*!40000 ALTER TABLE `othersoftware` DISABLE KEYS */;
/*!40000 ALTER TABLE `othersoftware` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patch`
--

DROP TABLE IF EXISTS `patch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `patch` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Patch',
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95)),
  KEY `finalclass` (`finalclass`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patch`
--

LOCK TABLES `patch` WRITE;
/*!40000 ALTER TABLE `patch` DISABLE KEYS */;
/*!40000 ALTER TABLE `patch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pc`
--

DROP TABLE IF EXISTS `pc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pc` (
  `id` int NOT NULL AUTO_INCREMENT,
  `osfamily_id` int DEFAULT '0',
  `osversion_id` int DEFAULT '0',
  `cpu` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `ram` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `type` enum('desktop','laptop') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `macaddress` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `ipaddress_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `osfamily_id` (`osfamily_id`),
  KEY `osversion_id` (`osversion_id`),
  KEY `ipaddress_id` (`ipaddress_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pc`
--

LOCK TABLES `pc` WRITE;
/*!40000 ALTER TABLE `pc` DISABLE KEYS */;
INSERT INTO `pc` VALUES (5,27,0,'','',NULL,'00:50:56:2b:60:53',33),(6,21,0,'','',NULL,'',35),(7,27,0,'','',NULL,'02:00:a2:6c:b2:f5',44),(8,27,0,'','',NULL,'02:dd:e5:f6:48:a4',45),(9,27,0,'','',NULL,'02:1c:a4:90:75:20',48),(10,0,0,'','',NULL,'02:1c:a4:90:75:20',49),(11,27,0,'','',NULL,'02:67:2f:db:58:ad',50),(12,0,0,'','',NULL,'02:e2:a0:b8:c3:86',51),(13,27,0,'','',NULL,'02:a7:63:20:94:c3',53),(14,0,0,'','',NULL,'02:bc:6e:fc:56:69',55),(15,27,0,'','',NULL,'02:a1:1e:79:c8:0d',56),(16,27,0,'','',NULL,'02:f5:0d:f8:fb:35',57),(22,27,0,'','',NULL,'00:50:56:33:b8:83',38);
/*!40000 ALTER TABLE `pc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pcsoftware`
--

DROP TABLE IF EXISTS `pcsoftware`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pcsoftware` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pcsoftware`
--

LOCK TABLES `pcsoftware` WRITE;
/*!40000 ALTER TABLE `pcsoftware` DISABLE KEYS */;
/*!40000 ALTER TABLE `pcsoftware` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pdu`
--

DROP TABLE IF EXISTS `pdu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pdu` (
  `id` int NOT NULL AUTO_INCREMENT,
  `rack_id` int DEFAULT '0',
  `powerstart_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `rack_id` (`rack_id`),
  KEY `powerstart_id` (`powerstart_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pdu`
--

LOCK TABLES `pdu` WRITE;
/*!40000 ALTER TABLE `pdu` DISABLE KEYS */;
/*!40000 ALTER TABLE `pdu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `peripheral`
--

DROP TABLE IF EXISTS `peripheral`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `peripheral` (
  `id` int NOT NULL AUTO_INCREMENT,
  `macaddress` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `ipaddress_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `ipaddress_id` (`ipaddress_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `peripheral`
--

LOCK TABLES `peripheral` WRITE;
/*!40000 ALTER TABLE `peripheral` DISABLE KEYS */;
/*!40000 ALTER TABLE `peripheral` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `person`
--

DROP TABLE IF EXISTS `person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `person` (
  `id` int NOT NULL AUTO_INCREMENT,
  `picture_data` longblob,
  `picture_mimetype` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `picture_filename` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `picture_downloads_count` int unsigned DEFAULT NULL,
  `first_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `employee_number` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `mobile_phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `location_id` int DEFAULT '0',
  `manager_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `first_name` (`first_name`(95)),
  KEY `location_id` (`location_id`),
  KEY `manager_id` (`manager_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `person`
--

LOCK TABLES `person` WRITE;
/*!40000 ALTER TABLE `person` DISABLE KEYS */;
INSERT INTO `person` VALUES (1,'','','',0,'MegaQuagga Administrator','','',0,0);
/*!40000 ALTER TABLE `person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phone`
--

DROP TABLE IF EXISTS `phone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `phone` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phone`
--

LOCK TABLES `phone` WRITE;
/*!40000 ALTER TABLE `phone` DISABLE KEYS */;
/*!40000 ALTER TABLE `phone` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `physicaldevice`
--

DROP TABLE IF EXISTS `physicaldevice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `physicaldevice` (
  `id` int NOT NULL AUTO_INCREMENT,
  `serialnumber` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `location_id` int DEFAULT '0',
  `status` enum('stock','implementation','production','obsolete') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'production',
  `brand_id` int DEFAULT '0',
  `model_id` int DEFAULT '0',
  `asset_number` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `purchase_date` date DEFAULT NULL,
  `end_of_warranty` date DEFAULT NULL,
  `finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'PhysicalDevice',
  PRIMARY KEY (`id`),
  KEY `location_id` (`location_id`),
  KEY `brand_id` (`brand_id`),
  KEY `model_id` (`model_id`),
  KEY `finalclass` (`finalclass`(95))
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `physicaldevice`
--

LOCK TABLES `physicaldevice` WRITE;
/*!40000 ALTER TABLE `physicaldevice` DISABLE KEYS */;
INSERT INTO `physicaldevice` VALUES (1,'',1,'production',0,0,'',NULL,NULL,'NetworkDevice'),(2,'',1,'production',0,0,'',NULL,NULL,'NetworkDevice'),(3,'',1,'production',0,0,'',NULL,NULL,'Server'),(5,'',0,'production',0,0,'',NULL,NULL,'PC'),(6,'',0,'production',0,0,'',NULL,NULL,'PC'),(7,'',0,'production',0,0,'',NULL,NULL,'PC'),(8,'',0,'production',0,0,'',NULL,NULL,'PC'),(9,'',0,'production',0,0,'',NULL,NULL,'PC'),(10,'',0,'production',0,0,'',NULL,NULL,'PC'),(11,'',0,'production',0,0,'',NULL,NULL,'PC'),(12,'',0,'production',0,0,'',NULL,NULL,'PC'),(13,'',0,'production',0,0,'',NULL,NULL,'PC'),(14,'',0,'production',0,0,'',NULL,NULL,'PC'),(15,'',0,'production',0,0,'',NULL,NULL,'PC'),(16,'',0,'production',0,0,'',NULL,NULL,'PC'),(17,'',1,'production',0,0,'',NULL,NULL,'NetworkDevice'),(18,'',1,'production',0,0,'',NULL,NULL,'NetworkDevice'),(19,'',0,'production',0,0,'',NULL,NULL,'Server'),(20,'',0,'production',0,0,'',NULL,NULL,'Server'),(21,'',0,'production',0,0,'',NULL,NULL,'Server'),(22,'',0,'production',0,0,'',NULL,NULL,'PC'),(23,'',0,'production',0,0,'',NULL,NULL,'NetworkDevice');
/*!40000 ALTER TABLE `physicaldevice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `physicalinterface`
--

DROP TABLE IF EXISTS `physicalinterface`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `physicalinterface` (
  `id` int NOT NULL AUTO_INCREMENT,
  `connectableci_id` int DEFAULT '0',
  `status` enum('active','inactive','obsolete','stock') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  PRIMARY KEY (`id`),
  KEY `connectableci_id` (`connectableci_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `physicalinterface`
--

LOCK TABLES `physicalinterface` WRITE;
/*!40000 ALTER TABLE `physicalinterface` DISABLE KEYS */;
INSERT INTO `physicalinterface` VALUES (1,3,'active'),(2,1,'active'),(3,1,'active'),(4,1,'active'),(5,2,'active'),(6,2,'active'),(7,2,'active'),(8,2,'active'),(9,2,'active'),(10,17,'active'),(11,17,'active'),(12,18,'active'),(13,18,'active');
/*!40000 ALTER TABLE `physicalinterface` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `powerconnection`
--

DROP TABLE IF EXISTS `powerconnection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `powerconnection` (
  `id` int NOT NULL AUTO_INCREMENT,
  `finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'PowerConnection',
  `macaddress` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `ipaddress_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `finalclass` (`finalclass`(95)),
  KEY `ipaddress_id` (`ipaddress_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `powerconnection`
--

LOCK TABLES `powerconnection` WRITE;
/*!40000 ALTER TABLE `powerconnection` DISABLE KEYS */;
/*!40000 ALTER TABLE `powerconnection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `powersource`
--

DROP TABLE IF EXISTS `powersource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `powersource` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `powersource`
--

LOCK TABLES `powersource` WRITE;
/*!40000 ALTER TABLE `powersource` DISABLE KEYS */;
/*!40000 ALTER TABLE `powersource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `printer`
--

DROP TABLE IF EXISTS `printer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `printer` (
  `id` int NOT NULL AUTO_INCREMENT,
  `macaddress` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `ipaddress_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `ipaddress_id` (`ipaddress_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `printer`
--

LOCK TABLES `printer` WRITE;
/*!40000 ALTER TABLE `printer` DISABLE KEYS */;
/*!40000 ALTER TABLE `printer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_action`
--

DROP TABLE IF EXISTS `priv_action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_action` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `status` enum('test','enabled','disabled') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'test',
  `asynchronous` enum('use_global_setting','yes','no') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'use_global_setting',
  `realclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Action',
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95)),
  KEY `realclass` (`realclass`(95))
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_action`
--

LOCK TABLES `priv_action` WRITE;
/*!40000 ALTER TABLE `priv_action` DISABLE KEYS */;
INSERT INTO `priv_action` VALUES (1,'Notification to persons mentioned in logs','','enabled','use_global_setting','ActionEmail'),(2,'Notification to persons mentioned in logs','','enabled','use_global_setting','ActionNewsroom'),(3,'Notification on public log update through the portal','','enabled','use_global_setting','ActionNewsroom'),(4,'Notification to agent when ticket assigned','','enabled','use_global_setting','ActionNewsroom');
/*!40000 ALTER TABLE `priv_action` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_action_email`
--

DROP TABLE IF EXISTS `priv_action_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_action_email` (
  `id` int NOT NULL AUTO_INCREMENT,
  `test_recipient` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `from` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `from_label` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `reply_to` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `reply_to_label` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `to` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `cc` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `bcc` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `subject` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `body` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `importance` enum('low','normal','high') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'normal',
  `html_template_data` longblob,
  `html_template_mimetype` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `html_template_filename` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `html_template_downloads_count` int unsigned DEFAULT NULL,
  `ignore_notify` enum('yes','no') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'yes',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_action_email`
--

LOCK TABLES `priv_action_email` WRITE;
/*!40000 ALTER TABLE `priv_action_email` DISABLE KEYS */;
INSERT INTO `priv_action_email` VALUES (1,'','$current_contact->email$','','','','SELECT Person WHERE id = :mentioned->id','','','You have been mentioned in \"$this->friendlyname$\"','<p>Hello $mentioned-&gt;first_name$,</p>\n								<p>You have been mentioned by $current_contact-&gt;friendlyname$ in $this-&gt;hyperlink()$</p>','normal','','','',0,'yes');
/*!40000 ALTER TABLE `priv_action_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_action_googlechat_notif`
--

DROP TABLE IF EXISTS `priv_action_googlechat_notif`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_action_googlechat_notif` (
  `id` int NOT NULL AUTO_INCREMENT,
  `message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_action_googlechat_notif`
--

LOCK TABLES `priv_action_googlechat_notif` WRITE;
/*!40000 ALTER TABLE `priv_action_googlechat_notif` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_action_googlechat_notif` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_action_itop_webhook`
--

DROP TABLE IF EXISTS `priv_action_itop_webhook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_action_itop_webhook` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_action_itop_webhook`
--

LOCK TABLES `priv_action_itop_webhook` WRITE;
/*!40000 ALTER TABLE `priv_action_itop_webhook` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_action_itop_webhook` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_action_microsoftteams_notif`
--

DROP TABLE IF EXISTS `priv_action_microsoftteams_notif`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_action_microsoftteams_notif` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `message` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `theme_color` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `image_url` varchar(2048) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `include_list_attributes` enum('list','msteams') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `include_modify_button` enum('no','yes') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `include_delete_button` enum('no','yes') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `include_other_actions_button` enum('no','specify','yes') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `specified_other_actions` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_action_microsoftteams_notif`
--

LOCK TABLES `priv_action_microsoftteams_notif` WRITE;
/*!40000 ALTER TABLE `priv_action_microsoftteams_notif` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_action_microsoftteams_notif` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_action_newsroom`
--

DROP TABLE IF EXISTS `priv_action_newsroom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_action_newsroom` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `icon_data` longblob,
  `icon_mimetype` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon_filename` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon_downloads_count` int unsigned DEFAULT NULL,
  `priority` enum('1','2','3','4') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '4',
  `test_recipient_id` int DEFAULT '0',
  `recipients` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '$this->url()$',
  PRIMARY KEY (`id`),
  KEY `test_recipient_id` (`test_recipient_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_action_newsroom`
--

LOCK TABLES `priv_action_newsroom` WRITE;
/*!40000 ALTER TABLE `priv_action_newsroom` DISABLE KEYS */;
INSERT INTO `priv_action_newsroom` VALUES (2,'$this->friendlyname$','You have been mentioned by $current_contact->friendlyname$','','','',0,'3',0,'SELECT Person WHERE id = :mentioned->id','$this->url()$'),(3,'$this->friendlyname$','New message from $current_contact->friendlyname$','','','',0,'4',0,'SELECT Person WHERE id = :this->agent_id','$this->url()$'),(4,'$this->friendlyname$','Ticket has been assigned to you','','','',0,'3',0,'SELECT Person WHERE id = :this->agent_id','$this->url()$');
/*!40000 ALTER TABLE `priv_action_newsroom` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_action_notification`
--

DROP TABLE IF EXISTS `priv_action_notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_action_notification` (
  `id` int NOT NULL AUTO_INCREMENT,
  `language` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `realclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'ActionNotification',
  PRIMARY KEY (`id`),
  KEY `language` (`language`(95)),
  KEY `realclass` (`realclass`(95))
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_action_notification`
--

LOCK TABLES `priv_action_notification` WRITE;
/*!40000 ALTER TABLE `priv_action_notification` DISABLE KEYS */;
INSERT INTO `priv_action_notification` VALUES (1,'EN US','ActionEmail'),(2,'EN US','ActionNewsroom'),(3,'EN US','ActionNewsroom'),(4,'EN US','ActionNewsroom');
/*!40000 ALTER TABLE `priv_action_notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_action_rocketchat_notif`
--

DROP TABLE IF EXISTS `priv_action_rocketchat_notif`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_action_rocketchat_notif` (
  `id` int NOT NULL AUTO_INCREMENT,
  `message` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `bot_alias` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `bot_url_avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `bot_emoji_avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_action_rocketchat_notif`
--

LOCK TABLES `priv_action_rocketchat_notif` WRITE;
/*!40000 ALTER TABLE `priv_action_rocketchat_notif` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_action_rocketchat_notif` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_action_slack_notif`
--

DROP TABLE IF EXISTS `priv_action_slack_notif`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_action_slack_notif` (
  `id` int NOT NULL AUTO_INCREMENT,
  `message` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `include_list_attributes` enum('list','slack') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `include_user_info` enum('no','yes') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `include_modify_button` enum('no','yes') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `include_delete_button` enum('no','yes') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `include_other_actions_button` enum('no','specify','yes') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `specified_other_actions` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_action_slack_notif`
--

LOCK TABLES `priv_action_slack_notif` WRITE;
/*!40000 ALTER TABLE `priv_action_slack_notif` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_action_slack_notif` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_action_webhook`
--

DROP TABLE IF EXISTS `priv_action_webhook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_action_webhook` (
  `id` int NOT NULL AUTO_INCREMENT,
  `remoteapplicationconnection_id` int DEFAULT '0',
  `test_remoteapplicationconnection_id` int DEFAULT '0',
  `method` enum('delete','get','head','patch','post','put') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'post',
  `path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `headers` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `payload` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `prepare_payload_callback` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `process_response_callback` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `realclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'ActionWebhook',
  PRIMARY KEY (`id`),
  KEY `remoteapplicationconnection_id` (`remoteapplicationconnection_id`),
  KEY `test_remoteapplicationconnection_id` (`test_remoteapplicationconnection_id`),
  KEY `realclass` (`realclass`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_action_webhook`
--

LOCK TABLES `priv_action_webhook` WRITE;
/*!40000 ALTER TABLE `priv_action_webhook` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_action_webhook` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_app_dashboards`
--

DROP TABLE IF EXISTS `priv_app_dashboards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_app_dashboards` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT '0',
  `menu_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `contents` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `menu_code` (`menu_code`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_app_dashboards`
--

LOCK TABLES `priv_app_dashboards` WRITE;
/*!40000 ALTER TABLE `priv_app_dashboards` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_app_dashboards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_app_preferences`
--

DROP TABLE IF EXISTS `priv_app_preferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_app_preferences` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userid` int DEFAULT '0',
  `preferences` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_app_preferences`
--

LOCK TABLES `priv_app_preferences` WRITE;
/*!40000 ALTER TABLE `priv_app_preferences` DISABLE KEYS */;
INSERT INTO `priv_app_preferences` VALUES (1,1,'a:4:{s:24:\"navigation_menu.expanded\";s:8:\"expanded\";s:20:\"quick_create_history\";a:10:{i:0;a:1:{s:5:\"class\";s:14:\"WebApplication\";}i:1;a:1:{s:5:\"class\";s:10:\"Middleware\";}i:2;a:1:{s:5:\"class\";s:9:\"WebServer\";}i:3;a:1:{s:5:\"class\";s:13:\"NetworkDevice\";}i:4;a:1:{s:5:\"class\";s:11:\"IPv4Address\";}i:5;a:1:{s:5:\"class\";s:2:\"PC\";}i:6;a:1:{s:5:\"class\";s:6:\"Server\";}i:7;a:1:{s:5:\"class\";s:25:\"lnkIPInterfaceToIPAddress\";}i:8;a:1:{s:5:\"class\";s:17:\"PhysicalInterface\";}i:9;a:1:{s:5:\"class\";s:8:\"Location\";}}s:26:\"activity_panel.is_expanded\";a:1:{s:19:\"IPv4Address::create\";b:0;}s:24:\"activity_panel.is_closed\";a:1:{s:19:\"IPv4Address::create\";b:1;}}');
/*!40000 ALTER TABLE `priv_app_preferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_async_send_email`
--

DROP TABLE IF EXISTS `priv_async_send_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_async_send_email` (
  `id` int NOT NULL AUTO_INCREMENT,
  `version` int DEFAULT '1',
  `to` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `subject` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `message` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_async_send_email`
--

LOCK TABLES `priv_async_send_email` WRITE;
/*!40000 ALTER TABLE `priv_async_send_email` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_async_send_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_async_send_newsroom`
--

DROP TABLE IF EXISTS `priv_async_send_newsroom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_async_send_newsroom` (
  `id` int NOT NULL AUTO_INCREMENT,
  `recipients` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `action_id` int DEFAULT '0',
  `trigger_id` int DEFAULT '0',
  `title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `object_id` int DEFAULT NULL,
  `object_class` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `url` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `action_id` (`action_id`),
  KEY `trigger_id` (`trigger_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_async_send_newsroom`
--

LOCK TABLES `priv_async_send_newsroom` WRITE;
/*!40000 ALTER TABLE `priv_async_send_newsroom` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_async_send_newsroom` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_async_send_web_request`
--

DROP TABLE IF EXISTS `priv_async_send_web_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_async_send_web_request` (
  `id` int NOT NULL AUTO_INCREMENT,
  `request` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_async_send_web_request`
--

LOCK TABLES `priv_async_send_web_request` WRITE;
/*!40000 ALTER TABLE `priv_async_send_web_request` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_async_send_web_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_async_task`
--

DROP TABLE IF EXISTS `priv_async_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_async_task` (
  `id` int NOT NULL AUTO_INCREMENT,
  `status` enum('planned','running','idle','error') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'planned',
  `created` datetime DEFAULT NULL,
  `started` datetime DEFAULT NULL,
  `planned` datetime DEFAULT NULL,
  `event_id` int DEFAULT '0',
  `remaining_retries` int DEFAULT '0',
  `last_error_code` int DEFAULT '0',
  `last_error` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `last_attempt` datetime DEFAULT NULL,
  `realclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'AsyncTask',
  PRIMARY KEY (`id`),
  KEY `created` (`created`),
  KEY `event_id` (`event_id`),
  KEY `realclass` (`realclass`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_async_task`
--

LOCK TABLES `priv_async_task` WRITE;
/*!40000 ALTER TABLE `priv_async_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_async_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_auditcategory`
--

DROP TABLE IF EXISTS `priv_auditcategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_auditcategory` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `definition_set` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `ok_error_tolerance` int DEFAULT '5',
  `warning_error_tolerance` int DEFAULT '25',
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_auditcategory`
--

LOCK TABLES `priv_auditcategory` WRITE;
/*!40000 ALTER TABLE `priv_auditcategory` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_auditcategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_auditdomain`
--

DROP TABLE IF EXISTS `priv_auditdomain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_auditdomain` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `icon_data` longblob,
  `icon_mimetype` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon_filename` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon_downloads_count` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_auditdomain`
--

LOCK TABLES `priv_auditdomain` WRITE;
/*!40000 ALTER TABLE `priv_auditdomain` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_auditdomain` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_auditrule`
--

DROP TABLE IF EXISTS `priv_auditrule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_auditrule` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `query` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `valid_flag` enum('true','false') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'true',
  `category_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95)),
  KEY `category_id` (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_auditrule`
--

LOCK TABLES `priv_auditrule` WRITE;
/*!40000 ALTER TABLE `priv_auditrule` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_auditrule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_backgroundtask`
--

DROP TABLE IF EXISTS `priv_backgroundtask`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_backgroundtask` (
  `id` int NOT NULL AUTO_INCREMENT,
  `class_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `first_run_date` datetime DEFAULT NULL,
  `latest_run_date` datetime DEFAULT NULL,
  `next_run_date` datetime DEFAULT NULL,
  `total_exec_count` int DEFAULT '0',
  `latest_run_duration` decimal(8,3) DEFAULT '0.000',
  `min_run_duration` decimal(8,3) DEFAULT '0.000',
  `max_run_duration` decimal(8,3) DEFAULT '0.000',
  `average_run_duration` decimal(8,3) DEFAULT '0.000',
  `running` tinyint(1) DEFAULT '0',
  `status` enum('active','paused','removed') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `system_user` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `class_name` (`class_name`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_backgroundtask`
--

LOCK TABLES `priv_backgroundtask` WRITE;
/*!40000 ALTER TABLE `priv_backgroundtask` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_backgroundtask` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_bulk_export_result`
--

DROP TABLE IF EXISTS `priv_bulk_export_result`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_bulk_export_result` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created` datetime DEFAULT NULL,
  `user_id` int DEFAULT '0',
  `chunk_size` int DEFAULT '0',
  `format` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `temp_file_path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `search` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `status_info` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `localize_output` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `created` (`created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_bulk_export_result`
--

LOCK TABLES `priv_bulk_export_result` WRITE;
/*!40000 ALTER TABLE `priv_bulk_export_result` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_bulk_export_result` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_change`
--

DROP TABLE IF EXISTS `priv_change`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_change` (
  `id` int NOT NULL AUTO_INCREMENT,
  `date` datetime DEFAULT NULL,
  `userinfo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `user_id` int DEFAULT '0',
  `origin` enum('interactive','csv-interactive','csv-import.php','webservice-soap','webservice-rest','synchro-data-source','email-processing','custom-extension') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'interactive',
  PRIMARY KEY (`id`),
  KEY `date` (`date`),
  KEY `user_id` (`user_id`),
  KEY `origin` (`origin`)
) ENGINE=InnoDB AUTO_INCREMENT=287 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_change`
--

LOCK TABLES `priv_change` WRITE;
/*!40000 ALTER TABLE `priv_change` DISABLE KEYS */;
INSERT INTO `priv_change` VALUES (1,'2024-09-10 00:38:05','',0,'interactive'),(2,'2024-09-10 00:38:06','Initialization create administrator',0,'interactive'),(3,'2024-09-10 00:38:07','Initialization from XML files for the selected modules ',0,'interactive'),(4,'2024-09-10 00:38:07','',0,'interactive'),(5,'2024-09-10 00:49:12','Uninstallation',0,'interactive'),(6,'2024-09-10 00:49:13','',0,'interactive'),(7,'2024-09-10 00:52:37','My first name My last name',1,'interactive'),(8,'2024-09-10 00:53:14','My first name My last name',1,'interactive'),(9,'2024-09-10 00:53:33','My first name My last name',1,'interactive'),(10,'2024-09-10 03:04:12','',0,'interactive'),(11,'2024-09-10 03:09:34','My first name My last name',1,'interactive'),(12,'2024-09-10 03:30:07','MegaQuagga Administrator Admin Account',1,'interactive'),(13,'2024-09-10 03:31:47','MegaQuagga Administrator Admin Account',1,'interactive'),(14,'2024-09-10 03:32:00','MegaQuagga Administrator Admin Account',1,'interactive'),(15,'2024-09-10 03:32:38','MegaQuagga Administrator Admin Account',1,'interactive'),(16,'2024-09-10 03:32:49','MegaQuagga Administrator Admin Account',1,'interactive'),(17,'2024-09-10 03:33:30','MegaQuagga Administrator Admin Account',1,'interactive'),(18,'2024-09-10 03:33:41','MegaQuagga Administrator Admin Account',1,'interactive'),(19,'2024-09-10 03:34:29','MegaQuagga Administrator Admin Account',1,'interactive'),(20,'2024-09-10 03:34:51','MegaQuagga Administrator Admin Account',1,'interactive'),(21,'2024-09-10 03:35:34','MegaQuagga Administrator Admin Account',1,'interactive'),(22,'2024-09-10 03:35:59','MegaQuagga Administrator Admin Account',1,'interactive'),(23,'2024-09-10 03:37:33','MegaQuagga Administrator Admin Account',1,'interactive'),(24,'2024-09-10 03:38:28','MegaQuagga Administrator Admin Account',1,'interactive'),(25,'2024-09-10 03:39:10','MegaQuagga Administrator Admin Account',1,'interactive'),(26,'2024-09-10 03:39:45','MegaQuagga Administrator Admin Account',1,'interactive'),(27,'2024-09-10 03:41:16','MegaQuagga Administrator Admin Account',1,'interactive'),(28,'2024-09-10 03:42:27','MegaQuagga Administrator Admin Account',1,'interactive'),(29,'2024-09-10 03:42:48','MegaQuagga Administrator Admin Account',1,'interactive'),(30,'2024-09-10 03:43:56','MegaQuagga Administrator Admin Account',1,'interactive'),(31,'2024-09-10 03:44:56','MegaQuagga Administrator Admin Account',1,'interactive'),(32,'2024-09-20 19:59:11','MegaQuagga Administrator Admin Account',1,'interactive'),(33,'2024-09-20 19:59:40','MegaQuagga Administrator Admin Account',1,'interactive'),(34,'2024-09-22 23:49:46','MegaQuagga Administrator Admin Account',1,'interactive'),(35,'2024-09-25 22:25:51','MegaQuagga Administrator Admin Account',1,'interactive'),(36,'2024-09-25 22:26:02','MegaQuagga Administrator Admin Account',1,'interactive'),(37,'2024-09-25 22:26:19','MegaQuagga Administrator Admin Account',1,'interactive'),(38,'2024-09-25 22:26:26','MegaQuagga Administrator Admin Account',1,'interactive'),(39,'2024-09-25 22:26:47','MegaQuagga Administrator Admin Account',1,'interactive'),(40,'2024-09-25 22:27:07','MegaQuagga Administrator Admin Account',1,'interactive'),(41,'2024-09-25 22:27:25','MegaQuagga Administrator Admin Account',1,'interactive'),(42,'2024-09-25 22:27:48','MegaQuagga Administrator Admin Account',1,'interactive'),(43,'2024-09-25 22:27:55','MegaQuagga Administrator Admin Account',1,'interactive'),(44,'2024-09-25 22:28:44','MegaQuagga Administrator Admin Account',1,'interactive'),(45,'2024-09-25 22:28:52','MegaQuagga Administrator Admin Account',1,'interactive'),(46,'2024-09-25 22:29:06','MegaQuagga Administrator Admin Account',1,'interactive'),(47,'2024-09-25 22:29:14','MegaQuagga Administrator Admin Account',1,'interactive'),(48,'2024-12-21 23:29:36','MegaQuagga Administrator Admin Account',1,'interactive'),(49,'2024-12-21 23:30:34','MegaQuagga Administrator Admin Account',1,'interactive'),(50,'2024-12-21 23:41:03','MegaQuagga Administrator Admin Account',1,'interactive'),(51,'2024-12-21 23:41:41','MegaQuagga Administrator Admin Account',1,'interactive'),(52,'2024-12-21 23:46:14','MegaQuagga Administrator Admin Account',1,'interactive'),(53,'2024-12-21 23:46:28','MegaQuagga Administrator Admin Account',1,'interactive'),(54,'2024-12-21 23:47:34','MegaQuagga Administrator Admin Account',1,'interactive'),(55,'2024-12-21 23:47:48','MegaQuagga Administrator Admin Account',1,'interactive'),(56,'2024-12-21 23:48:25','MegaQuagga Administrator Admin Account',1,'interactive'),(57,'2024-12-21 23:48:38','MegaQuagga Administrator Admin Account',1,'interactive'),(58,'2024-12-21 23:49:32','MegaQuagga Administrator Admin Account',1,'interactive'),(59,'2024-12-21 23:49:51','MegaQuagga Administrator Admin Account',1,'interactive'),(60,'2024-12-21 23:51:06','MegaQuagga Administrator Admin Account',1,'interactive'),(61,'2024-12-21 23:51:17','MegaQuagga Administrator Admin Account',1,'interactive'),(62,'2024-12-21 23:52:45','MegaQuagga Administrator Admin Account',1,'interactive'),(63,'2024-12-21 23:52:54','MegaQuagga Administrator Admin Account',1,'interactive'),(64,'2024-12-21 23:53:31','MegaQuagga Administrator Admin Account',1,'interactive'),(65,'2024-12-21 23:53:39','MegaQuagga Administrator Admin Account',1,'interactive'),(66,'2024-12-31 23:07:09','MegaQuagga Administrator Admin Account',1,'interactive'),(67,'2024-12-31 23:08:37','MegaQuagga Administrator Admin Account',1,'interactive'),(68,'2024-12-31 23:18:40','MegaQuagga Administrator Admin Account',1,'interactive'),(69,'2024-12-31 23:19:17','MegaQuagga Administrator Admin Account',1,'interactive'),(70,'2024-12-31 23:48:14','MegaQuagga Administrator Admin Account',1,'interactive'),(71,'2024-12-31 23:50:59','MegaQuagga Administrator Admin Account',1,'interactive'),(72,'2024-12-31 23:52:56','MegaQuagga Administrator Admin Account',1,'interactive'),(73,'2025-01-01 00:08:09','MegaQuagga Administrator Admin Account',1,'interactive'),(74,'2025-01-01 00:09:46','MegaQuagga Administrator Admin Account',1,'interactive'),(75,'2025-01-01 00:11:33','MegaQuagga Administrator Admin Account',1,'interactive'),(76,'2025-01-01 00:16:07','MegaQuagga Administrator Admin Account',1,'interactive'),(77,'2025-01-01 00:31:35','MegaQuagga Administrator Admin Account',1,'interactive'),(78,'2025-01-01 02:18:20','MegaQuagga Administrator Admin Account',1,'interactive'),(79,'2025-01-01 02:44:19','MegaQuagga Administrator Admin Account',1,'interactive'),(80,'2025-01-01 02:46:46','MegaQuagga Administrator Admin Account',1,'interactive'),(81,'2025-01-01 02:48:12','MegaQuagga Administrator Admin Account',1,'interactive'),(82,'2025-01-01 02:49:24','MegaQuagga Administrator Admin Account',1,'interactive'),(83,'2025-01-01 02:53:45','MegaQuagga Administrator Admin Account',1,'interactive'),(84,'2025-01-01 02:56:48','MegaQuagga Administrator Admin Account',1,'interactive'),(85,'2025-01-01 02:58:50','MegaQuagga Administrator Admin Account',1,'interactive'),(86,'2025-01-01 02:59:37','MegaQuagga Administrator Admin Account',1,'interactive'),(87,'2025-01-01 03:00:34','MegaQuagga Administrator Admin Account',1,'interactive'),(88,'2025-01-01 03:01:20','MegaQuagga Administrator Admin Account',1,'interactive'),(89,'2025-01-01 03:06:42','MegaQuagga Administrator Admin Account',1,'interactive'),(90,'2025-01-01 03:08:43','MegaQuagga Administrator Admin Account',1,'interactive'),(91,'2025-01-01 03:10:17','MegaQuagga Administrator Admin Account',1,'interactive'),(92,'2025-01-01 03:14:50','MegaQuagga Administrator Admin Account',1,'interactive'),(93,'2025-01-01 03:17:44','MegaQuagga Administrator Admin Account',1,'interactive'),(94,'2025-01-01 03:18:28','MegaQuagga Administrator Admin Account',1,'interactive'),(95,'2025-01-01 03:20:18','MegaQuagga Administrator Admin Account',1,'interactive'),(96,'2025-01-01 03:21:03','MegaQuagga Administrator Admin Account',1,'interactive'),(97,'2025-01-01 03:21:47','MegaQuagga Administrator Admin Account',1,'interactive'),(98,'2025-01-01 03:23:32','MegaQuagga Administrator Admin Account',1,'interactive'),(99,'2025-01-01 03:26:02','MegaQuagga Administrator Admin Account',1,'interactive'),(100,'2025-01-01 03:29:19','MegaQuagga Administrator Admin Account',1,'interactive'),(101,'2025-01-01 03:31:23','MegaQuagga Administrator Admin Account',1,'interactive'),(102,'2025-01-01 03:33:34','MegaQuagga Administrator Admin Account',1,'interactive'),(103,'2025-01-01 03:35:50','MegaQuagga Administrator Admin Account',1,'interactive'),(104,'2025-01-01 03:38:17','MegaQuagga Administrator Admin Account',1,'interactive'),(105,'2025-01-01 03:39:26','MegaQuagga Administrator Admin Account',1,'interactive'),(106,'2025-01-01 03:40:35','MegaQuagga Administrator Admin Account',1,'interactive'),(107,'2025-01-01 03:41:19','MegaQuagga Administrator Admin Account',1,'interactive'),(108,'2025-01-01 03:41:57','MegaQuagga Administrator Admin Account',1,'interactive'),(109,'2025-01-01 03:45:49','MegaQuagga Administrator Admin Account',1,'interactive'),(110,'2025-01-01 03:47:37','MegaQuagga Administrator Admin Account',1,'interactive'),(111,'2025-01-01 03:49:27','MegaQuagga Administrator Admin Account',1,'interactive'),(112,'2025-01-01 03:51:25','MegaQuagga Administrator Admin Account',1,'interactive'),(113,'2025-01-01 03:53:54','MegaQuagga Administrator Admin Account',1,'interactive'),(114,'2025-01-02 03:37:51','MegaQuagga Administrator Admin Account',1,'interactive'),(115,'2025-01-02 03:40:53','MegaQuagga Administrator Admin Account',1,'interactive'),(116,'2025-01-02 03:54:36','MegaQuagga Administrator Admin Account',1,'interactive'),(117,'2025-01-02 03:55:18','MegaQuagga Administrator Admin Account',1,'interactive'),(118,'2025-01-02 03:57:39','MegaQuagga Administrator Admin Account',1,'interactive'),(119,'2025-01-02 03:59:03','MegaQuagga Administrator Admin Account',1,'interactive'),(120,'2025-01-02 03:59:42','MegaQuagga Administrator Admin Account',1,'interactive'),(121,'2025-01-02 04:00:38','MegaQuagga Administrator Admin Account',1,'interactive'),(122,'2025-01-02 04:01:35','MegaQuagga Administrator Admin Account',1,'interactive'),(123,'2025-01-02 04:02:17','MegaQuagga Administrator Admin Account',1,'interactive'),(124,'2025-01-02 04:02:47','MegaQuagga Administrator Admin Account',1,'interactive'),(125,'2025-01-02 04:03:29','MegaQuagga Administrator Admin Account',1,'interactive'),(126,'2025-01-02 04:04:19','MegaQuagga Administrator Admin Account',1,'interactive'),(127,'2025-01-02 04:05:05','MegaQuagga Administrator Admin Account',1,'interactive'),(128,'2025-01-02 04:05:43','MegaQuagga Administrator Admin Account',1,'interactive'),(129,'2025-01-02 04:08:42','MegaQuagga Administrator Admin Account',1,'interactive'),(130,'2025-01-02 04:22:19','MegaQuagga Administrator Admin Account',1,'interactive'),(131,'2025-01-02 04:22:49','MegaQuagga Administrator Admin Account',1,'interactive'),(132,'2025-01-02 04:28:58','MegaQuagga Administrator Admin Account',1,'interactive'),(133,'2025-01-02 04:29:51','MegaQuagga Administrator Admin Account',1,'interactive'),(134,'2025-01-02 04:30:33','MegaQuagga Administrator Admin Account',1,'interactive'),(135,'2025-01-02 04:34:28','MegaQuagga Administrator Admin Account',1,'interactive'),(136,'2025-01-02 04:34:58','MegaQuagga Administrator Admin Account',1,'interactive'),(137,'2025-01-02 04:35:31','MegaQuagga Administrator Admin Account',1,'interactive'),(138,'2025-01-02 04:37:04','MegaQuagga Administrator Admin Account',1,'interactive'),(139,'2025-01-02 04:37:39','MegaQuagga Administrator Admin Account',1,'interactive'),(140,'2025-01-02 04:39:30','MegaQuagga Administrator Admin Account',1,'interactive'),(141,'2025-01-02 04:44:12','MegaQuagga Administrator Admin Account',1,'interactive'),(142,'2025-01-02 04:44:59','MegaQuagga Administrator Admin Account',1,'interactive'),(143,'2025-01-02 04:45:37','MegaQuagga Administrator Admin Account',1,'interactive'),(144,'2025-01-02 04:46:07','MegaQuagga Administrator Admin Account',1,'interactive'),(145,'2025-01-02 04:46:56','MegaQuagga Administrator Admin Account',1,'interactive'),(146,'2025-01-02 04:52:14','MegaQuagga Administrator Admin Account',1,'interactive'),(147,'2025-01-02 04:55:52','MegaQuagga Administrator Admin Account',1,'interactive'),(148,'2025-01-02 04:55:57','MegaQuagga Administrator Admin Account',1,'interactive'),(149,'2025-01-02 04:57:21','MegaQuagga Administrator Admin Account',1,'interactive'),(150,'2025-01-02 04:57:24','MegaQuagga Administrator Admin Account',1,'interactive'),(151,'2025-01-02 22:18:04','MegaQuagga Administrator Admin Account',1,'interactive'),(152,'2025-01-02 22:18:09','MegaQuagga Administrator Admin Account',1,'interactive'),(153,'2025-01-02 22:19:43','MegaQuagga Administrator Admin Account',1,'interactive'),(154,'2025-01-02 22:21:21','MegaQuagga Administrator Admin Account',1,'interactive'),(155,'2025-01-02 22:21:24','MegaQuagga Administrator Admin Account',1,'interactive'),(156,'2025-01-02 22:22:39','MegaQuagga Administrator Admin Account',1,'interactive'),(157,'2025-01-02 22:22:41','MegaQuagga Administrator Admin Account',1,'interactive'),(158,'2025-01-02 22:23:27','MegaQuagga Administrator Admin Account',1,'interactive'),(159,'2025-01-02 22:23:34','MegaQuagga Administrator Admin Account',1,'interactive'),(160,'2025-01-02 22:30:29','MegaQuagga Administrator Admin Account',1,'interactive'),(161,'2025-01-02 22:31:34','MegaQuagga Administrator Admin Account',1,'interactive'),(162,'2025-01-02 22:31:39','MegaQuagga Administrator Admin Account',1,'interactive'),(163,'2025-01-02 22:32:50','MegaQuagga Administrator Admin Account',1,'interactive'),(164,'2025-01-02 22:32:51','MegaQuagga Administrator Admin Account',1,'interactive'),(165,'2025-01-02 22:34:17','MegaQuagga Administrator Admin Account',1,'interactive'),(166,'2025-01-02 22:35:25','MegaQuagga Administrator Admin Account',1,'interactive'),(167,'2025-01-02 22:42:51','MegaQuagga Administrator Admin Account',1,'interactive'),(168,'2025-01-02 22:45:22','MegaQuagga Administrator Admin Account',1,'interactive'),(169,'2025-01-02 22:46:20','MegaQuagga Administrator Admin Account',1,'interactive'),(170,'2025-01-02 22:53:41','MegaQuagga Administrator Admin Account',1,'interactive'),(171,'2025-01-02 23:40:02','MegaQuagga Administrator Admin Account',1,'interactive'),(172,'2025-01-02 23:41:51','MegaQuagga Administrator Admin Account',1,'interactive'),(173,'2025-01-02 23:44:28','MegaQuagga Administrator Admin Account',1,'interactive'),(174,'2025-01-02 23:46:01','MegaQuagga Administrator Admin Account',1,'interactive'),(175,'2025-01-03 22:23:07','MegaQuagga Administrator Admin Account',1,'interactive'),(176,'2025-01-03 23:35:07','MegaQuagga Administrator Admin Account',1,'interactive'),(177,'2025-01-03 23:35:23','MegaQuagga Administrator Admin Account',1,'interactive'),(178,'2025-01-03 23:36:57','MegaQuagga Administrator Admin Account',1,'interactive'),(179,'2025-01-03 23:37:04','MegaQuagga Administrator Admin Account',1,'interactive'),(180,'2025-01-03 23:38:20','MegaQuagga Administrator Admin Account',1,'interactive'),(181,'2025-01-03 23:38:37','MegaQuagga Administrator Admin Account',1,'interactive'),(182,'2025-01-03 23:41:07','MegaQuagga Administrator Admin Account',1,'interactive'),(183,'2025-01-03 23:41:09','MegaQuagga Administrator Admin Account',1,'interactive'),(184,'2025-01-03 23:43:58','MegaQuagga Administrator Admin Account',1,'interactive'),(185,'2025-01-03 23:44:10','MegaQuagga Administrator Admin Account',1,'interactive'),(186,'2025-01-03 23:45:21','MegaQuagga Administrator Admin Account',1,'interactive'),(187,'2025-01-03 23:46:13','MegaQuagga Administrator Admin Account',1,'interactive'),(188,'2025-01-04 20:51:10','MegaQuagga Administrator Admin Account',1,'interactive'),(189,'2025-01-04 20:51:22','MegaQuagga Administrator Admin Account',1,'interactive'),(190,'2025-01-04 20:55:47','MegaQuagga Administrator Admin Account',1,'interactive'),(191,'2025-01-04 20:56:03','MegaQuagga Administrator Admin Account',1,'interactive'),(192,'2025-01-04 20:56:48','MegaQuagga Administrator Admin Account',1,'interactive'),(193,'2025-01-04 21:02:00','MegaQuagga Administrator Admin Account',1,'interactive'),(194,'2025-01-04 21:02:10','MegaQuagga Administrator Admin Account',1,'interactive'),(195,'2025-01-04 21:04:17','MegaQuagga Administrator Admin Account',1,'interactive'),(196,'2025-01-04 21:04:21','MegaQuagga Administrator Admin Account',1,'interactive'),(197,'2025-01-04 21:05:25','MegaQuagga Administrator Admin Account',1,'interactive'),(198,'2025-01-04 21:05:39','MegaQuagga Administrator Admin Account',1,'interactive'),(199,'2025-01-04 21:08:29','MegaQuagga Administrator Admin Account',1,'interactive'),(200,'2025-01-04 21:08:34','MegaQuagga Administrator Admin Account',1,'interactive'),(201,'2025-01-04 21:10:48','MegaQuagga Administrator Admin Account',1,'interactive'),(202,'2025-01-04 21:10:55','MegaQuagga Administrator Admin Account',1,'interactive'),(203,'2025-01-04 21:14:29','MegaQuagga Administrator Admin Account',1,'interactive'),(204,'2025-01-04 21:14:33','MegaQuagga Administrator Admin Account',1,'interactive'),(205,'2025-01-04 21:16:34','MegaQuagga Administrator Admin Account',1,'interactive'),(206,'2025-01-04 21:16:36','MegaQuagga Administrator Admin Account',1,'interactive'),(207,'2025-01-04 21:18:39','MegaQuagga Administrator Admin Account',1,'interactive'),(208,'2025-01-04 21:18:44','MegaQuagga Administrator Admin Account',1,'interactive'),(209,'2025-01-04 21:19:55','MegaQuagga Administrator Admin Account',1,'interactive'),(210,'2025-01-04 21:20:01','MegaQuagga Administrator Admin Account',1,'interactive'),(211,'2025-01-04 21:21:37','MegaQuagga Administrator Admin Account',1,'interactive'),(212,'2025-01-04 21:23:01','MegaQuagga Administrator Admin Account',1,'interactive'),(213,'2025-01-04 21:23:28','MegaQuagga Administrator Admin Account',1,'interactive'),(214,'2025-01-04 21:24:58','MegaQuagga Administrator Admin Account',1,'interactive'),(215,'2025-01-04 21:25:05','MegaQuagga Administrator Admin Account',1,'interactive'),(216,'2025-01-04 21:26:25','MegaQuagga Administrator Admin Account',1,'interactive'),(217,'2025-01-04 21:27:57','MegaQuagga Administrator Admin Account',1,'interactive'),(218,'2025-01-04 21:28:34','MegaQuagga Administrator Admin Account',1,'interactive'),(219,'2025-01-04 21:29:11','MegaQuagga Administrator Admin Account',1,'interactive'),(220,'2025-01-04 21:29:41','MegaQuagga Administrator Admin Account',1,'interactive'),(221,'2025-01-04 21:30:41','MegaQuagga Administrator Admin Account',1,'interactive'),(222,'2025-01-04 21:30:59','MegaQuagga Administrator Admin Account',1,'interactive'),(223,'2025-01-04 21:32:48','MegaQuagga Administrator Admin Account',1,'interactive'),(224,'2025-01-04 21:32:51','MegaQuagga Administrator Admin Account',1,'interactive'),(225,'2025-01-04 21:33:53','MegaQuagga Administrator Admin Account',1,'interactive'),(226,'2025-01-04 21:34:49','MegaQuagga Administrator Admin Account',1,'interactive'),(227,'2025-01-04 21:34:53','MegaQuagga Administrator Admin Account',1,'interactive'),(228,'2025-01-04 21:35:25','MegaQuagga Administrator Admin Account',1,'interactive'),(229,'2025-01-04 21:35:51','MegaQuagga Administrator Admin Account',1,'interactive'),(230,'2025-01-04 21:37:01','MegaQuagga Administrator Admin Account',1,'interactive'),(231,'2025-01-04 21:37:29','MegaQuagga Administrator Admin Account',1,'interactive'),(232,'2025-01-04 21:37:53','MegaQuagga Administrator Admin Account',1,'interactive'),(233,'2025-01-04 21:38:08','MegaQuagga Administrator Admin Account',1,'interactive'),(234,'2025-01-04 21:38:27','MegaQuagga Administrator Admin Account',1,'interactive'),(235,'2025-01-04 21:39:13','MegaQuagga Administrator Admin Account',1,'interactive'),(236,'2025-01-04 21:39:36','MegaQuagga Administrator Admin Account',1,'interactive'),(237,'2025-01-04 21:39:58','MegaQuagga Administrator Admin Account',1,'interactive'),(238,'2025-01-04 21:40:22','MegaQuagga Administrator Admin Account',1,'interactive'),(239,'2025-01-04 21:40:53','MegaQuagga Administrator Admin Account',1,'interactive'),(240,'2025-01-04 21:41:51','MegaQuagga Administrator Admin Account',1,'interactive'),(241,'2025-01-04 21:42:09','MegaQuagga Administrator Admin Account',1,'interactive'),(242,'2025-01-04 21:42:34','MegaQuagga Administrator Admin Account',1,'interactive'),(243,'2025-01-04 21:42:55','MegaQuagga Administrator Admin Account',1,'interactive'),(244,'2025-01-04 21:43:19','MegaQuagga Administrator Admin Account',1,'interactive'),(245,'2025-01-04 21:44:09','MegaQuagga Administrator Admin Account',1,'interactive'),(246,'2025-01-04 21:44:18','MegaQuagga Administrator Admin Account',1,'interactive'),(247,'2025-01-04 21:44:34','MegaQuagga Administrator Admin Account',1,'interactive'),(248,'2025-01-04 21:45:05','MegaQuagga Administrator Admin Account',1,'interactive'),(249,'2025-01-04 21:45:24','MegaQuagga Administrator Admin Account',1,'interactive'),(250,'2025-01-04 21:45:38','MegaQuagga Administrator Admin Account',1,'interactive'),(251,'2025-01-04 21:46:58','MegaQuagga Administrator Admin Account',1,'interactive'),(252,'2025-01-04 21:47:04','MegaQuagga Administrator Admin Account',1,'interactive'),(253,'2025-01-04 21:48:41','MegaQuagga Administrator Admin Account',1,'interactive'),(254,'2025-01-04 21:48:45','MegaQuagga Administrator Admin Account',1,'interactive'),(255,'2025-01-04 21:49:44','MegaQuagga Administrator Admin Account',1,'interactive'),(256,'2025-01-04 21:50:04','MegaQuagga Administrator Admin Account',1,'interactive'),(257,'2025-01-04 21:50:20','MegaQuagga Administrator Admin Account',1,'interactive'),(258,'2025-01-04 21:50:47','MegaQuagga Administrator Admin Account',1,'interactive'),(259,'2025-01-04 21:51:10','MegaQuagga Administrator Admin Account',1,'interactive'),(260,'2025-01-04 21:51:53','MegaQuagga Administrator Admin Account',1,'interactive'),(261,'2025-01-04 21:52:13','MegaQuagga Administrator Admin Account',1,'interactive'),(262,'2025-01-04 21:52:27','MegaQuagga Administrator Admin Account',1,'interactive'),(263,'2025-01-04 21:52:41','MegaQuagga Administrator Admin Account',1,'interactive'),(264,'2025-01-04 21:52:53','MegaQuagga Administrator Admin Account',1,'interactive'),(265,'2025-01-04 21:53:41','MegaQuagga Administrator Admin Account',1,'interactive'),(266,'2025-01-04 21:54:39','MegaQuagga Administrator Admin Account',1,'interactive'),(267,'2025-01-04 21:54:55','MegaQuagga Administrator Admin Account',1,'interactive'),(268,'2025-01-04 21:55:16','MegaQuagga Administrator Admin Account',1,'interactive'),(269,'2025-01-04 21:55:29','MegaQuagga Administrator Admin Account',1,'interactive'),(270,'2025-01-04 21:56:33','MegaQuagga Administrator Admin Account',1,'interactive'),(271,'2025-01-04 21:56:51','MegaQuagga Administrator Admin Account',1,'interactive'),(272,'2025-01-04 21:58:38','MegaQuagga Administrator Admin Account',1,'interactive'),(273,'2025-01-04 21:58:41','MegaQuagga Administrator Admin Account',1,'interactive'),(274,'2025-01-04 21:59:06','MegaQuagga Administrator Admin Account',1,'interactive'),(275,'2025-01-04 21:59:50','MegaQuagga Administrator Admin Account',1,'interactive'),(276,'2025-01-04 22:00:08','MegaQuagga Administrator Admin Account',1,'interactive'),(277,'2025-01-04 22:00:35','MegaQuagga Administrator Admin Account',1,'interactive'),(278,'2025-01-04 22:00:59','MegaQuagga Administrator Admin Account',1,'interactive'),(279,'2025-01-04 22:01:23','MegaQuagga Administrator Admin Account',1,'interactive'),(280,'2025-01-04 22:28:02','MegaQuagga Administrator Admin Account',1,'interactive'),(281,'2025-01-04 22:28:40','MegaQuagga Administrator Admin Account',1,'interactive'),(282,'2025-01-04 22:29:50','MegaQuagga Administrator Admin Account',1,'interactive'),(283,'2025-01-04 22:31:09','MegaQuagga Administrator Admin Account',1,'interactive'),(284,'2025-01-04 22:31:55','MegaQuagga Administrator Admin Account',1,'interactive'),(285,'2025-01-04 22:32:53','MegaQuagga Administrator Admin Account',1,'interactive'),(286,'2025-01-04 22:34:32','MegaQuagga Administrator Admin Account',1,'interactive');
/*!40000 ALTER TABLE `priv_change` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop`
--

DROP TABLE IF EXISTS `priv_changeop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_changeop` (
  `id` int NOT NULL AUTO_INCREMENT,
  `changeid` int DEFAULT '0',
  `objclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `objkey` int DEFAULT '0',
  `optype` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'CMDBChangeOp',
  PRIMARY KEY (`id`),
  KEY `changeid` (`changeid`),
  KEY `optype` (`optype`(95)),
  KEY `objclass_objkey` (`objclass`(95),`objkey`)
) ENGINE=InnoDB AUTO_INCREMENT=762 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop`
--

LOCK TABLES `priv_changeop` WRITE;
/*!40000 ALTER TABLE `priv_changeop` DISABLE KEYS */;
INSERT INTO `priv_changeop` VALUES (1,1,'TriggerOnObjectMention',1,'CMDBChangeOpCreate'),(2,1,'TriggerOnObjectMention',2,'CMDBChangeOpCreate'),(3,1,'TriggerOnObjectMention',3,'CMDBChangeOpCreate'),(5,1,'TriggerOnObjectMention',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(6,1,'lnkTriggerAction',1,'CMDBChangeOpCreate'),(8,1,'TriggerOnObjectMention',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(9,1,'lnkTriggerAction',2,'CMDBChangeOpCreate'),(11,1,'TriggerOnObjectMention',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(12,1,'lnkTriggerAction',3,'CMDBChangeOpCreate'),(13,1,'ActionEmail',1,'CMDBChangeOpCreate'),(14,1,'ActionNewsroom',2,'CMDBChangeOpCreate'),(15,1,'ActionNewsroom',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(16,1,'TriggerOnObjectMention',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(17,1,'lnkTriggerAction',4,'CMDBChangeOpCreate'),(18,1,'ActionNewsroom',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(19,1,'TriggerOnObjectMention',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(20,1,'lnkTriggerAction',5,'CMDBChangeOpCreate'),(21,1,'ActionNewsroom',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(22,1,'TriggerOnObjectMention',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(23,1,'lnkTriggerAction',6,'CMDBChangeOpCreate'),(24,1,'TriggerOnObjectMention',2,'CMDBChangeOpSetAttributeScalar'),(25,1,'TriggerOnObjectMention',1,'CMDBChangeOpSetAttributeScalar'),(26,1,'TriggerOnObjectMention',3,'CMDBChangeOpSetAttributeScalar'),(27,1,'ActionNewsroom',3,'CMDBChangeOpCreate'),(28,1,'ActionNewsroom',4,'CMDBChangeOpCreate'),(29,1,'QueryOQL',1,'CMDBChangeOpCreate'),(30,1,'QueryOQL',2,'CMDBChangeOpCreate'),(31,1,'QueryOQL',3,'CMDBChangeOpCreate'),(32,1,'QueryOQL',4,'CMDBChangeOpCreate'),(33,1,'QueryOQL',5,'CMDBChangeOpCreate'),(34,1,'QueryOQL',6,'CMDBChangeOpCreate'),(35,1,'QueryOQL',7,'CMDBChangeOpCreate'),(36,1,'QueryOQL',8,'CMDBChangeOpCreate'),(37,1,'QueryOQL',9,'CMDBChangeOpCreate'),(38,1,'QueryOQL',10,'CMDBChangeOpCreate'),(39,1,'QueryOQL',11,'CMDBChangeOpCreate'),(40,1,'QueryOQL',12,'CMDBChangeOpCreate'),(41,1,'QueryOQL',13,'CMDBChangeOpCreate'),(42,1,'URP_Profiles',1,'CMDBChangeOpCreate'),(43,1,'URP_Profiles',1024,'CMDBChangeOpCreate'),(44,1,'URP_Profiles',3,'CMDBChangeOpCreate'),(45,1,'URP_Profiles',4,'CMDBChangeOpCreate'),(46,1,'URP_Profiles',5,'CMDBChangeOpCreate'),(47,1,'URP_Profiles',6,'CMDBChangeOpCreate'),(48,1,'URP_Profiles',7,'CMDBChangeOpCreate'),(49,1,'URP_Profiles',8,'CMDBChangeOpCreate'),(50,1,'URP_Profiles',9,'CMDBChangeOpCreate'),(51,1,'URP_Profiles',10,'CMDBChangeOpCreate'),(52,1,'URP_Profiles',11,'CMDBChangeOpCreate'),(53,1,'URP_Profiles',2,'CMDBChangeOpCreate'),(54,1,'URP_Profiles',12,'CMDBChangeOpCreate'),(55,2,'Organization',1,'CMDBChangeOpCreate'),(56,2,'Person',1,'CMDBChangeOpCreate'),(58,2,'URP_Profiles',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(59,2,'URP_UserProfile',1,'CMDBChangeOpCreate'),(60,2,'Person',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(61,2,'UserLocal',1,'CMDBChangeOpCreate'),(62,3,'RemoteApplicationType',1,'CMDBChangeOpCreate'),(63,3,'RemoteApplicationType',2,'CMDBChangeOpCreate'),(64,3,'RemoteApplicationType',3,'CMDBChangeOpCreate'),(65,3,'RemoteApplicationType',4,'CMDBChangeOpCreate'),(66,3,'RemoteApplicationType',5,'CMDBChangeOpCreate'),(67,3,'RemoteApplicationType',6,'CMDBChangeOpCreate'),(68,3,'Brand',7,'CMDBChangeOpCreate'),(69,3,'Brand',8,'CMDBChangeOpCreate'),(70,3,'Brand',9,'CMDBChangeOpCreate'),(71,3,'Brand',10,'CMDBChangeOpCreate'),(72,3,'Brand',11,'CMDBChangeOpCreate'),(73,3,'Brand',12,'CMDBChangeOpCreate'),(74,3,'Brand',13,'CMDBChangeOpCreate'),(75,3,'Brand',14,'CMDBChangeOpCreate'),(76,3,'Brand',15,'CMDBChangeOpCreate'),(77,3,'Brand',16,'CMDBChangeOpCreate'),(78,3,'Brand',17,'CMDBChangeOpCreate'),(79,3,'Brand',18,'CMDBChangeOpCreate'),(80,3,'Brand',19,'CMDBChangeOpCreate'),(81,3,'OSFamily',20,'CMDBChangeOpCreate'),(82,3,'OSFamily',21,'CMDBChangeOpCreate'),(83,3,'OSFamily',22,'CMDBChangeOpCreate'),(84,3,'OSFamily',23,'CMDBChangeOpCreate'),(85,3,'OSFamily',24,'CMDBChangeOpCreate'),(86,3,'OSFamily',25,'CMDBChangeOpCreate'),(87,3,'OSFamily',26,'CMDBChangeOpCreate'),(88,3,'OSFamily',27,'CMDBChangeOpCreate'),(89,3,'OSFamily',28,'CMDBChangeOpCreate'),(90,3,'OSVersion',29,'CMDBChangeOpCreate'),(91,3,'OSVersion',30,'CMDBChangeOpCreate'),(92,3,'OSVersion',31,'CMDBChangeOpCreate'),(93,3,'OSVersion',32,'CMDBChangeOpCreate'),(94,3,'OSVersion',33,'CMDBChangeOpCreate'),(95,3,'OSVersion',34,'CMDBChangeOpCreate'),(96,3,'OSVersion',35,'CMDBChangeOpCreate'),(97,3,'OSVersion',36,'CMDBChangeOpCreate'),(98,3,'OSVersion',37,'CMDBChangeOpCreate'),(99,3,'OSVersion',38,'CMDBChangeOpCreate'),(100,3,'OSVersion',39,'CMDBChangeOpCreate'),(101,3,'OSVersion',40,'CMDBChangeOpCreate'),(102,3,'OSVersion',41,'CMDBChangeOpCreate'),(103,3,'OSVersion',42,'CMDBChangeOpCreate'),(104,4,'ModuleInstallation',1,'CMDBChangeOpCreate'),(105,4,'ModuleInstallation',2,'CMDBChangeOpCreate'),(106,4,'ModuleInstallation',3,'CMDBChangeOpCreate'),(107,4,'ModuleInstallation',4,'CMDBChangeOpCreate'),(108,4,'ModuleInstallation',5,'CMDBChangeOpCreate'),(109,4,'ModuleInstallation',6,'CMDBChangeOpCreate'),(110,4,'ModuleInstallation',7,'CMDBChangeOpCreate'),(111,4,'ModuleInstallation',8,'CMDBChangeOpCreate'),(112,4,'ModuleInstallation',9,'CMDBChangeOpCreate'),(113,4,'ModuleInstallation',10,'CMDBChangeOpCreate'),(114,4,'ModuleInstallation',11,'CMDBChangeOpCreate'),(115,4,'ModuleInstallation',12,'CMDBChangeOpCreate'),(116,4,'ModuleInstallation',13,'CMDBChangeOpCreate'),(117,4,'ModuleInstallation',14,'CMDBChangeOpCreate'),(118,4,'ModuleInstallation',15,'CMDBChangeOpCreate'),(119,4,'ModuleInstallation',16,'CMDBChangeOpCreate'),(120,4,'ModuleInstallation',17,'CMDBChangeOpCreate'),(121,4,'ModuleInstallation',18,'CMDBChangeOpCreate'),(122,4,'ModuleInstallation',19,'CMDBChangeOpCreate'),(123,4,'ModuleInstallation',20,'CMDBChangeOpCreate'),(124,4,'ModuleInstallation',21,'CMDBChangeOpCreate'),(125,4,'ModuleInstallation',22,'CMDBChangeOpCreate'),(126,4,'ModuleInstallation',23,'CMDBChangeOpCreate'),(127,4,'ModuleInstallation',24,'CMDBChangeOpCreate'),(128,4,'ModuleInstallation',25,'CMDBChangeOpCreate'),(129,4,'ModuleInstallation',26,'CMDBChangeOpCreate'),(130,4,'ModuleInstallation',27,'CMDBChangeOpCreate'),(131,4,'ModuleInstallation',28,'CMDBChangeOpCreate'),(132,4,'ModuleInstallation',29,'CMDBChangeOpCreate'),(133,4,'ModuleInstallation',30,'CMDBChangeOpCreate'),(134,4,'ModuleInstallation',31,'CMDBChangeOpCreate'),(135,4,'ModuleInstallation',32,'CMDBChangeOpCreate'),(136,4,'ModuleInstallation',33,'CMDBChangeOpCreate'),(137,4,'ModuleInstallation',34,'CMDBChangeOpCreate'),(138,4,'ModuleInstallation',35,'CMDBChangeOpCreate'),(139,4,'ModuleInstallation',36,'CMDBChangeOpCreate'),(140,4,'ModuleInstallation',37,'CMDBChangeOpCreate'),(141,4,'ModuleInstallation',38,'CMDBChangeOpCreate'),(142,4,'ModuleInstallation',39,'CMDBChangeOpCreate'),(143,4,'ModuleInstallation',40,'CMDBChangeOpCreate'),(144,4,'ModuleInstallation',41,'CMDBChangeOpCreate'),(145,4,'ModuleInstallation',42,'CMDBChangeOpCreate'),(146,4,'ModuleInstallation',43,'CMDBChangeOpCreate'),(147,4,'ModuleInstallation',44,'CMDBChangeOpCreate'),(148,4,'ExtensionInstallation',1,'CMDBChangeOpCreate'),(149,4,'ExtensionInstallation',2,'CMDBChangeOpCreate'),(150,4,'ExtensionInstallation',3,'CMDBChangeOpCreate'),(151,4,'ExtensionInstallation',4,'CMDBChangeOpCreate'),(152,4,'ExtensionInstallation',5,'CMDBChangeOpCreate'),(153,4,'ExtensionInstallation',6,'CMDBChangeOpCreate'),(154,4,'ExtensionInstallation',7,'CMDBChangeOpCreate'),(155,4,'ExtensionInstallation',8,'CMDBChangeOpCreate'),(156,4,'ExtensionInstallation',9,'CMDBChangeOpCreate'),(157,5,'URP_Profiles',20,'CMDBChangeOpCreate'),(158,5,'URP_Profiles',5323,'CMDBChangeOpCreate'),(159,6,'ModuleInstallation',45,'CMDBChangeOpCreate'),(160,6,'ModuleInstallation',46,'CMDBChangeOpCreate'),(161,6,'ModuleInstallation',47,'CMDBChangeOpCreate'),(162,6,'ModuleInstallation',48,'CMDBChangeOpCreate'),(163,6,'ModuleInstallation',49,'CMDBChangeOpCreate'),(164,6,'ModuleInstallation',50,'CMDBChangeOpCreate'),(165,6,'ModuleInstallation',51,'CMDBChangeOpCreate'),(166,6,'ModuleInstallation',52,'CMDBChangeOpCreate'),(167,6,'ModuleInstallation',53,'CMDBChangeOpCreate'),(168,6,'ModuleInstallation',54,'CMDBChangeOpCreate'),(169,6,'ModuleInstallation',55,'CMDBChangeOpCreate'),(170,6,'ModuleInstallation',56,'CMDBChangeOpCreate'),(171,6,'ModuleInstallation',57,'CMDBChangeOpCreate'),(172,6,'ModuleInstallation',58,'CMDBChangeOpCreate'),(173,6,'ModuleInstallation',59,'CMDBChangeOpCreate'),(174,6,'ModuleInstallation',60,'CMDBChangeOpCreate'),(175,6,'ModuleInstallation',61,'CMDBChangeOpCreate'),(176,6,'ModuleInstallation',62,'CMDBChangeOpCreate'),(177,6,'ModuleInstallation',63,'CMDBChangeOpCreate'),(178,6,'ModuleInstallation',64,'CMDBChangeOpCreate'),(179,6,'ModuleInstallation',65,'CMDBChangeOpCreate'),(180,6,'ModuleInstallation',66,'CMDBChangeOpCreate'),(181,6,'ModuleInstallation',67,'CMDBChangeOpCreate'),(182,6,'ModuleInstallation',68,'CMDBChangeOpCreate'),(183,6,'ModuleInstallation',69,'CMDBChangeOpCreate'),(184,6,'ModuleInstallation',70,'CMDBChangeOpCreate'),(185,6,'ModuleInstallation',71,'CMDBChangeOpCreate'),(186,6,'ModuleInstallation',72,'CMDBChangeOpCreate'),(187,6,'ModuleInstallation',73,'CMDBChangeOpCreate'),(188,6,'ModuleInstallation',74,'CMDBChangeOpCreate'),(189,6,'ModuleInstallation',75,'CMDBChangeOpCreate'),(190,6,'ModuleInstallation',76,'CMDBChangeOpCreate'),(191,6,'ModuleInstallation',77,'CMDBChangeOpCreate'),(192,6,'ModuleInstallation',78,'CMDBChangeOpCreate'),(193,6,'ModuleInstallation',79,'CMDBChangeOpCreate'),(194,6,'ModuleInstallation',80,'CMDBChangeOpCreate'),(195,6,'ModuleInstallation',81,'CMDBChangeOpCreate'),(196,6,'ModuleInstallation',82,'CMDBChangeOpCreate'),(197,6,'ModuleInstallation',83,'CMDBChangeOpCreate'),(198,6,'ModuleInstallation',84,'CMDBChangeOpCreate'),(199,6,'ModuleInstallation',85,'CMDBChangeOpCreate'),(200,6,'ModuleInstallation',86,'CMDBChangeOpCreate'),(201,6,'ModuleInstallation',87,'CMDBChangeOpCreate'),(202,6,'ModuleInstallation',88,'CMDBChangeOpCreate'),(203,6,'ModuleInstallation',89,'CMDBChangeOpCreate'),(204,6,'ModuleInstallation',90,'CMDBChangeOpCreate'),(205,6,'ModuleInstallation',91,'CMDBChangeOpCreate'),(206,6,'ModuleInstallation',92,'CMDBChangeOpCreate'),(207,6,'ModuleInstallation',93,'CMDBChangeOpCreate'),(208,6,'ModuleInstallation',94,'CMDBChangeOpCreate'),(209,6,'ModuleInstallation',95,'CMDBChangeOpCreate'),(210,6,'ModuleInstallation',96,'CMDBChangeOpCreate'),(211,6,'ModuleInstallation',97,'CMDBChangeOpCreate'),(212,6,'ModuleInstallation',98,'CMDBChangeOpCreate'),(213,6,'ModuleInstallation',99,'CMDBChangeOpCreate'),(214,6,'ExtensionInstallation',10,'CMDBChangeOpCreate'),(215,6,'ExtensionInstallation',11,'CMDBChangeOpCreate'),(216,6,'ExtensionInstallation',12,'CMDBChangeOpCreate'),(217,6,'ExtensionInstallation',13,'CMDBChangeOpCreate'),(218,6,'ExtensionInstallation',14,'CMDBChangeOpCreate'),(219,6,'ExtensionInstallation',15,'CMDBChangeOpCreate'),(220,6,'ExtensionInstallation',16,'CMDBChangeOpCreate'),(221,6,'ExtensionInstallation',17,'CMDBChangeOpCreate'),(222,6,'ExtensionInstallation',18,'CMDBChangeOpCreate'),(223,6,'ExtensionInstallation',19,'CMDBChangeOpCreate'),(224,7,'Organization',1,'CMDBChangeOpSetAttributeScalar'),(225,8,'IPConfig',1,'CMDBChangeOpCreate'),(226,8,'IPUsage',43,'CMDBChangeOpCreate'),(227,8,'IPUsage',44,'CMDBChangeOpCreate'),(228,8,'IPUsage',45,'CMDBChangeOpCreate'),(229,9,'IPBlockType',46,'CMDBChangeOpCreate'),(230,10,'ModuleInstallation',100,'CMDBChangeOpCreate'),(231,10,'ModuleInstallation',101,'CMDBChangeOpCreate'),(232,10,'ModuleInstallation',102,'CMDBChangeOpCreate'),(233,10,'ModuleInstallation',103,'CMDBChangeOpCreate'),(234,10,'ModuleInstallation',104,'CMDBChangeOpCreate'),(235,10,'ModuleInstallation',105,'CMDBChangeOpCreate'),(236,10,'ModuleInstallation',106,'CMDBChangeOpCreate'),(237,10,'ModuleInstallation',107,'CMDBChangeOpCreate'),(238,10,'ModuleInstallation',108,'CMDBChangeOpCreate'),(239,10,'ModuleInstallation',109,'CMDBChangeOpCreate'),(240,10,'ModuleInstallation',110,'CMDBChangeOpCreate'),(241,10,'ModuleInstallation',111,'CMDBChangeOpCreate'),(242,10,'ModuleInstallation',112,'CMDBChangeOpCreate'),(243,10,'ModuleInstallation',113,'CMDBChangeOpCreate'),(244,10,'ModuleInstallation',114,'CMDBChangeOpCreate'),(245,10,'ModuleInstallation',115,'CMDBChangeOpCreate'),(246,10,'ModuleInstallation',116,'CMDBChangeOpCreate'),(247,10,'ModuleInstallation',117,'CMDBChangeOpCreate'),(248,10,'ModuleInstallation',118,'CMDBChangeOpCreate'),(249,10,'ModuleInstallation',119,'CMDBChangeOpCreate'),(250,10,'ModuleInstallation',120,'CMDBChangeOpCreate'),(251,10,'ModuleInstallation',121,'CMDBChangeOpCreate'),(252,10,'ModuleInstallation',122,'CMDBChangeOpCreate'),(253,10,'ModuleInstallation',123,'CMDBChangeOpCreate'),(254,10,'ModuleInstallation',124,'CMDBChangeOpCreate'),(255,10,'ModuleInstallation',125,'CMDBChangeOpCreate'),(256,10,'ModuleInstallation',126,'CMDBChangeOpCreate'),(257,10,'ModuleInstallation',127,'CMDBChangeOpCreate'),(258,10,'ModuleInstallation',128,'CMDBChangeOpCreate'),(259,10,'ModuleInstallation',129,'CMDBChangeOpCreate'),(260,10,'ModuleInstallation',130,'CMDBChangeOpCreate'),(261,10,'ModuleInstallation',131,'CMDBChangeOpCreate'),(262,10,'ModuleInstallation',132,'CMDBChangeOpCreate'),(263,10,'ModuleInstallation',133,'CMDBChangeOpCreate'),(264,10,'ModuleInstallation',134,'CMDBChangeOpCreate'),(265,10,'ModuleInstallation',135,'CMDBChangeOpCreate'),(266,10,'ModuleInstallation',136,'CMDBChangeOpCreate'),(267,10,'ModuleInstallation',137,'CMDBChangeOpCreate'),(268,10,'ModuleInstallation',138,'CMDBChangeOpCreate'),(269,10,'ModuleInstallation',139,'CMDBChangeOpCreate'),(270,10,'ModuleInstallation',140,'CMDBChangeOpCreate'),(271,10,'ModuleInstallation',141,'CMDBChangeOpCreate'),(272,10,'ModuleInstallation',142,'CMDBChangeOpCreate'),(273,10,'ModuleInstallation',143,'CMDBChangeOpCreate'),(274,10,'ModuleInstallation',144,'CMDBChangeOpCreate'),(275,10,'ModuleInstallation',145,'CMDBChangeOpCreate'),(276,10,'ModuleInstallation',146,'CMDBChangeOpCreate'),(277,10,'ModuleInstallation',147,'CMDBChangeOpCreate'),(278,10,'ModuleInstallation',148,'CMDBChangeOpCreate'),(279,10,'ModuleInstallation',149,'CMDBChangeOpCreate'),(280,10,'ModuleInstallation',150,'CMDBChangeOpCreate'),(281,10,'ModuleInstallation',151,'CMDBChangeOpCreate'),(282,10,'ModuleInstallation',152,'CMDBChangeOpCreate'),(283,10,'ModuleInstallation',153,'CMDBChangeOpCreate'),(284,10,'ModuleInstallation',154,'CMDBChangeOpCreate'),(285,10,'ModuleInstallation',155,'CMDBChangeOpCreate'),(286,10,'ExtensionInstallation',20,'CMDBChangeOpCreate'),(287,10,'ExtensionInstallation',21,'CMDBChangeOpCreate'),(288,10,'ExtensionInstallation',22,'CMDBChangeOpCreate'),(289,10,'ExtensionInstallation',23,'CMDBChangeOpCreate'),(290,10,'ExtensionInstallation',24,'CMDBChangeOpCreate'),(291,10,'ExtensionInstallation',25,'CMDBChangeOpCreate'),(292,10,'ExtensionInstallation',26,'CMDBChangeOpCreate'),(293,10,'ExtensionInstallation',27,'CMDBChangeOpCreate'),(294,10,'ExtensionInstallation',28,'CMDBChangeOpCreate'),(295,10,'ExtensionInstallation',29,'CMDBChangeOpCreate'),(296,10,'ExtensionInstallation',30,'CMDBChangeOpCreate'),(297,11,'Person',1,'CMDBChangeOpSetAttributeScalar'),(298,11,'Person',1,'CMDBChangeOpSetAttributeScalar'),(299,12,'IPConfig',1,'CMDBChangeOpSetAttributeScalar'),(300,12,'IPConfig',1,'CMDBChangeOpSetAttributeScalar'),(311,23,'Location',1,'CMDBChangeOpCreate'),(312,24,'NetworkDeviceType',47,'CMDBChangeOpCreate'),(313,25,'NetworkDevice',1,'CMDBChangeOpCreate'),(314,26,'NetworkDevice',2,'CMDBChangeOpCreate'),(315,27,'OSVersion',48,'CMDBChangeOpCreate'),(316,28,'Domain',1,'CMDBChangeOpCreate'),(318,30,'Software',1,'CMDBChangeOpCreate'),(320,31,'WebServer',4,'CMDBChangeOpCreate'),(322,31,'PhysicalInterface',1,'CMDBChangeOpCreate'),(323,31,'Server',3,'CMDBChangeOpCreate'),(326,34,'UserLocal',1,'CMDBChangeOpSetAttributeOneWayPassword'),(327,34,'UserLocal',1,'CMDBChangeOpSetAttributeScalar'),(328,35,'IPObject',13,'CMDBChangeOpDelete'),(329,36,'IPObject',12,'CMDBChangeOpDelete'),(330,37,'IPObject',4,'CMDBChangeOpDelete'),(331,38,'IPObject',3,'CMDBChangeOpDelete'),(332,39,'IPObject',2,'CMDBChangeOpDelete'),(334,40,'IPObject',11,'CMDBChangeOpDelete'),(335,40,'Server',3,'CMDBChangeOpSetAttributeScalar'),(336,41,'IPObject',1,'CMDBChangeOpDelete'),(337,42,'IPObject',6,'CMDBChangeOpDelete'),(338,43,'IPObject',5,'CMDBChangeOpDelete'),(339,44,'IPObject',8,'CMDBChangeOpDelete'),(340,45,'IPObject',7,'CMDBChangeOpDelete'),(341,46,'IPObject',10,'CMDBChangeOpDelete'),(342,47,'IPObject',9,'CMDBChangeOpDelete'),(343,48,'IPv4Block',14,'CMDBChangeOpCreate'),(344,49,'IPv4Subnet',15,'CMDBChangeOpCreate'),(345,50,'IPv4Block',16,'CMDBChangeOpCreate'),(346,51,'IPv4Subnet',17,'CMDBChangeOpCreate'),(347,52,'IPv4Block',18,'CMDBChangeOpCreate'),(348,53,'IPv4Subnet',19,'CMDBChangeOpCreate'),(349,54,'IPv4Block',20,'CMDBChangeOpCreate'),(350,55,'IPv4Subnet',21,'CMDBChangeOpCreate'),(351,56,'IPv4Block',22,'CMDBChangeOpCreate'),(352,57,'IPv4Subnet',23,'CMDBChangeOpCreate'),(353,58,'IPv4Block',24,'CMDBChangeOpCreate'),(354,59,'IPv4Subnet',25,'CMDBChangeOpCreate'),(355,60,'IPv4Block',26,'CMDBChangeOpCreate'),(356,61,'IPv4Subnet',27,'CMDBChangeOpCreate'),(357,62,'IPv4Block',28,'CMDBChangeOpCreate'),(358,63,'IPv4Subnet',29,'CMDBChangeOpCreate'),(359,64,'IPv4Block',30,'CMDBChangeOpCreate'),(360,65,'IPv4Subnet',31,'CMDBChangeOpCreate'),(362,67,'IPv4Address',33,'CMDBChangeOpCreate'),(363,68,'IPv4Address',34,'CMDBChangeOpCreate'),(364,69,'IPv4Address',35,'CMDBChangeOpCreate'),(369,74,'IPObject',37,'CMDBChangeOpDelete'),(370,75,'IPv4Address',38,'CMDBChangeOpCreate'),(371,76,'IPv4Address',39,'CMDBChangeOpCreate'),(372,77,'IPv4Address',40,'CMDBChangeOpCreate'),(373,78,'IPv4Address',41,'CMDBChangeOpCreate'),(374,79,'IPv4Address',42,'CMDBChangeOpCreate'),(376,81,'IPv4Address',44,'CMDBChangeOpCreate'),(377,82,'IPv4Address',45,'CMDBChangeOpCreate'),(380,85,'IPv4Address',48,'CMDBChangeOpCreate'),(381,86,'IPv4Address',49,'CMDBChangeOpCreate'),(382,87,'IPv4Address',50,'CMDBChangeOpCreate'),(383,88,'IPv4Address',51,'CMDBChangeOpCreate'),(385,90,'IPv4Address',53,'CMDBChangeOpCreate'),(392,94,'IPv4Address',48,'CMDBChangeOpSetAttributeScalar'),(393,95,'IPv4Address',55,'CMDBChangeOpCreate'),(394,96,'IPv4Address',56,'CMDBChangeOpCreate'),(395,97,'IPv4Address',57,'CMDBChangeOpCreate'),(398,100,'IPv4Address',60,'CMDBChangeOpCreate'),(414,113,'IPv4Address',69,'CMDBChangeOpCreate'),(415,114,'IPObject',36,'CMDBChangeOpDelete'),(416,114,'IPObject',43,'CMDBChangeOpDelete'),(417,114,'IPObject',46,'CMDBChangeOpDelete'),(418,114,'IPObject',47,'CMDBChangeOpDelete'),(419,114,'IPObject',52,'CMDBChangeOpDelete'),(420,114,'IPObject',54,'CMDBChangeOpDelete'),(421,114,'IPObject',58,'CMDBChangeOpDelete'),(422,114,'IPObject',62,'CMDBChangeOpDelete'),(423,114,'IPObject',63,'CMDBChangeOpDelete'),(424,114,'IPObject',64,'CMDBChangeOpDelete'),(425,114,'IPObject',65,'CMDBChangeOpDelete'),(426,114,'IPObject',66,'CMDBChangeOpDelete'),(427,114,'IPObject',67,'CMDBChangeOpDelete'),(428,114,'IPObject',59,'CMDBChangeOpDelete'),(429,114,'IPObject',61,'CMDBChangeOpDelete'),(430,114,'IPObject',68,'CMDBChangeOpDelete'),(431,115,'IPv4Address',42,'CMDBChangeOpSetAttributeScalar'),(432,115,'IPv4Address',42,'CMDBChangeOpSetAttributeScalar'),(433,116,'PC',5,'CMDBChangeOpCreate'),(434,116,'IPv4Address',33,'CMDBChangeOpSetAttributeScalar'),(435,116,'IPv4Address',33,'CMDBChangeOpSetAttributeScalar'),(436,117,'PC',5,'CMDBChangeOpSetAttributeScalar'),(437,118,'PC',6,'CMDBChangeOpCreate'),(438,118,'IPv4Address',35,'CMDBChangeOpSetAttributeScalar'),(439,118,'IPv4Address',35,'CMDBChangeOpSetAttributeScalar'),(440,119,'PC',7,'CMDBChangeOpCreate'),(441,119,'IPv4Address',44,'CMDBChangeOpSetAttributeScalar'),(442,119,'IPv4Address',44,'CMDBChangeOpSetAttributeScalar'),(443,120,'PC',7,'CMDBChangeOpSetAttributeScalar'),(444,121,'PC',8,'CMDBChangeOpCreate'),(445,121,'IPv4Address',45,'CMDBChangeOpSetAttributeScalar'),(446,121,'IPv4Address',45,'CMDBChangeOpSetAttributeScalar'),(447,122,'PC',9,'CMDBChangeOpCreate'),(448,122,'IPv4Address',48,'CMDBChangeOpSetAttributeScalar'),(449,122,'IPv4Address',48,'CMDBChangeOpSetAttributeScalar'),(450,123,'PC',10,'CMDBChangeOpCreate'),(451,123,'IPv4Address',49,'CMDBChangeOpSetAttributeScalar'),(452,123,'IPv4Address',49,'CMDBChangeOpSetAttributeScalar'),(453,124,'PC',11,'CMDBChangeOpCreate'),(454,124,'IPv4Address',50,'CMDBChangeOpSetAttributeScalar'),(455,124,'IPv4Address',50,'CMDBChangeOpSetAttributeScalar'),(456,125,'PC',12,'CMDBChangeOpCreate'),(457,125,'IPv4Address',51,'CMDBChangeOpSetAttributeScalar'),(458,125,'IPv4Address',51,'CMDBChangeOpSetAttributeScalar'),(459,126,'PC',13,'CMDBChangeOpCreate'),(460,126,'IPv4Address',53,'CMDBChangeOpSetAttributeScalar'),(461,126,'IPv4Address',53,'CMDBChangeOpSetAttributeScalar'),(462,127,'PC',14,'CMDBChangeOpCreate'),(463,127,'IPv4Address',55,'CMDBChangeOpSetAttributeScalar'),(464,127,'IPv4Address',55,'CMDBChangeOpSetAttributeScalar'),(465,128,'PC',15,'CMDBChangeOpCreate'),(466,128,'IPv4Address',56,'CMDBChangeOpSetAttributeScalar'),(467,128,'IPv4Address',56,'CMDBChangeOpSetAttributeScalar'),(468,129,'PC',16,'CMDBChangeOpCreate'),(469,129,'IPv4Address',57,'CMDBChangeOpSetAttributeScalar'),(470,129,'IPv4Address',57,'CMDBChangeOpSetAttributeScalar'),(471,130,'NetworkDevice',17,'CMDBChangeOpCreate'),(472,131,'NetworkDevice',18,'CMDBChangeOpCreate'),(473,132,'NetworkDevice',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(474,132,'PhysicalInterface',2,'CMDBChangeOpCreate'),(475,133,'NetworkDevice',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(476,133,'PhysicalInterface',3,'CMDBChangeOpCreate'),(477,134,'NetworkDevice',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(478,134,'PhysicalInterface',4,'CMDBChangeOpCreate'),(479,135,'NetworkDevice',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(480,135,'PhysicalInterface',5,'CMDBChangeOpCreate'),(481,136,'NetworkDevice',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(482,136,'PhysicalInterface',6,'CMDBChangeOpCreate'),(483,137,'NetworkDevice',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(484,137,'PhysicalInterface',7,'CMDBChangeOpCreate'),(485,138,'NetworkDevice',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(486,138,'PhysicalInterface',8,'CMDBChangeOpCreate'),(487,139,'NetworkDevice',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(488,139,'PhysicalInterface',9,'CMDBChangeOpCreate'),(489,140,'NetworkDevice',17,'CMDBChangeOpSetAttributeScalar'),(490,140,'NetworkDevice',17,'CMDBChangeOpSetAttributeScalar'),(491,141,'NetworkDevice',17,'CMDBChangeOpSetAttributeLinksAddRemove'),(492,141,'PhysicalInterface',10,'CMDBChangeOpCreate'),(493,142,'NetworkDevice',17,'CMDBChangeOpSetAttributeLinksAddRemove'),(494,142,'PhysicalInterface',11,'CMDBChangeOpCreate'),(495,143,'NetworkDevice',18,'CMDBChangeOpSetAttributeScalar'),(496,144,'NetworkDevice',18,'CMDBChangeOpSetAttributeLinksAddRemove'),(497,144,'PhysicalInterface',12,'CMDBChangeOpCreate'),(498,145,'NetworkDevice',18,'CMDBChangeOpSetAttributeLinksAddRemove'),(499,145,'PhysicalInterface',13,'CMDBChangeOpCreate'),(500,146,'PhysicalInterface',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(501,146,'lnkIPInterfaceToIPAddress',1,'CMDBChangeOpCreate'),(502,146,'IPv4Address',42,'CMDBChangeOpSetAttributeScalar'),(503,146,'IPv4Address',42,'CMDBChangeOpSetAttributeScalar'),(504,147,'IPv4Address',70,'CMDBChangeOpCreate'),(505,148,'PhysicalInterface',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(506,148,'lnkIPInterfaceToIPAddress',2,'CMDBChangeOpCreate'),(507,149,'IPv4Address',71,'CMDBChangeOpCreate'),(508,150,'PhysicalInterface',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(509,150,'lnkIPInterfaceToIPAddress',3,'CMDBChangeOpCreate'),(510,151,'IPv4Address',72,'CMDBChangeOpCreate'),(511,152,'PhysicalInterface',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(512,152,'lnkIPInterfaceToIPAddress',4,'CMDBChangeOpCreate'),(513,153,'PhysicalInterface',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(514,153,'lnkIPInterfaceToIPAddress',5,'CMDBChangeOpCreate'),(515,153,'IPv4Address',34,'CMDBChangeOpSetAttributeScalar'),(516,153,'IPv4Address',34,'CMDBChangeOpSetAttributeScalar'),(517,154,'IPv4Address',73,'CMDBChangeOpCreate'),(518,155,'PhysicalInterface',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(519,155,'lnkIPInterfaceToIPAddress',6,'CMDBChangeOpCreate'),(520,156,'IPv4Address',74,'CMDBChangeOpCreate'),(521,157,'PhysicalInterface',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(522,157,'lnkIPInterfaceToIPAddress',7,'CMDBChangeOpCreate'),(523,158,'IPv4Address',75,'CMDBChangeOpCreate'),(524,159,'PhysicalInterface',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(525,159,'lnkIPInterfaceToIPAddress',8,'CMDBChangeOpCreate'),(526,160,'PhysicalInterface',12,'CMDBChangeOpSetAttributeLinksAddRemove'),(527,160,'lnkIPInterfaceToIPAddress',9,'CMDBChangeOpCreate'),(528,160,'IPv4Address',69,'CMDBChangeOpSetAttributeScalar'),(529,160,'IPv4Address',69,'CMDBChangeOpSetAttributeScalar'),(530,161,'IPv4Address',76,'CMDBChangeOpCreate'),(531,162,'PhysicalInterface',13,'CMDBChangeOpSetAttributeLinksAddRemove'),(532,162,'lnkIPInterfaceToIPAddress',10,'CMDBChangeOpCreate'),(533,163,'IPv4Address',77,'CMDBChangeOpCreate'),(534,164,'PhysicalInterface',10,'CMDBChangeOpSetAttributeLinksAddRemove'),(535,164,'lnkIPInterfaceToIPAddress',11,'CMDBChangeOpCreate'),(536,165,'PhysicalInterface',11,'CMDBChangeOpSetAttributeLinksAddRemove'),(537,165,'lnkIPInterfaceToIPAddress',12,'CMDBChangeOpCreate'),(538,165,'IPv4Address',60,'CMDBChangeOpSetAttributeScalar'),(539,165,'IPv4Address',60,'CMDBChangeOpSetAttributeScalar'),(540,166,'IPv4Address',60,'CMDBChangeOpSetAttributeScalar'),(541,167,'Server',19,'CMDBChangeOpCreate'),(542,167,'IPv4Address',39,'CMDBChangeOpSetAttributeScalar'),(543,167,'IPv4Address',39,'CMDBChangeOpSetAttributeScalar'),(544,168,'Server',20,'CMDBChangeOpCreate'),(545,168,'IPv4Address',40,'CMDBChangeOpSetAttributeScalar'),(546,168,'IPv4Address',40,'CMDBChangeOpSetAttributeScalar'),(547,169,'Server',21,'CMDBChangeOpCreate'),(548,169,'IPv4Address',41,'CMDBChangeOpSetAttributeScalar'),(549,169,'IPv4Address',41,'CMDBChangeOpSetAttributeScalar'),(550,170,'PC',22,'CMDBChangeOpCreate'),(551,170,'IPv4Address',38,'CMDBChangeOpSetAttributeScalar'),(552,170,'IPv4Address',38,'CMDBChangeOpSetAttributeScalar'),(553,171,'IPObject',32,'CMDBChangeOpDelete'),(554,172,'IPv4Address',78,'CMDBChangeOpCreate'),(555,173,'IPv4Address',78,'CMDBChangeOpSetAttributeScalar'),(556,173,'IPv4Address',78,'CMDBChangeOpSetAttributeScalar'),(557,174,'NetworkDevice',23,'CMDBChangeOpCreate'),(558,174,'IPv4Address',78,'CMDBChangeOpSetAttributeScalar'),(559,174,'IPv4Address',78,'CMDBChangeOpSetAttributeScalar'),(560,175,'Server',20,'CMDBChangeOpSetAttributeLinksAddRemove'),(561,175,'WebServer',24,'CMDBChangeOpCreate'),(562,176,'Software',2,'CMDBChangeOpCreate'),(563,177,'Server',19,'CMDBChangeOpSetAttributeLinksAddRemove'),(564,177,'Middleware',25,'CMDBChangeOpCreate'),(565,178,'Software',3,'CMDBChangeOpCreate'),(566,179,'Server',19,'CMDBChangeOpSetAttributeLinksAddRemove'),(567,179,'Middleware',26,'CMDBChangeOpCreate'),(568,180,'Software',4,'CMDBChangeOpCreate'),(569,181,'Server',19,'CMDBChangeOpSetAttributeLinksAddRemove'),(570,181,'Middleware',27,'CMDBChangeOpCreate'),(571,182,'Software',5,'CMDBChangeOpCreate'),(572,183,'Server',19,'CMDBChangeOpSetAttributeLinksAddRemove'),(573,183,'Middleware',28,'CMDBChangeOpCreate'),(574,184,'Software',6,'CMDBChangeOpCreate'),(575,185,'Server',19,'CMDBChangeOpSetAttributeLinksAddRemove'),(576,185,'Middleware',29,'CMDBChangeOpCreate'),(577,186,'Software',7,'CMDBChangeOpCreate'),(578,187,'Server',19,'CMDBChangeOpSetAttributeLinksAddRemove'),(579,187,'Middleware',30,'CMDBChangeOpCreate'),(580,188,'Software',8,'CMDBChangeOpCreate'),(581,189,'Server',21,'CMDBChangeOpSetAttributeLinksAddRemove'),(582,189,'WebServer',31,'CMDBChangeOpCreate'),(583,190,'Software',9,'CMDBChangeOpCreate'),(584,191,'Server',20,'CMDBChangeOpSetAttributeLinksAddRemove'),(585,191,'WebServer',32,'CMDBChangeOpCreate'),(586,192,'Server',20,'CMDBChangeOpSetAttributeLinksTune'),(587,192,'WebServer',32,'CMDBChangeOpSetAttributeScalar'),(588,193,'Software',10,'CMDBChangeOpCreate'),(589,194,'PC',22,'CMDBChangeOpSetAttributeLinksAddRemove'),(590,194,'WebServer',33,'CMDBChangeOpCreate'),(591,195,'Software',11,'CMDBChangeOpCreate'),(592,196,'Server',19,'CMDBChangeOpSetAttributeLinksAddRemove'),(593,196,'Middleware',34,'CMDBChangeOpCreate'),(594,197,'Software',12,'CMDBChangeOpCreate'),(595,198,'Server',19,'CMDBChangeOpSetAttributeLinksAddRemove'),(596,198,'Middleware',35,'CMDBChangeOpCreate'),(597,199,'Software',13,'CMDBChangeOpCreate'),(598,200,'Server',19,'CMDBChangeOpSetAttributeLinksAddRemove'),(599,200,'Middleware',36,'CMDBChangeOpCreate'),(600,201,'Software',14,'CMDBChangeOpCreate'),(601,202,'Server',19,'CMDBChangeOpSetAttributeLinksAddRemove'),(602,202,'Middleware',37,'CMDBChangeOpCreate'),(603,203,'Software',15,'CMDBChangeOpCreate'),(604,204,'Server',20,'CMDBChangeOpSetAttributeLinksAddRemove'),(605,204,'Middleware',38,'CMDBChangeOpCreate'),(606,205,'Software',16,'CMDBChangeOpCreate'),(607,206,'Server',20,'CMDBChangeOpSetAttributeLinksAddRemove'),(608,206,'Middleware',39,'CMDBChangeOpCreate'),(609,207,'Software',17,'CMDBChangeOpCreate'),(610,208,'Server',20,'CMDBChangeOpSetAttributeLinksAddRemove'),(611,208,'Middleware',40,'CMDBChangeOpCreate'),(612,209,'Software',18,'CMDBChangeOpCreate'),(613,210,'Server',20,'CMDBChangeOpSetAttributeLinksAddRemove'),(614,210,'WebServer',41,'CMDBChangeOpCreate'),(615,211,'Server',21,'CMDBChangeOpSetAttributeLinksAddRemove'),(616,211,'Middleware',42,'CMDBChangeOpCreate'),(617,212,'PC',22,'CMDBChangeOpSetAttributeLinksAddRemove'),(618,212,'Middleware',43,'CMDBChangeOpCreate'),(619,213,'PC',22,'CMDBChangeOpSetAttributeLinksAddRemove'),(620,213,'Middleware',44,'CMDBChangeOpCreate'),(621,214,'Software',19,'CMDBChangeOpCreate'),(622,215,'PC',22,'CMDBChangeOpSetAttributeLinksAddRemove'),(623,215,'Middleware',45,'CMDBChangeOpCreate'),(624,216,'PC',22,'CMDBChangeOpSetAttributeLinksAddRemove'),(625,216,'Middleware',46,'CMDBChangeOpCreate'),(626,217,'PC',10,'CMDBChangeOpSetAttributeLinksAddRemove'),(627,217,'Middleware',47,'CMDBChangeOpCreate'),(628,218,'PC',10,'CMDBChangeOpSetAttributeLinksAddRemove'),(629,218,'Middleware',48,'CMDBChangeOpCreate'),(630,219,'PC',10,'CMDBChangeOpSetAttributeLinksAddRemove'),(631,219,'Middleware',49,'CMDBChangeOpCreate'),(632,220,'PC',10,'CMDBChangeOpSetAttributeLinksAddRemove'),(633,220,'Middleware',50,'CMDBChangeOpCreate'),(634,221,'PC',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(635,221,'Middleware',51,'CMDBChangeOpCreate'),(636,222,'PC',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(637,222,'Middleware',52,'CMDBChangeOpCreate'),(638,223,'Software',20,'CMDBChangeOpCreate'),(639,224,'PC',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(640,224,'Middleware',53,'CMDBChangeOpCreate'),(641,225,'PC',10,'CMDBChangeOpSetAttributeLinksTune'),(642,225,'Middleware',49,'CMDBChangeOpSetAttributeScalar'),(643,226,'Software',21,'CMDBChangeOpCreate'),(644,227,'PC',10,'CMDBChangeOpSetAttributeLinksAddRemove'),(645,227,'Middleware',54,'CMDBChangeOpCreate'),(646,228,'PC',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(647,228,'Middleware',55,'CMDBChangeOpCreate'),(648,229,'PC',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(649,229,'Middleware',56,'CMDBChangeOpCreate'),(650,230,'PC',16,'CMDBChangeOpSetAttributeLinksAddRemove'),(651,230,'Middleware',57,'CMDBChangeOpCreate'),(652,231,'PC',16,'CMDBChangeOpSetAttributeLinksAddRemove'),(653,231,'Middleware',58,'CMDBChangeOpCreate'),(654,232,'PC',16,'CMDBChangeOpSetAttributeLinksAddRemove'),(655,232,'Middleware',59,'CMDBChangeOpCreate'),(656,233,'PC',16,'CMDBChangeOpSetAttributeLinksAddRemove'),(657,233,'Middleware',60,'CMDBChangeOpCreate'),(658,234,'PC',16,'CMDBChangeOpSetAttributeLinksAddRemove'),(659,234,'Middleware',61,'CMDBChangeOpCreate'),(660,235,'PC',15,'CMDBChangeOpSetAttributeLinksAddRemove'),(661,235,'Middleware',62,'CMDBChangeOpCreate'),(662,236,'PC',15,'CMDBChangeOpSetAttributeLinksAddRemove'),(663,236,'Middleware',63,'CMDBChangeOpCreate'),(664,237,'PC',15,'CMDBChangeOpSetAttributeLinksAddRemove'),(665,237,'Middleware',64,'CMDBChangeOpCreate'),(666,238,'PC',15,'CMDBChangeOpSetAttributeLinksAddRemove'),(667,238,'Middleware',65,'CMDBChangeOpCreate'),(668,239,'PC',15,'CMDBChangeOpSetAttributeLinksAddRemove'),(669,239,'Middleware',66,'CMDBChangeOpCreate'),(670,240,'PC',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(671,240,'Middleware',67,'CMDBChangeOpCreate'),(672,241,'PC',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(673,241,'Middleware',68,'CMDBChangeOpCreate'),(674,242,'PC',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(675,242,'Middleware',69,'CMDBChangeOpCreate'),(676,243,'PC',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(677,243,'Middleware',70,'CMDBChangeOpCreate'),(678,244,'PC',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(679,244,'Middleware',71,'CMDBChangeOpCreate'),(680,245,'PC',12,'CMDBChangeOpSetAttributeLinksAddRemove'),(681,245,'Middleware',72,'CMDBChangeOpCreate'),(682,246,'PC',12,'CMDBChangeOpSetAttributeLinksAddRemove'),(683,246,'Middleware',73,'CMDBChangeOpCreate'),(684,247,'PC',12,'CMDBChangeOpSetAttributeLinksTune'),(685,247,'Middleware',73,'CMDBChangeOpSetAttributeScalar'),(686,247,'Middleware',73,'CMDBChangeOpSetAttributeScalar'),(687,248,'PC',12,'CMDBChangeOpSetAttributeLinksAddRemove'),(688,248,'Middleware',74,'CMDBChangeOpCreate'),(689,249,'PC',12,'CMDBChangeOpSetAttributeLinksAddRemove'),(690,249,'Middleware',75,'CMDBChangeOpCreate'),(691,250,'PC',12,'CMDBChangeOpSetAttributeLinksAddRemove'),(692,250,'Middleware',76,'CMDBChangeOpCreate'),(693,251,'Software',22,'CMDBChangeOpCreate'),(694,252,'PC',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(695,252,'Middleware',77,'CMDBChangeOpCreate'),(696,253,'Software',23,'CMDBChangeOpCreate'),(697,254,'PC',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(698,254,'Middleware',78,'CMDBChangeOpCreate'),(699,255,'PC',13,'CMDBChangeOpSetAttributeLinksAddRemove'),(700,255,'Middleware',79,'CMDBChangeOpCreate'),(701,256,'PC',13,'CMDBChangeOpSetAttributeLinksAddRemove'),(702,256,'Middleware',80,'CMDBChangeOpCreate'),(703,257,'PC',13,'CMDBChangeOpSetAttributeLinksAddRemove'),(704,257,'Middleware',81,'CMDBChangeOpCreate'),(705,258,'PC',13,'CMDBChangeOpSetAttributeLinksAddRemove'),(706,258,'Middleware',82,'CMDBChangeOpCreate'),(707,259,'PC',13,'CMDBChangeOpSetAttributeLinksAddRemove'),(708,259,'Middleware',83,'CMDBChangeOpCreate'),(709,260,'PC',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(710,260,'Middleware',84,'CMDBChangeOpCreate'),(711,261,'PC',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(712,261,'Middleware',85,'CMDBChangeOpCreate'),(713,262,'PC',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(714,262,'Middleware',86,'CMDBChangeOpCreate'),(715,263,'PC',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(716,263,'Middleware',87,'CMDBChangeOpCreate'),(717,264,'PC',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(718,264,'Middleware',88,'CMDBChangeOpCreate'),(719,265,'PC',11,'CMDBChangeOpSetAttributeLinksAddRemove'),(720,265,'Middleware',89,'CMDBChangeOpCreate'),(721,266,'PC',11,'CMDBChangeOpSetAttributeLinksAddRemove'),(722,266,'Middleware',90,'CMDBChangeOpCreate'),(723,267,'PC',11,'CMDBChangeOpSetAttributeLinksAddRemove'),(724,267,'Middleware',91,'CMDBChangeOpCreate'),(725,268,'PC',11,'CMDBChangeOpSetAttributeLinksAddRemove'),(726,268,'Middleware',92,'CMDBChangeOpCreate'),(727,269,'PC',11,'CMDBChangeOpSetAttributeLinksAddRemove'),(728,269,'Middleware',93,'CMDBChangeOpCreate'),(729,270,'PC',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(730,270,'Middleware',94,'CMDBChangeOpCreate'),(731,271,'PC',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(732,271,'Middleware',95,'CMDBChangeOpCreate'),(733,272,'Software',24,'CMDBChangeOpCreate'),(734,273,'PC',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(735,273,'Middleware',96,'CMDBChangeOpCreate'),(736,274,'PC',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(737,274,'Middleware',97,'CMDBChangeOpCreate'),(738,275,'PC',14,'CMDBChangeOpSetAttributeLinksAddRemove'),(739,275,'Middleware',98,'CMDBChangeOpCreate'),(740,276,'PC',14,'CMDBChangeOpSetAttributeLinksAddRemove'),(741,276,'Middleware',99,'CMDBChangeOpCreate'),(742,277,'PC',14,'CMDBChangeOpSetAttributeLinksAddRemove'),(743,277,'Middleware',100,'CMDBChangeOpCreate'),(744,278,'PC',14,'CMDBChangeOpSetAttributeLinksAddRemove'),(745,278,'Middleware',101,'CMDBChangeOpCreate'),(746,279,'PC',14,'CMDBChangeOpSetAttributeLinksAddRemove'),(747,279,'Middleware',102,'CMDBChangeOpCreate'),(748,280,'WebServer',24,'CMDBChangeOpSetAttributeLinksAddRemove'),(749,280,'WebApplication',103,'CMDBChangeOpCreate'),(750,281,'WebServer',24,'CMDBChangeOpSetAttributeLinksAddRemove'),(751,281,'WebApplication',104,'CMDBChangeOpCreate'),(752,282,'WebServer',24,'CMDBChangeOpSetAttributeLinksAddRemove'),(753,282,'WebApplication',105,'CMDBChangeOpCreate'),(754,283,'WebServer',24,'CMDBChangeOpSetAttributeLinksAddRemove'),(755,283,'WebApplication',106,'CMDBChangeOpCreate'),(756,284,'WebServer',24,'CMDBChangeOpSetAttributeLinksAddRemove'),(757,284,'WebApplication',107,'CMDBChangeOpCreate'),(758,285,'WebServer',24,'CMDBChangeOpSetAttributeLinksAddRemove'),(759,285,'WebApplication',108,'CMDBChangeOpCreate'),(760,286,'WebServer',31,'CMDBChangeOpSetAttributeLinksAddRemove'),(761,286,'WebApplication',109,'CMDBChangeOpCreate');
/*!40000 ALTER TABLE `priv_changeop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_attachment_added`
--

DROP TABLE IF EXISTS `priv_changeop_attachment_added`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_changeop_attachment_added` (
  `id` int NOT NULL,
  `attachment_id` int DEFAULT '0',
  `filename` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `attachment_id` (`attachment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_attachment_added`
--

LOCK TABLES `priv_changeop_attachment_added` WRITE;
/*!40000 ALTER TABLE `priv_changeop_attachment_added` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_changeop_attachment_added` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_attachment_removed`
--

DROP TABLE IF EXISTS `priv_changeop_attachment_removed`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_changeop_attachment_removed` (
  `id` int NOT NULL,
  `filename` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_attachment_removed`
--

LOCK TABLES `priv_changeop_attachment_removed` WRITE;
/*!40000 ALTER TABLE `priv_changeop_attachment_removed` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_changeop_attachment_removed` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_create`
--

DROP TABLE IF EXISTS `priv_changeop_create`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_changeop_create` (
  `id` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_create`
--

LOCK TABLES `priv_changeop_create` WRITE;
/*!40000 ALTER TABLE `priv_changeop_create` DISABLE KEYS */;
INSERT INTO `priv_changeop_create` VALUES (1),(2),(3),(6),(9),(12),(13),(14),(17),(20),(23),(27),(28),(29),(30),(31),(32),(33),(34),(35),(36),(37),(38),(39),(40),(41),(42),(43),(44),(45),(46),(47),(48),(49),(50),(51),(52),(53),(54),(55),(56),(59),(61),(62),(63),(64),(65),(66),(67),(68),(69),(70),(71),(72),(73),(74),(75),(76),(77),(78),(79),(80),(81),(82),(83),(84),(85),(86),(87),(88),(89),(90),(91),(92),(93),(94),(95),(96),(97),(98),(99),(100),(101),(102),(103),(104),(105),(106),(107),(108),(109),(110),(111),(112),(113),(114),(115),(116),(117),(118),(119),(120),(121),(122),(123),(124),(125),(126),(127),(128),(129),(130),(131),(132),(133),(134),(135),(136),(137),(138),(139),(140),(141),(142),(143),(144),(145),(146),(147),(148),(149),(150),(151),(152),(153),(154),(155),(156),(157),(158),(159),(160),(161),(162),(163),(164),(165),(166),(167),(168),(169),(170),(171),(172),(173),(174),(175),(176),(177),(178),(179),(180),(181),(182),(183),(184),(185),(186),(187),(188),(189),(190),(191),(192),(193),(194),(195),(196),(197),(198),(199),(200),(201),(202),(203),(204),(205),(206),(207),(208),(209),(210),(211),(212),(213),(214),(215),(216),(217),(218),(219),(220),(221),(222),(223),(225),(226),(227),(228),(229),(230),(231),(232),(233),(234),(235),(236),(237),(238),(239),(240),(241),(242),(243),(244),(245),(246),(247),(248),(249),(250),(251),(252),(253),(254),(255),(256),(257),(258),(259),(260),(261),(262),(263),(264),(265),(266),(267),(268),(269),(270),(271),(272),(273),(274),(275),(276),(277),(278),(279),(280),(281),(282),(283),(284),(285),(286),(287),(288),(289),(290),(291),(292),(293),(294),(295),(296),(311),(312),(313),(314),(315),(316),(318),(320),(322),(323),(343),(344),(345),(346),(347),(348),(349),(350),(351),(352),(353),(354),(355),(356),(357),(358),(359),(360),(362),(363),(364),(370),(371),(372),(373),(374),(376),(377),(380),(381),(382),(383),(385),(393),(394),(395),(398),(414),(433),(437),(440),(444),(447),(450),(453),(456),(459),(462),(465),(468),(471),(472),(474),(476),(478),(480),(482),(484),(486),(488),(492),(494),(497),(499),(501),(504),(506),(507),(509),(510),(512),(514),(517),(519),(520),(522),(523),(525),(527),(530),(532),(533),(535),(537),(541),(544),(547),(550),(554),(557),(561),(562),(564),(565),(567),(568),(570),(571),(573),(574),(576),(577),(579),(580),(582),(583),(585),(588),(590),(591),(593),(594),(596),(597),(599),(600),(602),(603),(605),(606),(608),(609),(611),(612),(614),(616),(618),(620),(621),(623),(625),(627),(629),(631),(633),(635),(637),(638),(640),(643),(645),(647),(649),(651),(653),(655),(657),(659),(661),(663),(665),(667),(669),(671),(673),(675),(677),(679),(681),(683),(688),(690),(692),(693),(695),(696),(698),(700),(702),(704),(706),(708),(710),(712),(714),(716),(718),(720),(722),(724),(726),(728),(730),(732),(733),(735),(737),(739),(741),(743),(745),(747),(749),(751),(753),(755),(757),(759),(761);
/*!40000 ALTER TABLE `priv_changeop_create` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_delete`
--

DROP TABLE IF EXISTS `priv_changeop_delete`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_changeop_delete` (
  `id` int NOT NULL,
  `fclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `fname` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_delete`
--

LOCK TABLES `priv_changeop_delete` WRITE;
/*!40000 ALTER TABLE `priv_changeop_delete` DISABLE KEYS */;
INSERT INTO `priv_changeop_delete` VALUES (328,'IPv4Subnet','10.120.0.0'),(329,'IPv4Block','Example_Subnet'),(330,'IPv4Subnet','10.160.0.0'),(331,'IPv4Block','Student_Network'),(332,'IPv4Subnet','10.170.0.0'),(334,'IPv4Address','10.170.0.20'),(336,'IPv4Block','Server_Network'),(337,'IPv4Subnet','10.171.0.0'),(338,'IPv4Block','Financial_Network'),(339,'IPv4Subnet','10.172.0.0'),(340,'IPv4Block','HHRR_Network'),(341,'IPv4Subnet','10.173.0.0'),(342,'IPv4Block','IT_Network'),(369,'IPv4Address','10.170.0.2'),(415,'IPv4Address','10.170.0.1'),(416,'IPv4Address','10.171.0.1'),(417,'IPv4Address','10.171.0.254'),(418,'IPv4Address','10.172.0.1'),(419,'IPv4Address','10.172.0.254'),(420,'IPv4Address','10.173.0.1'),(421,'IPv4Address','10.173.0.254'),(422,'IPv4Address','172.16.20.1'),(423,'IPv4Address','172.16.20.200'),(424,'IPv4Address','172.16.20.254'),(425,'IPv4Address','172.16.21.1'),(426,'IPv4Address','172.16.21.200'),(427,'IPv4Address','172.16.21.254'),(428,'IPv4Address','192.168.11.1'),(429,'IPv4Address','192.168.11.254'),(430,'IPv4Address','192.168.100.1'),(553,'IPv4Address','10.160.0.1');
/*!40000 ALTER TABLE `priv_changeop_delete` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_links`
--

DROP TABLE IF EXISTS `priv_changeop_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_changeop_links` (
  `id` int NOT NULL,
  `item_class` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `item_id` int DEFAULT '0',
  `optype` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'CMDBChangeOpSetAttributeLinks',
  PRIMARY KEY (`id`),
  KEY `optype` (`optype`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_links`
--

LOCK TABLES `priv_changeop_links` WRITE;
/*!40000 ALTER TABLE `priv_changeop_links` DISABLE KEYS */;
INSERT INTO `priv_changeop_links` VALUES (5,'Action',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(8,'Action',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(11,'Action',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(15,'Trigger',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(16,'Action',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(18,'Trigger',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(19,'Action',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(21,'Trigger',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(22,'Action',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(58,'User',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(60,'UserLocal',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(473,'PhysicalInterface',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(475,'PhysicalInterface',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(477,'PhysicalInterface',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(479,'PhysicalInterface',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(481,'PhysicalInterface',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(483,'PhysicalInterface',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(485,'PhysicalInterface',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(487,'PhysicalInterface',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(491,'PhysicalInterface',10,'CMDBChangeOpSetAttributeLinksAddRemove'),(493,'PhysicalInterface',11,'CMDBChangeOpSetAttributeLinksAddRemove'),(496,'PhysicalInterface',12,'CMDBChangeOpSetAttributeLinksAddRemove'),(498,'PhysicalInterface',13,'CMDBChangeOpSetAttributeLinksAddRemove'),(500,'IPAddress',42,'CMDBChangeOpSetAttributeLinksAddRemove'),(505,'IPAddress',70,'CMDBChangeOpSetAttributeLinksAddRemove'),(508,'IPAddress',71,'CMDBChangeOpSetAttributeLinksAddRemove'),(511,'IPAddress',72,'CMDBChangeOpSetAttributeLinksAddRemove'),(513,'IPAddress',34,'CMDBChangeOpSetAttributeLinksAddRemove'),(518,'IPAddress',73,'CMDBChangeOpSetAttributeLinksAddRemove'),(521,'IPAddress',74,'CMDBChangeOpSetAttributeLinksAddRemove'),(524,'IPAddress',75,'CMDBChangeOpSetAttributeLinksAddRemove'),(526,'IPAddress',69,'CMDBChangeOpSetAttributeLinksAddRemove'),(531,'IPAddress',76,'CMDBChangeOpSetAttributeLinksAddRemove'),(534,'IPAddress',77,'CMDBChangeOpSetAttributeLinksAddRemove'),(536,'IPAddress',60,'CMDBChangeOpSetAttributeLinksAddRemove'),(560,'WebServer',24,'CMDBChangeOpSetAttributeLinksAddRemove'),(563,'Middleware',25,'CMDBChangeOpSetAttributeLinksAddRemove'),(566,'Middleware',26,'CMDBChangeOpSetAttributeLinksAddRemove'),(569,'Middleware',27,'CMDBChangeOpSetAttributeLinksAddRemove'),(572,'Middleware',28,'CMDBChangeOpSetAttributeLinksAddRemove'),(575,'Middleware',29,'CMDBChangeOpSetAttributeLinksAddRemove'),(578,'Middleware',30,'CMDBChangeOpSetAttributeLinksAddRemove'),(581,'WebServer',31,'CMDBChangeOpSetAttributeLinksAddRemove'),(584,'WebServer',32,'CMDBChangeOpSetAttributeLinksAddRemove'),(586,'WebServer',32,'CMDBChangeOpSetAttributeLinksTune'),(589,'WebServer',33,'CMDBChangeOpSetAttributeLinksAddRemove'),(592,'Middleware',34,'CMDBChangeOpSetAttributeLinksAddRemove'),(595,'Middleware',35,'CMDBChangeOpSetAttributeLinksAddRemove'),(598,'Middleware',36,'CMDBChangeOpSetAttributeLinksAddRemove'),(601,'Middleware',37,'CMDBChangeOpSetAttributeLinksAddRemove'),(604,'Middleware',38,'CMDBChangeOpSetAttributeLinksAddRemove'),(607,'Middleware',39,'CMDBChangeOpSetAttributeLinksAddRemove'),(610,'Middleware',40,'CMDBChangeOpSetAttributeLinksAddRemove'),(613,'WebServer',41,'CMDBChangeOpSetAttributeLinksAddRemove'),(615,'Middleware',42,'CMDBChangeOpSetAttributeLinksAddRemove'),(617,'Middleware',43,'CMDBChangeOpSetAttributeLinksAddRemove'),(619,'Middleware',44,'CMDBChangeOpSetAttributeLinksAddRemove'),(622,'Middleware',45,'CMDBChangeOpSetAttributeLinksAddRemove'),(624,'Middleware',46,'CMDBChangeOpSetAttributeLinksAddRemove'),(626,'Middleware',47,'CMDBChangeOpSetAttributeLinksAddRemove'),(628,'Middleware',48,'CMDBChangeOpSetAttributeLinksAddRemove'),(630,'Middleware',49,'CMDBChangeOpSetAttributeLinksAddRemove'),(632,'Middleware',50,'CMDBChangeOpSetAttributeLinksAddRemove'),(634,'Middleware',51,'CMDBChangeOpSetAttributeLinksAddRemove'),(636,'Middleware',52,'CMDBChangeOpSetAttributeLinksAddRemove'),(639,'Middleware',53,'CMDBChangeOpSetAttributeLinksAddRemove'),(641,'Middleware',49,'CMDBChangeOpSetAttributeLinksTune'),(644,'Middleware',54,'CMDBChangeOpSetAttributeLinksAddRemove'),(646,'Middleware',55,'CMDBChangeOpSetAttributeLinksAddRemove'),(648,'Middleware',56,'CMDBChangeOpSetAttributeLinksAddRemove'),(650,'Middleware',57,'CMDBChangeOpSetAttributeLinksAddRemove'),(652,'Middleware',58,'CMDBChangeOpSetAttributeLinksAddRemove'),(654,'Middleware',59,'CMDBChangeOpSetAttributeLinksAddRemove'),(656,'Middleware',60,'CMDBChangeOpSetAttributeLinksAddRemove'),(658,'Middleware',61,'CMDBChangeOpSetAttributeLinksAddRemove'),(660,'Middleware',62,'CMDBChangeOpSetAttributeLinksAddRemove'),(662,'Middleware',63,'CMDBChangeOpSetAttributeLinksAddRemove'),(664,'Middleware',64,'CMDBChangeOpSetAttributeLinksAddRemove'),(666,'Middleware',65,'CMDBChangeOpSetAttributeLinksAddRemove'),(668,'Middleware',66,'CMDBChangeOpSetAttributeLinksAddRemove'),(670,'Middleware',67,'CMDBChangeOpSetAttributeLinksAddRemove'),(672,'Middleware',68,'CMDBChangeOpSetAttributeLinksAddRemove'),(674,'Middleware',69,'CMDBChangeOpSetAttributeLinksAddRemove'),(676,'Middleware',70,'CMDBChangeOpSetAttributeLinksAddRemove'),(678,'Middleware',71,'CMDBChangeOpSetAttributeLinksAddRemove'),(680,'Middleware',72,'CMDBChangeOpSetAttributeLinksAddRemove'),(682,'Middleware',73,'CMDBChangeOpSetAttributeLinksAddRemove'),(684,'Middleware',73,'CMDBChangeOpSetAttributeLinksTune'),(687,'Middleware',74,'CMDBChangeOpSetAttributeLinksAddRemove'),(689,'Middleware',75,'CMDBChangeOpSetAttributeLinksAddRemove'),(691,'Middleware',76,'CMDBChangeOpSetAttributeLinksAddRemove'),(694,'Middleware',77,'CMDBChangeOpSetAttributeLinksAddRemove'),(697,'Middleware',78,'CMDBChangeOpSetAttributeLinksAddRemove'),(699,'Middleware',79,'CMDBChangeOpSetAttributeLinksAddRemove'),(701,'Middleware',80,'CMDBChangeOpSetAttributeLinksAddRemove'),(703,'Middleware',81,'CMDBChangeOpSetAttributeLinksAddRemove'),(705,'Middleware',82,'CMDBChangeOpSetAttributeLinksAddRemove'),(707,'Middleware',83,'CMDBChangeOpSetAttributeLinksAddRemove'),(709,'Middleware',84,'CMDBChangeOpSetAttributeLinksAddRemove'),(711,'Middleware',85,'CMDBChangeOpSetAttributeLinksAddRemove'),(713,'Middleware',86,'CMDBChangeOpSetAttributeLinksAddRemove'),(715,'Middleware',87,'CMDBChangeOpSetAttributeLinksAddRemove'),(717,'Middleware',88,'CMDBChangeOpSetAttributeLinksAddRemove'),(719,'Middleware',89,'CMDBChangeOpSetAttributeLinksAddRemove'),(721,'Middleware',90,'CMDBChangeOpSetAttributeLinksAddRemove'),(723,'Middleware',91,'CMDBChangeOpSetAttributeLinksAddRemove'),(725,'Middleware',92,'CMDBChangeOpSetAttributeLinksAddRemove'),(727,'Middleware',93,'CMDBChangeOpSetAttributeLinksAddRemove'),(729,'Middleware',94,'CMDBChangeOpSetAttributeLinksAddRemove'),(731,'Middleware',95,'CMDBChangeOpSetAttributeLinksAddRemove'),(734,'Middleware',96,'CMDBChangeOpSetAttributeLinksAddRemove'),(736,'Middleware',97,'CMDBChangeOpSetAttributeLinksAddRemove'),(738,'Middleware',98,'CMDBChangeOpSetAttributeLinksAddRemove'),(740,'Middleware',99,'CMDBChangeOpSetAttributeLinksAddRemove'),(742,'Middleware',100,'CMDBChangeOpSetAttributeLinksAddRemove'),(744,'Middleware',101,'CMDBChangeOpSetAttributeLinksAddRemove'),(746,'Middleware',102,'CMDBChangeOpSetAttributeLinksAddRemove'),(748,'WebApplication',103,'CMDBChangeOpSetAttributeLinksAddRemove'),(750,'WebApplication',104,'CMDBChangeOpSetAttributeLinksAddRemove'),(752,'WebApplication',105,'CMDBChangeOpSetAttributeLinksAddRemove'),(754,'WebApplication',106,'CMDBChangeOpSetAttributeLinksAddRemove'),(756,'WebApplication',107,'CMDBChangeOpSetAttributeLinksAddRemove'),(758,'WebApplication',108,'CMDBChangeOpSetAttributeLinksAddRemove'),(760,'WebApplication',109,'CMDBChangeOpSetAttributeLinksAddRemove');
/*!40000 ALTER TABLE `priv_changeop_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_links_addremove`
--

DROP TABLE IF EXISTS `priv_changeop_links_addremove`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_changeop_links_addremove` (
  `id` int NOT NULL,
  `type` enum('added','removed') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'added',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_links_addremove`
--

LOCK TABLES `priv_changeop_links_addremove` WRITE;
/*!40000 ALTER TABLE `priv_changeop_links_addremove` DISABLE KEYS */;
INSERT INTO `priv_changeop_links_addremove` VALUES (5,'added'),(8,'added'),(11,'added'),(15,'added'),(16,'added'),(18,'added'),(19,'added'),(21,'added'),(22,'added'),(58,'added'),(60,'added'),(473,'added'),(475,'added'),(477,'added'),(479,'added'),(481,'added'),(483,'added'),(485,'added'),(487,'added'),(491,'added'),(493,'added'),(496,'added'),(498,'added'),(500,'added'),(505,'added'),(508,'added'),(511,'added'),(513,'added'),(518,'added'),(521,'added'),(524,'added'),(526,'added'),(531,'added'),(534,'added'),(536,'added'),(560,'added'),(563,'added'),(566,'added'),(569,'added'),(572,'added'),(575,'added'),(578,'added'),(581,'added'),(584,'added'),(589,'added'),(592,'added'),(595,'added'),(598,'added'),(601,'added'),(604,'added'),(607,'added'),(610,'added'),(613,'added'),(615,'added'),(617,'added'),(619,'added'),(622,'added'),(624,'added'),(626,'added'),(628,'added'),(630,'added'),(632,'added'),(634,'added'),(636,'added'),(639,'added'),(644,'added'),(646,'added'),(648,'added'),(650,'added'),(652,'added'),(654,'added'),(656,'added'),(658,'added'),(660,'added'),(662,'added'),(664,'added'),(666,'added'),(668,'added'),(670,'added'),(672,'added'),(674,'added'),(676,'added'),(678,'added'),(680,'added'),(682,'added'),(687,'added'),(689,'added'),(691,'added'),(694,'added'),(697,'added'),(699,'added'),(701,'added'),(703,'added'),(705,'added'),(707,'added'),(709,'added'),(711,'added'),(713,'added'),(715,'added'),(717,'added'),(719,'added'),(721,'added'),(723,'added'),(725,'added'),(727,'added'),(729,'added'),(731,'added'),(734,'added'),(736,'added'),(738,'added'),(740,'added'),(742,'added'),(744,'added'),(746,'added'),(748,'added'),(750,'added'),(752,'added'),(754,'added'),(756,'added'),(758,'added'),(760,'added');
/*!40000 ALTER TABLE `priv_changeop_links_addremove` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_links_tune`
--

DROP TABLE IF EXISTS `priv_changeop_links_tune`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_changeop_links_tune` (
  `id` int NOT NULL,
  `link_id` int DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_links_tune`
--

LOCK TABLES `priv_changeop_links_tune` WRITE;
/*!40000 ALTER TABLE `priv_changeop_links_tune` DISABLE KEYS */;
INSERT INTO `priv_changeop_links_tune` VALUES (586,32),(641,49),(684,73);
/*!40000 ALTER TABLE `priv_changeop_links_tune` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_plugin`
--

DROP TABLE IF EXISTS `priv_changeop_plugin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_changeop_plugin` (
  `id` int NOT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_plugin`
--

LOCK TABLES `priv_changeop_plugin` WRITE;
/*!40000 ALTER TABLE `priv_changeop_plugin` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_changeop_plugin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_setatt`
--

DROP TABLE IF EXISTS `priv_changeop_setatt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_changeop_setatt` (
  `id` int NOT NULL,
  `attcode` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `optype` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'CMDBChangeOpSetAttribute',
  PRIMARY KEY (`id`),
  KEY `optype` (`optype`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_setatt`
--

LOCK TABLES `priv_changeop_setatt` WRITE;
/*!40000 ALTER TABLE `priv_changeop_setatt` DISABLE KEYS */;
INSERT INTO `priv_changeop_setatt` VALUES (5,'action_list','CMDBChangeOpSetAttributeLinksAddRemove'),(8,'action_list','CMDBChangeOpSetAttributeLinksAddRemove'),(11,'action_list','CMDBChangeOpSetAttributeLinksAddRemove'),(15,'trigger_list','CMDBChangeOpSetAttributeLinksAddRemove'),(16,'action_list','CMDBChangeOpSetAttributeLinksAddRemove'),(18,'trigger_list','CMDBChangeOpSetAttributeLinksAddRemove'),(19,'action_list','CMDBChangeOpSetAttributeLinksAddRemove'),(21,'trigger_list','CMDBChangeOpSetAttributeLinksAddRemove'),(22,'action_list','CMDBChangeOpSetAttributeLinksAddRemove'),(24,'subscription_policy','CMDBChangeOpSetAttributeScalar'),(25,'subscription_policy','CMDBChangeOpSetAttributeScalar'),(26,'subscription_policy','CMDBChangeOpSetAttributeScalar'),(58,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(60,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(224,'name','CMDBChangeOpSetAttributeScalar'),(297,'name','CMDBChangeOpSetAttributeScalar'),(298,'first_name','CMDBChangeOpSetAttributeScalar'),(299,'ipv4_block_min_size','CMDBChangeOpSetAttributeScalar'),(300,'ipv4_block_cidr_aligned','CMDBChangeOpSetAttributeScalar'),(326,'password','CMDBChangeOpSetAttributeOneWayPassword'),(327,'password_renewed_date','CMDBChangeOpSetAttributeScalar'),(335,'managementip_id','CMDBChangeOpSetAttributeScalar'),(392,'status','CMDBChangeOpSetAttributeScalar'),(431,'domain_id','CMDBChangeOpSetAttributeScalar'),(432,'fqdn','CMDBChangeOpSetAttributeScalar'),(434,'status','CMDBChangeOpSetAttributeScalar'),(435,'allocation_date','CMDBChangeOpSetAttributeScalar'),(436,'name','CMDBChangeOpSetAttributeScalar'),(438,'status','CMDBChangeOpSetAttributeScalar'),(439,'allocation_date','CMDBChangeOpSetAttributeScalar'),(441,'status','CMDBChangeOpSetAttributeScalar'),(442,'allocation_date','CMDBChangeOpSetAttributeScalar'),(443,'osfamily_id','CMDBChangeOpSetAttributeScalar'),(445,'status','CMDBChangeOpSetAttributeScalar'),(446,'allocation_date','CMDBChangeOpSetAttributeScalar'),(448,'status','CMDBChangeOpSetAttributeScalar'),(449,'allocation_date','CMDBChangeOpSetAttributeScalar'),(451,'status','CMDBChangeOpSetAttributeScalar'),(452,'allocation_date','CMDBChangeOpSetAttributeScalar'),(454,'status','CMDBChangeOpSetAttributeScalar'),(455,'allocation_date','CMDBChangeOpSetAttributeScalar'),(457,'status','CMDBChangeOpSetAttributeScalar'),(458,'allocation_date','CMDBChangeOpSetAttributeScalar'),(460,'status','CMDBChangeOpSetAttributeScalar'),(461,'allocation_date','CMDBChangeOpSetAttributeScalar'),(463,'status','CMDBChangeOpSetAttributeScalar'),(464,'allocation_date','CMDBChangeOpSetAttributeScalar'),(466,'status','CMDBChangeOpSetAttributeScalar'),(467,'allocation_date','CMDBChangeOpSetAttributeScalar'),(469,'status','CMDBChangeOpSetAttributeScalar'),(470,'allocation_date','CMDBChangeOpSetAttributeScalar'),(473,'physicalinterface_list','CMDBChangeOpSetAttributeLinksAddRemove'),(475,'physicalinterface_list','CMDBChangeOpSetAttributeLinksAddRemove'),(477,'physicalinterface_list','CMDBChangeOpSetAttributeLinksAddRemove'),(479,'physicalinterface_list','CMDBChangeOpSetAttributeLinksAddRemove'),(481,'physicalinterface_list','CMDBChangeOpSetAttributeLinksAddRemove'),(483,'physicalinterface_list','CMDBChangeOpSetAttributeLinksAddRemove'),(485,'physicalinterface_list','CMDBChangeOpSetAttributeLinksAddRemove'),(487,'physicalinterface_list','CMDBChangeOpSetAttributeLinksAddRemove'),(489,'business_criticity','CMDBChangeOpSetAttributeScalar'),(490,'location_id','CMDBChangeOpSetAttributeScalar'),(491,'physicalinterface_list','CMDBChangeOpSetAttributeLinksAddRemove'),(493,'physicalinterface_list','CMDBChangeOpSetAttributeLinksAddRemove'),(495,'location_id','CMDBChangeOpSetAttributeScalar'),(496,'physicalinterface_list','CMDBChangeOpSetAttributeLinksAddRemove'),(498,'physicalinterface_list','CMDBChangeOpSetAttributeLinksAddRemove'),(500,'ip_list','CMDBChangeOpSetAttributeLinksAddRemove'),(502,'status','CMDBChangeOpSetAttributeScalar'),(503,'allocation_date','CMDBChangeOpSetAttributeScalar'),(505,'ip_list','CMDBChangeOpSetAttributeLinksAddRemove'),(508,'ip_list','CMDBChangeOpSetAttributeLinksAddRemove'),(511,'ip_list','CMDBChangeOpSetAttributeLinksAddRemove'),(513,'ip_list','CMDBChangeOpSetAttributeLinksAddRemove'),(515,'status','CMDBChangeOpSetAttributeScalar'),(516,'allocation_date','CMDBChangeOpSetAttributeScalar'),(518,'ip_list','CMDBChangeOpSetAttributeLinksAddRemove'),(521,'ip_list','CMDBChangeOpSetAttributeLinksAddRemove'),(524,'ip_list','CMDBChangeOpSetAttributeLinksAddRemove'),(526,'ip_list','CMDBChangeOpSetAttributeLinksAddRemove'),(528,'status','CMDBChangeOpSetAttributeScalar'),(529,'allocation_date','CMDBChangeOpSetAttributeScalar'),(531,'ip_list','CMDBChangeOpSetAttributeLinksAddRemove'),(534,'ip_list','CMDBChangeOpSetAttributeLinksAddRemove'),(536,'ip_list','CMDBChangeOpSetAttributeLinksAddRemove'),(538,'status','CMDBChangeOpSetAttributeScalar'),(539,'allocation_date','CMDBChangeOpSetAttributeScalar'),(540,'usage_id','CMDBChangeOpSetAttributeScalar'),(542,'status','CMDBChangeOpSetAttributeScalar'),(543,'allocation_date','CMDBChangeOpSetAttributeScalar'),(545,'status','CMDBChangeOpSetAttributeScalar'),(546,'allocation_date','CMDBChangeOpSetAttributeScalar'),(548,'status','CMDBChangeOpSetAttributeScalar'),(549,'allocation_date','CMDBChangeOpSetAttributeScalar'),(551,'status','CMDBChangeOpSetAttributeScalar'),(552,'allocation_date','CMDBChangeOpSetAttributeScalar'),(555,'status','CMDBChangeOpSetAttributeScalar'),(556,'usage_id','CMDBChangeOpSetAttributeScalar'),(558,'status','CMDBChangeOpSetAttributeScalar'),(559,'allocation_date','CMDBChangeOpSetAttributeScalar'),(560,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(563,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(566,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(569,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(572,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(575,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(578,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(581,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(584,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(586,'softwares_list','CMDBChangeOpSetAttributeLinksTune'),(587,'name','CMDBChangeOpSetAttributeScalar'),(589,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(592,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(595,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(598,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(601,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(604,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(607,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(610,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(613,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(615,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(617,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(619,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(622,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(624,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(626,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(628,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(630,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(632,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(634,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(636,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(639,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(641,'softwares_list','CMDBChangeOpSetAttributeLinksTune'),(642,'software_id','CMDBChangeOpSetAttributeScalar'),(644,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(646,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(648,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(650,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(652,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(654,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(656,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(658,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(660,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(662,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(664,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(666,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(668,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(670,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(672,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(674,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(676,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(678,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(680,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(682,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(684,'softwares_list','CMDBChangeOpSetAttributeLinksTune'),(685,'software_id','CMDBChangeOpSetAttributeScalar'),(686,'status','CMDBChangeOpSetAttributeScalar'),(687,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(689,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(691,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(694,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(697,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(699,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(701,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(703,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(705,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(707,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(709,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(711,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(713,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(715,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(717,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(719,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(721,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(723,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(725,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(727,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(729,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(731,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(734,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(736,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(738,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(740,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(742,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(744,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(746,'softwares_list','CMDBChangeOpSetAttributeLinksAddRemove'),(748,'webapp_list','CMDBChangeOpSetAttributeLinksAddRemove'),(750,'webapp_list','CMDBChangeOpSetAttributeLinksAddRemove'),(752,'webapp_list','CMDBChangeOpSetAttributeLinksAddRemove'),(754,'webapp_list','CMDBChangeOpSetAttributeLinksAddRemove'),(756,'webapp_list','CMDBChangeOpSetAttributeLinksAddRemove'),(758,'webapp_list','CMDBChangeOpSetAttributeLinksAddRemove'),(760,'webapp_list','CMDBChangeOpSetAttributeLinksAddRemove');
/*!40000 ALTER TABLE `priv_changeop_setatt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_setatt_custfields`
--

DROP TABLE IF EXISTS `priv_changeop_setatt_custfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_changeop_setatt_custfields` (
  `id` int NOT NULL,
  `prevdata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_setatt_custfields`
--

LOCK TABLES `priv_changeop_setatt_custfields` WRITE;
/*!40000 ALTER TABLE `priv_changeop_setatt_custfields` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_changeop_setatt_custfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_setatt_data`
--

DROP TABLE IF EXISTS `priv_changeop_setatt_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_changeop_setatt_data` (
  `id` int NOT NULL,
  `prevdata_data` longblob,
  `prevdata_mimetype` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `prevdata_filename` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `prevdata_downloads_count` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_setatt_data`
--

LOCK TABLES `priv_changeop_setatt_data` WRITE;
/*!40000 ALTER TABLE `priv_changeop_setatt_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_changeop_setatt_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_setatt_encrypted`
--

DROP TABLE IF EXISTS `priv_changeop_setatt_encrypted`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_changeop_setatt_encrypted` (
  `id` int NOT NULL,
  `data` tinyblob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_setatt_encrypted`
--

LOCK TABLES `priv_changeop_setatt_encrypted` WRITE;
/*!40000 ALTER TABLE `priv_changeop_setatt_encrypted` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_changeop_setatt_encrypted` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_setatt_html`
--

DROP TABLE IF EXISTS `priv_changeop_setatt_html`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_changeop_setatt_html` (
  `id` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_setatt_html`
--

LOCK TABLES `priv_changeop_setatt_html` WRITE;
/*!40000 ALTER TABLE `priv_changeop_setatt_html` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_changeop_setatt_html` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_setatt_log`
--

DROP TABLE IF EXISTS `priv_changeop_setatt_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_changeop_setatt_log` (
  `id` int NOT NULL,
  `lastentry` int DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_setatt_log`
--

LOCK TABLES `priv_changeop_setatt_log` WRITE;
/*!40000 ALTER TABLE `priv_changeop_setatt_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_changeop_setatt_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_setatt_longtext`
--

DROP TABLE IF EXISTS `priv_changeop_setatt_longtext`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_changeop_setatt_longtext` (
  `id` int NOT NULL,
  `prevdata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `optype` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'CMDBChangeOpSetAttributeLongText',
  PRIMARY KEY (`id`),
  KEY `optype` (`optype`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_setatt_longtext`
--

LOCK TABLES `priv_changeop_setatt_longtext` WRITE;
/*!40000 ALTER TABLE `priv_changeop_setatt_longtext` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_changeop_setatt_longtext` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_setatt_pwd`
--

DROP TABLE IF EXISTS `priv_changeop_setatt_pwd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_changeop_setatt_pwd` (
  `id` int NOT NULL,
  `prev_pwd_hash` tinyblob,
  `prev_pwd_salt` tinyblob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_setatt_pwd`
--

LOCK TABLES `priv_changeop_setatt_pwd` WRITE;
/*!40000 ALTER TABLE `priv_changeop_setatt_pwd` DISABLE KEYS */;
INSERT INTO `priv_changeop_setatt_pwd` VALUES (326,_binary '$2y$10$9LsUgT1lAjuxQdBgQX3hH./IXGAsdxICk1/JSFmbSo10hbf1uj1CG','');
/*!40000 ALTER TABLE `priv_changeop_setatt_pwd` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_setatt_scalar`
--

DROP TABLE IF EXISTS `priv_changeop_setatt_scalar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_changeop_setatt_scalar` (
  `id` int NOT NULL,
  `oldvalue` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `newvalue` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_setatt_scalar`
--

LOCK TABLES `priv_changeop_setatt_scalar` WRITE;
/*!40000 ALTER TABLE `priv_changeop_setatt_scalar` DISABLE KEYS */;
INSERT INTO `priv_changeop_setatt_scalar` VALUES (24,'allow_no_channel','force_at_least_one_channel'),(25,'allow_no_channel','force_at_least_one_channel'),(26,'allow_no_channel','force_at_least_one_channel'),(224,'My Company/Department','MegaQuagga Publishing'),(297,'My last name','Admin Account'),(298,'My first name','MegaQuagga Administrator'),(299,'256','250'),(300,'bca_yes','bca_no'),(327,'2024-09-10','2024-09-22'),(335,'11','0'),(392,'allocated','unassigned'),(431,'0','1'),(432,'vyos-sw-dmz.','vyos-sw-dmz.megaquagga.local.'),(434,'unassigned','allocated'),(435,'','2025-01-02 03:54:36'),(436,'student-host-windows','student-host-windows.megaquagga.local'),(438,'unassigned','allocated'),(439,'','2025-01-02 03:57:39'),(441,'unassigned','allocated'),(442,'','2025-01-02 03:59:03'),(443,'0','27'),(445,'unassigned','allocated'),(446,'','2025-01-02 04:00:38'),(448,'unassigned','allocated'),(449,'2025-01-01 02:58:50','2025-01-02 04:01:35'),(451,'unassigned','allocated'),(452,'','2025-01-02 04:02:17'),(454,'unassigned','allocated'),(455,'','2025-01-02 04:02:47'),(457,'unassigned','allocated'),(458,'','2025-01-02 04:03:29'),(460,'unassigned','allocated'),(461,'','2025-01-02 04:04:19'),(463,'unassigned','allocated'),(464,'','2025-01-02 04:05:05'),(466,'unassigned','allocated'),(467,'','2025-01-02 04:05:43'),(469,'unassigned','allocated'),(470,'','2025-01-02 04:08:42'),(489,'low','high'),(490,'0','1'),(495,'0','1'),(502,'unassigned','allocated'),(503,'','2025-01-02 04:52:14'),(515,'unassigned','allocated'),(516,'','2025-01-02 22:19:43'),(528,'unassigned','allocated'),(529,'','2025-01-02 22:30:29'),(538,'unassigned','allocated'),(539,'','2025-01-02 22:34:17'),(540,'43','44'),(542,'unassigned','allocated'),(543,'','2025-01-02 22:42:51'),(545,'unassigned','allocated'),(546,'','2025-01-02 22:45:22'),(548,'unassigned','allocated'),(549,'','2025-01-02 22:46:20'),(551,'unassigned','allocated'),(552,'','2025-01-02 22:53:41'),(555,'allocated','unassigned'),(556,'0','45'),(558,'unassigned','allocated'),(559,'2025-01-02 23:41:51','2025-01-02 23:46:01'),(587,'Apache httpd 2.4.58','Apache httpd 2.4.58 (Web Server)'),(642,'5','20'),(685,'0','5'),(686,'','active');
/*!40000 ALTER TABLE `priv_changeop_setatt_scalar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_setatt_tagset`
--

DROP TABLE IF EXISTS `priv_changeop_setatt_tagset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_changeop_setatt_tagset` (
  `id` int NOT NULL,
  `oldvalue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `newvalue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_setatt_tagset`
--

LOCK TABLES `priv_changeop_setatt_tagset` WRITE;
/*!40000 ALTER TABLE `priv_changeop_setatt_tagset` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_changeop_setatt_tagset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_setatt_text`
--

DROP TABLE IF EXISTS `priv_changeop_setatt_text`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_changeop_setatt_text` (
  `id` int NOT NULL,
  `prevdata` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_setatt_text`
--

LOCK TABLES `priv_changeop_setatt_text` WRITE;
/*!40000 ALTER TABLE `priv_changeop_setatt_text` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_changeop_setatt_text` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_setatt_url`
--

DROP TABLE IF EXISTS `priv_changeop_setatt_url`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_changeop_setatt_url` (
  `id` int NOT NULL,
  `oldvalue` varchar(2048) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `newvalue` varchar(2048) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_setatt_url`
--

LOCK TABLES `priv_changeop_setatt_url` WRITE;
/*!40000 ALTER TABLE `priv_changeop_setatt_url` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_changeop_setatt_url` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_db_properties`
--

DROP TABLE IF EXISTS `priv_db_properties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_db_properties` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `value` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `change_date` datetime DEFAULT NULL,
  `change_comment` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_db_properties`
--

LOCK TABLES `priv_db_properties` WRITE;
/*!40000 ALTER TABLE `priv_db_properties` DISABLE KEYS */;
INSERT INTO `priv_db_properties` VALUES (1,'database_uuid','Unique ID of this iTop Database','{66E53ED3-B580-DFDA-5924-A9F5590DE9B1}','2024-09-10 00:38:05','Installation/upgrade of iTop');
/*!40000 ALTER TABLE `priv_db_properties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_event`
--

DROP TABLE IF EXISTS `priv_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_event` (
  `id` int NOT NULL AUTO_INCREMENT,
  `message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `date` datetime DEFAULT NULL,
  `userinfo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `realclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Event',
  PRIMARY KEY (`id`),
  KEY `realclass` (`realclass`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_event`
--

LOCK TABLES `priv_event` WRITE;
/*!40000 ALTER TABLE `priv_event` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_event_email`
--

DROP TABLE IF EXISTS `priv_event_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_event_email` (
  `id` int NOT NULL AUTO_INCREMENT,
  `to` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `cc` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `bcc` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `from` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `subject` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `body` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `attachments` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_event_email`
--

LOCK TABLES `priv_event_email` WRITE;
/*!40000 ALTER TABLE `priv_event_email` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_event_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_event_issue`
--

DROP TABLE IF EXISTS `priv_event_issue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_event_issue` (
  `id` int NOT NULL AUTO_INCREMENT,
  `issue` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `impact` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `page` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `arguments_post` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `arguments_get` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `callstack` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_event_issue`
--

LOCK TABLES `priv_event_issue` WRITE;
/*!40000 ALTER TABLE `priv_event_issue` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_event_issue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_event_loginusage`
--

DROP TABLE IF EXISTS `priv_event_loginusage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_event_loginusage` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_event_loginusage`
--

LOCK TABLES `priv_event_loginusage` WRITE;
/*!40000 ALTER TABLE `priv_event_loginusage` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_event_loginusage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_event_newsroom`
--

DROP TABLE IF EXISTS `priv_event_newsroom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_event_newsroom` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `icon_data` longblob,
  `icon_mimetype` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon_filename` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon_downloads_count` int unsigned DEFAULT NULL,
  `priority` enum('1','2','3','4') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '4',
  `url` varchar(2048) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `read` enum('no','yes') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `read_date` datetime DEFAULT NULL,
  `contact_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `title` (`title`(95)),
  KEY `contact_id` (`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_event_newsroom`
--

LOCK TABLES `priv_event_newsroom` WRITE;
/*!40000 ALTER TABLE `priv_event_newsroom` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_event_newsroom` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_event_notification`
--

DROP TABLE IF EXISTS `priv_event_notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_event_notification` (
  `id` int NOT NULL AUTO_INCREMENT,
  `trigger_id` int DEFAULT '0',
  `action_id` int DEFAULT '0',
  `object_id` int DEFAULT '0',
  `realclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'EventNotification',
  PRIMARY KEY (`id`),
  KEY `trigger_id` (`trigger_id`),
  KEY `action_id` (`action_id`),
  KEY `realclass` (`realclass`(95)),
  KEY `object_id` (`object_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_event_notification`
--

LOCK TABLES `priv_event_notification` WRITE;
/*!40000 ALTER TABLE `priv_event_notification` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_event_notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_event_onobject`
--

DROP TABLE IF EXISTS `priv_event_onobject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_event_onobject` (
  `id` int NOT NULL AUTO_INCREMENT,
  `obj_class` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `obj_key` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_event_onobject`
--

LOCK TABLES `priv_event_onobject` WRITE;
/*!40000 ALTER TABLE `priv_event_onobject` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_event_onobject` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_event_restservice`
--

DROP TABLE IF EXISTS `priv_event_restservice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_event_restservice` (
  `id` int NOT NULL AUTO_INCREMENT,
  `operation` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `version` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `json_input` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `code` int DEFAULT '0',
  `json_output` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `provider` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_event_restservice`
--

LOCK TABLES `priv_event_restservice` WRITE;
/*!40000 ALTER TABLE `priv_event_restservice` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_event_restservice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_event_webhook`
--

DROP TABLE IF EXISTS `priv_event_webhook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_event_webhook` (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `webhook_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `headers` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `payload` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `response` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_event_webhook`
--

LOCK TABLES `priv_event_webhook` WRITE;
/*!40000 ALTER TABLE `priv_event_webhook` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_event_webhook` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_event_webservice`
--

DROP TABLE IF EXISTS `priv_event_webservice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_event_webservice` (
  `id` int NOT NULL AUTO_INCREMENT,
  `verb` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `result` tinyint(1) DEFAULT '0',
  `log_info` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `log_warning` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `log_error` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `data` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_event_webservice`
--

LOCK TABLES `priv_event_webservice` WRITE;
/*!40000 ALTER TABLE `priv_event_webservice` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_event_webservice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_extension_install`
--

DROP TABLE IF EXISTS `priv_extension_install`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_extension_install` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `label` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `version` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `source` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `installed` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_extension_install`
--

LOCK TABLES `priv_extension_install` WRITE;
/*!40000 ALTER TABLE `priv_extension_install` DISABLE KEYS */;
INSERT INTO `priv_extension_install` VALUES (1,'itop-config-mgmt-core','Configuration Management Core','3.2.0','datamodels','2024-09-10 00:38:07'),(2,'itop-config-mgmt-datacenter','Data Center Devices','3.2.0','datamodels','2024-09-10 00:38:07'),(3,'itop-config-mgmt-end-user','End-User Devices','3.2.0','datamodels','2024-09-10 00:38:07'),(4,'itop-config-mgmt-storage','Storage Devices','3.2.0','datamodels','2024-09-10 00:38:07'),(5,'itop-config-mgmt-virtualization','Virtualization','3.2.0','datamodels','2024-09-10 00:38:07'),(6,'itop-service-mgmt-enterprise','Service Management for Enterprises','3.2.0','datamodels','2024-09-10 00:38:07'),(7,'itop-ticket-mgmt-simple-ticket-enhanced-portal','Customer Portal','3.2.0','datamodels','2024-09-10 00:38:07'),(8,'itop-ticket-mgmt-simple-ticket','Simple Ticket Management','3.2.0','datamodels','2024-09-10 00:38:07'),(9,'itop-change-mgmt-simple','Simple Change Management','3.2.0','datamodels','2024-09-10 00:38:07'),(10,'itop-config-mgmt-core','Configuration Management Core','3.2.0','datamodels','2024-09-10 00:49:13'),(11,'itop-config-mgmt-datacenter','Data Center Devices','3.2.0','datamodels','2024-09-10 00:49:13'),(12,'itop-config-mgmt-end-user','End-User Devices','3.2.0','datamodels','2024-09-10 00:49:13'),(13,'itop-config-mgmt-storage','Storage Devices','3.2.0','datamodels','2024-09-10 00:49:13'),(14,'itop-config-mgmt-virtualization','Virtualization','3.2.0','datamodels','2024-09-10 00:49:13'),(15,'itop-service-mgmt-enterprise','Service Management for Enterprises','3.2.0','datamodels','2024-09-10 00:49:13'),(16,'itop-ticket-mgmt-simple-ticket-enhanced-portal','Customer Portal','3.2.0','datamodels','2024-09-10 00:49:13'),(17,'itop-ticket-mgmt-simple-ticket','Simple Ticket Management','3.2.0','datamodels','2024-09-10 00:49:13'),(18,'itop-change-mgmt-simple','Simple Change Management','3.2.0','datamodels','2024-09-10 00:49:13'),(19,'teemip-core-ip-mgmt','IPAM for iTop','3.2.0','extensions','2024-09-10 00:49:13'),(20,'itop-config-mgmt-core','Configuration Management Core','3.2.0','datamodels','2024-09-10 03:04:12'),(21,'itop-config-mgmt-datacenter','Data Center Devices','3.2.0','datamodels','2024-09-10 03:04:12'),(22,'itop-config-mgmt-end-user','End-User Devices','3.2.0','datamodels','2024-09-10 03:04:12'),(23,'itop-config-mgmt-storage','Storage Devices','3.2.0','datamodels','2024-09-10 03:04:12'),(24,'itop-config-mgmt-virtualization','Virtualization','3.2.0','datamodels','2024-09-10 03:04:12'),(25,'itop-service-mgmt-enterprise','Service Management for Enterprises','3.2.0','datamodels','2024-09-10 03:04:12'),(26,'itop-ticket-mgmt-simple-ticket-enhanced-portal','Customer Portal','3.2.0','datamodels','2024-09-10 03:04:12'),(27,'itop-ticket-mgmt-simple-ticket','Simple Ticket Management','3.2.0','datamodels','2024-09-10 03:04:12'),(28,'itop-change-mgmt-simple','Simple Change Management','3.2.0','datamodels','2024-09-10 03:04:12'),(29,'teemip-ip-discovery-collector','IP Discovery Collector','3.1.2','extensions','2024-09-10 03:04:12'),(30,'teemip-core-ip-mgmt','IPAM for iTop','3.2.0','extensions','2024-09-10 03:04:12');
/*!40000 ALTER TABLE `priv_extension_install` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_internaluser`
--

DROP TABLE IF EXISTS `priv_internaluser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_internaluser` (
  `id` int NOT NULL AUTO_INCREMENT,
  `reset_pwd_token_hash` tinyblob,
  `reset_pwd_token_salt` tinyblob,
  `finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'UserInternal',
  PRIMARY KEY (`id`),
  KEY `finalclass` (`finalclass`(95))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_internaluser`
--

LOCK TABLES `priv_internaluser` WRITE;
/*!40000 ALTER TABLE `priv_internaluser` DISABLE KEYS */;
INSERT INTO `priv_internaluser` VALUES (1,'','','UserLocal');
/*!40000 ALTER TABLE `priv_internaluser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_link_action_trigger`
--

DROP TABLE IF EXISTS `priv_link_action_trigger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_link_action_trigger` (
  `link_id` int NOT NULL AUTO_INCREMENT,
  `action_id` int DEFAULT '0',
  `trigger_id` int DEFAULT '0',
  `order` int DEFAULT '0',
  PRIMARY KEY (`link_id`),
  KEY `action_id` (`action_id`),
  KEY `trigger_id` (`trigger_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_link_action_trigger`
--

LOCK TABLES `priv_link_action_trigger` WRITE;
/*!40000 ALTER TABLE `priv_link_action_trigger` DISABLE KEYS */;
INSERT INTO `priv_link_action_trigger` VALUES (1,1,1,0),(2,1,2,0),(3,1,3,0),(4,2,2,0),(5,2,1,0),(6,2,3,0);
/*!40000 ALTER TABLE `priv_link_action_trigger` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_link_audit_category_domain`
--

DROP TABLE IF EXISTS `priv_link_audit_category_domain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_link_audit_category_domain` (
  `id` int NOT NULL AUTO_INCREMENT,
  `category_id` int DEFAULT '0',
  `domain_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`),
  KEY `domain_id` (`domain_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_link_audit_category_domain`
--

LOCK TABLES `priv_link_audit_category_domain` WRITE;
/*!40000 ALTER TABLE `priv_link_audit_category_domain` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_link_audit_category_domain` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_lnk_action_notif_to_contact`
--

DROP TABLE IF EXISTS `priv_lnk_action_notif_to_contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_lnk_action_notif_to_contact` (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_id` int DEFAULT '0',
  `contact_id` int DEFAULT '0',
  `trigger_id` int DEFAULT '0',
  `subscribed` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `action_id` (`action_id`),
  KEY `contact_id` (`contact_id`),
  KEY `trigger_id` (`trigger_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_lnk_action_notif_to_contact`
--

LOCK TABLES `priv_lnk_action_notif_to_contact` WRITE;
/*!40000 ALTER TABLE `priv_lnk_action_notif_to_contact` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_lnk_action_notif_to_contact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_module_install`
--

DROP TABLE IF EXISTS `priv_module_install`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_module_install` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `version` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `installed` datetime DEFAULT NULL,
  `comment` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `parent_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95)),
  KEY `version` (`version`(95)),
  KEY `parent_id` (`parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=156 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_module_install`
--

LOCK TABLES `priv_module_install` WRITE;
/*!40000 ALTER TABLE `priv_module_install` DISABLE KEYS */;
INSERT INTO `priv_module_install` VALUES (1,'datamodel','3.2.0','2024-09-10 00:38:07','{\"source_dir\":\"datamodels\\/2.x\\/\"}',0),(2,'iTop','3.2.0-14524','2024-09-10 00:38:07','Done by the setup program\nBuilt on 2024-08-08 17:40:01',0),(3,'authent-cas','3.2.0','2024-09-10 00:38:07','Done by the setup program\nMandatory\nVisible (during the setup)',2),(4,'authent-external','3.2.0','2024-09-10 00:38:07','Done by the setup program\nOptional\nVisible (during the setup)',2),(5,'authent-ldap','3.2.0','2024-09-10 00:38:07','Done by the setup program\nOptional\nVisible (during the setup)',2),(6,'authent-local','3.2.0','2024-09-10 00:38:07','Done by the setup program\nMandatory\nVisible (during the setup)',2),(7,'combodo-backoffice-darkmoon-theme','3.2.0','2024-09-10 00:38:07','Done by the setup program\nMandatory\nHidden (selected automatically)',2),(8,'combodo-backoffice-fullmoon-high-contrast-theme','3.2.0','2024-09-10 00:38:07','Done by the setup program\nMandatory\nHidden (selected automatically)',2),(9,'combodo-backoffice-fullmoon-protanopia-deuteranopia-theme','3.2.0','2024-09-10 00:38:07','Done by the setup program\nMandatory\nHidden (selected automatically)',2),(10,'combodo-backoffice-fullmoon-tritanopia-theme','3.2.0','2024-09-10 00:38:07','Done by the setup program\nMandatory\nHidden (selected automatically)',2),(11,'itop-backup','3.2.0','2024-09-10 00:38:07','Done by the setup program\nMandatory\nHidden (selected automatically)',2),(12,'itop-config','3.2.0','2024-09-10 00:38:07','Done by the setup program\nMandatory\nHidden (selected automatically)',2),(13,'itop-files-information','3.2.0','2024-09-10 00:38:07','Done by the setup program\nOptional\nHidden (selected automatically)',2),(14,'itop-portal-base','3.2.0','2024-09-10 00:38:07','Done by the setup program\nMandatory\nHidden (selected automatically)',2),(15,'itop-profiles-itil','3.2.0','2024-09-10 00:38:07','Done by the setup program\nMandatory\nHidden (selected automatically)',2),(16,'itop-sla-computation','3.2.0','2024-09-10 00:38:07','Done by the setup program\nMandatory\nHidden (selected automatically)',2),(17,'itop-structure','3.2.0','2024-09-10 00:38:07','Done by the setup program\nMandatory\nHidden (selected automatically)',2),(18,'itop-welcome-itil','3.2.0','2024-09-10 00:38:07','Done by the setup program\nMandatory\nHidden (selected automatically)',2),(19,'authent-token','2.1.7','2024-09-10 00:38:07','Done by the setup program\nMandatory\nHidden (selected automatically)\nDepends on module: itop-welcome-itil/2.7.0||itop-structure/3.0.0',2),(20,'combodo-db-tools','3.2.0','2024-09-10 00:38:07','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-structure/3.0.0',2),(21,'combodo-password-expiration','1.0.2','2024-09-10 00:38:07','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: authent-local/2.7.0',2),(22,'combodo-webhook-integration','1.4.0','2024-09-10 00:38:07','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-structure/3.2.0',2),(23,'itop-attachments','3.2.0','2024-09-10 00:38:07','Done by the setup program\nOptional\nVisible (during the setup)',2),(24,'itop-config-mgmt','3.2.0','2024-09-10 00:38:07','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-structure/2.7.1',2),(25,'itop-core-update','3.2.0','2024-09-10 00:38:07','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-files-information/2.7.0\nDepends on module: combodo-db-tools/2.7.0',2),(26,'itop-hub-connector','3.2.0','2024-09-10 00:38:07','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.4.0',2),(27,'itop-oauth-client','3.2.0','2024-09-10 00:38:07','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-welcome-itil/3.1.0,',2),(28,'itop-themes-compat','3.2.0','2024-09-10 00:38:07','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-structure/3.1.0',2),(29,'itop-tickets','3.2.0','2024-09-10 00:38:07','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-structure/2.7.1',2),(30,'itop-datacenter-mgmt','3.2.0','2024-09-10 00:38:07','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.2.0',2),(31,'itop-endusers-devices','3.2.0','2024-09-10 00:38:07','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.2.0',2),(32,'itop-storage-mgmt','3.2.0','2024-09-10 00:38:07','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.4.0',2),(33,'itop-virtualization-mgmt','3.2.0','2024-09-10 00:38:07','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.4.0',2),(34,'itop-bridge-cmdb-ticket','3.2.0','2024-09-10 00:38:07','Done by the setup program\nOptional\nHidden (selected automatically)\nDepends on module: itop-config-mgmt/2.7.1\nDepends on module: itop-tickets/2.7.0',2),(35,'itop-bridge-virtualization-storage','3.2.0','2024-09-10 00:38:07','Done by the setup program\nOptional\nHidden (selected automatically)\nDepends on module: itop-storage-mgmt/2.2.0\nDepends on module: itop-virtualization-mgmt/2.2.0',2),(36,'itop-service-mgmt','3.2.0','2024-09-10 00:38:07','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-tickets/2.0.0',2),(37,'itop-bridge-cmdb-services','3.2.0','2024-09-10 00:38:07','Done by the setup program\nOptional\nHidden (selected automatically)\nDepends on module: itop-config-mgmt/2.7.1\nDepends on module: itop-service-mgmt/2.7.1 || itop-service-mgmt-provider/2.7.1',2),(38,'itop-bridge-datacenter-mgmt-services','3.2.0','2024-09-10 00:38:07','Done by the setup program\nOptional\nHidden (selected automatically)\nDepends on module: itop-config-mgmt/2.7.1\nDepends on module: itop-service-mgmt/2.7.1 || itop-service-mgmt-provider/2.7.1\nDepends on module: itop-datacenter-mgmt/3.1.0',2),(39,'itop-bridge-endusers-devices-services','3.2.0','2024-09-10 00:38:07','Done by the setup program\nOptional\nHidden (selected automatically)\nDepends on module: itop-config-mgmt/2.7.1\nDepends on module: itop-service-mgmt/2.7.1 || itop-service-mgmt-provider/2.7.1\nDepends on module: itop-endusers-devices/3.1.0',2),(40,'itop-bridge-storage-mgmt-services','3.2.0','2024-09-10 00:38:07','Done by the setup program\nOptional\nHidden (selected automatically)\nDepends on module: itop-config-mgmt/2.7.1\nDepends on module: itop-service-mgmt/2.7.1 || itop-service-mgmt-provider/2.7.1\nDepends on module: itop-storage-mgmt/3.1.0',2),(41,'itop-bridge-virtualization-mgmt-services','3.2.0','2024-09-10 00:38:07','Done by the setup program\nOptional\nHidden (selected automatically)\nDepends on module: itop-config-mgmt/2.7.1\nDepends on module: itop-service-mgmt/2.7.1 || itop-service-mgmt-provider/2.7.1\nDepends on module: itop-virtualization-mgmt/3.1.0',2),(42,'itop-request-mgmt','3.2.0','2024-09-10 00:38:07','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-tickets/2.4.0',2),(43,'itop-portal','3.2.0','2024-09-10 00:38:07','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-portal-base/2.7.0',2),(44,'itop-change-mgmt','3.2.0','2024-09-10 00:38:07','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.2.0\nDepends on module: itop-tickets/2.0.0',2),(45,'datamodel','3.2.0','2024-09-10 00:49:13','{\"source_dir\":\"datamodels\\/2.x\\/\"}',0),(46,'iTop','3.2.0-14524','2024-09-10 00:49:13','Done by the setup program\nBuilt on 2024-08-08 17:40:01',0),(47,'authent-cas','3.2.0','2024-09-10 00:49:13','Done by the setup program\nMandatory\nVisible (during the setup)',46),(48,'authent-external','3.2.0','2024-09-10 00:49:13','Done by the setup program\nOptional\nVisible (during the setup)',46),(49,'authent-ldap','3.2.0','2024-09-10 00:49:13','Done by the setup program\nOptional\nVisible (during the setup)',46),(50,'authent-local','3.2.0','2024-09-10 00:49:13','Done by the setup program\nMandatory\nVisible (during the setup)',46),(51,'combodo-backoffice-darkmoon-theme','3.2.0','2024-09-10 00:49:13','Done by the setup program\nMandatory\nHidden (selected automatically)',46),(52,'combodo-backoffice-fullmoon-high-contrast-theme','3.2.0','2024-09-10 00:49:13','Done by the setup program\nMandatory\nHidden (selected automatically)',46),(53,'combodo-backoffice-fullmoon-protanopia-deuteranopia-theme','3.2.0','2024-09-10 00:49:13','Done by the setup program\nMandatory\nHidden (selected automatically)',46),(54,'combodo-backoffice-fullmoon-tritanopia-theme','3.2.0','2024-09-10 00:49:13','Done by the setup program\nMandatory\nHidden (selected automatically)',46),(55,'itop-backup','3.2.0','2024-09-10 00:49:13','Done by the setup program\nMandatory\nHidden (selected automatically)',46),(56,'itop-config','3.2.0','2024-09-10 00:49:13','Done by the setup program\nMandatory\nHidden (selected automatically)',46),(57,'itop-files-information','3.2.0','2024-09-10 00:49:13','Done by the setup program\nOptional\nHidden (selected automatically)',46),(58,'itop-portal-base','3.2.0','2024-09-10 00:49:13','Done by the setup program\nMandatory\nHidden (selected automatically)',46),(59,'itop-profiles-itil','3.2.0','2024-09-10 00:49:13','Done by the setup program\nMandatory\nHidden (selected automatically)',46),(60,'itop-sla-computation','3.2.0','2024-09-10 00:49:13','Done by the setup program\nMandatory\nHidden (selected automatically)',46),(61,'itop-structure','3.2.0','2024-09-10 00:49:13','Done by the setup program\nMandatory\nHidden (selected automatically)',46),(62,'itop-welcome-itil','3.2.0','2024-09-10 00:49:13','Done by the setup program\nMandatory\nHidden (selected automatically)',46),(63,'authent-token','2.1.7','2024-09-10 00:49:13','Done by the setup program\nMandatory\nHidden (selected automatically)\nDepends on module: itop-welcome-itil/2.7.0||itop-structure/3.0.0',46),(64,'teemip-framework','3.2.0','2024-09-10 00:49:13','Done by the setup program\nMandatory\nHidden (selected automatically)\nDepends on module: itop-config-mgmt/3.1.0',46),(65,'teemip-webservices','3.2.0','2024-09-10 00:49:13','Done by the setup program\nMandatory\nHidden (selected automatically)\nDepends on module: teemip-ip-mgmt/3.2.0',46),(66,'combodo-db-tools','3.2.0','2024-09-10 00:49:13','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-structure/3.0.0',46),(67,'combodo-password-expiration','1.0.2','2024-09-10 00:49:13','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: authent-local/2.7.0',46),(68,'combodo-webhook-integration','1.4.0','2024-09-10 00:49:13','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-structure/3.2.0',46),(69,'itop-attachments','3.2.0','2024-09-10 00:49:13','Done by the setup program\nOptional\nVisible (during the setup)',46),(70,'itop-config-mgmt','3.2.0','2024-09-10 00:49:13','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-structure/2.7.1',46),(71,'itop-core-update','3.2.0','2024-09-10 00:49:13','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-files-information/2.7.0\nDepends on module: combodo-db-tools/2.7.0',46),(72,'itop-hub-connector','3.2.0','2024-09-10 00:49:13','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.4.0',46),(73,'itop-oauth-client','3.2.0','2024-09-10 00:49:13','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-welcome-itil/3.1.0,',46),(74,'itop-themes-compat','3.2.0','2024-09-10 00:49:13','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-structure/3.1.0',46),(75,'itop-tickets','3.2.0','2024-09-10 00:49:13','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-structure/2.7.1',46),(76,'itop-datacenter-mgmt','3.2.0','2024-09-10 00:49:13','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.2.0',46),(77,'itop-endusers-devices','3.2.0','2024-09-10 00:49:13','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.2.0',46),(78,'itop-storage-mgmt','3.2.0','2024-09-10 00:49:13','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.4.0',46),(79,'itop-virtualization-mgmt','3.2.0','2024-09-10 00:49:13','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.4.0',46),(80,'itop-bridge-cmdb-ticket','3.2.0','2024-09-10 00:49:13','Done by the setup program\nOptional\nHidden (selected automatically)\nDepends on module: itop-config-mgmt/2.7.1\nDepends on module: itop-tickets/2.7.0',46),(81,'itop-bridge-virtualization-storage','3.2.0','2024-09-10 00:49:13','Done by the setup program\nOptional\nHidden (selected automatically)\nDepends on module: itop-storage-mgmt/2.2.0\nDepends on module: itop-virtualization-mgmt/2.2.0',46),(82,'itop-service-mgmt','3.2.0','2024-09-10 00:49:13','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-tickets/2.0.0',46),(83,'itop-bridge-cmdb-services','3.2.0','2024-09-10 00:49:13','Done by the setup program\nOptional\nHidden (selected automatically)\nDepends on module: itop-config-mgmt/2.7.1\nDepends on module: itop-service-mgmt/2.7.1 || itop-service-mgmt-provider/2.7.1',46),(84,'itop-bridge-datacenter-mgmt-services','3.2.0','2024-09-10 00:49:13','Done by the setup program\nOptional\nHidden (selected automatically)\nDepends on module: itop-config-mgmt/2.7.1\nDepends on module: itop-service-mgmt/2.7.1 || itop-service-mgmt-provider/2.7.1\nDepends on module: itop-datacenter-mgmt/3.1.0',46),(85,'itop-bridge-endusers-devices-services','3.2.0','2024-09-10 00:49:13','Done by the setup program\nOptional\nHidden (selected automatically)\nDepends on module: itop-config-mgmt/2.7.1\nDepends on module: itop-service-mgmt/2.7.1 || itop-service-mgmt-provider/2.7.1\nDepends on module: itop-endusers-devices/3.1.0',46),(86,'itop-bridge-storage-mgmt-services','3.2.0','2024-09-10 00:49:13','Done by the setup program\nOptional\nHidden (selected automatically)\nDepends on module: itop-config-mgmt/2.7.1\nDepends on module: itop-service-mgmt/2.7.1 || itop-service-mgmt-provider/2.7.1\nDepends on module: itop-storage-mgmt/3.1.0',46),(87,'itop-bridge-virtualization-mgmt-services','3.2.0','2024-09-10 00:49:13','Done by the setup program\nOptional\nHidden (selected automatically)\nDepends on module: itop-config-mgmt/2.7.1\nDepends on module: itop-service-mgmt/2.7.1 || itop-service-mgmt-provider/2.7.1\nDepends on module: itop-virtualization-mgmt/3.1.0',46),(88,'itop-request-mgmt','3.2.0','2024-09-10 00:49:13','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-tickets/2.4.0',46),(89,'itop-portal','3.2.0','2024-09-10 00:49:13','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-portal-base/2.7.0',46),(90,'itop-change-mgmt','3.2.0','2024-09-10 00:49:13','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.2.0\nDepends on module: itop-tickets/2.0.0',46),(91,'teemip-ip-mgmt','3.2.0','2024-09-10 00:49:13','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-tickets/3.1.0\nDepends on module: teemip-framework/3.2.0\nDepends on module: teemip-network-mgmt/3.2.0',46),(92,'teemip-newsroom-provider','1.2.0','2024-09-10 00:49:13','Done by the setup program\nOptional\nHidden (selected automatically)\nDepends on module: teemip-ip-mgmt/3.2.0',46),(93,'teemip-network-mgmt','3.2.0','2024-09-10 00:49:13','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: teemip-framework/3.2.0',46),(94,'teemip-ipv6-mgmt','3.2.0','2024-09-10 00:49:13','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: teemip-ip-mgmt/3.2.0',46),(95,'teemip-config-mgmt-adaptor','3.2.0','2024-09-10 00:49:13','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/3.1.0\nDepends on module: teemip-ip-mgmt/3.2.0',46),(96,'teemip-datacenter-mgmt-adaptor','3.2.0','2024-09-10 00:49:13','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-datacenter-mgmt/3.1.0\nDepends on module: teemip-ip-mgmt/3.2.0\nDepends on module: teemip-config-mgmt-adaptor/3.2.0',46),(97,'teemip-endusers-devices-adaptor','3.2.0','2024-09-10 00:49:13','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-endusers-devices/3.1.0\nDepends on module: teemip-ip-mgmt/3.2.0\nDepends on module: teemip-config-mgmt-adaptor/3.2.0',46),(98,'teemip-storage-mgmt-adaptor','3.2.0','2024-09-10 00:49:13','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-storage-mgmt/3.1.0\nDepends on module: teemip-ip-mgmt/3.2.0\nDepends on module: teemip-config-mgmt-adaptor/3.2.0',46),(99,'teemip-virtualization-mgmt-adaptor','3.2.0','2024-09-10 00:49:13','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/3.1.0\nDepends on module: itop-virtualization-mgmt/3.1.0\nDepends on module: teemip-ip-mgmt/3.2.0\nDepends on module: teemip-config-mgmt-adaptor/3.2.0',46),(100,'datamodel','3.2.0','2024-09-10 03:04:12','{\"source_dir\":\"datamodels\\/2.x\\/\"}',0),(101,'iTop','3.2.0-14524','2024-09-10 03:04:12','Done by the setup program\nBuilt on 2024-08-08 17:40:01',0),(102,'authent-cas','3.2.0','2024-09-10 03:04:12','Done by the setup program\nMandatory\nVisible (during the setup)',101),(103,'authent-external','3.2.0','2024-09-10 03:04:12','Done by the setup program\nOptional\nVisible (during the setup)',101),(104,'authent-ldap','3.2.0','2024-09-10 03:04:12','Done by the setup program\nOptional\nVisible (during the setup)',101),(105,'authent-local','3.2.0','2024-09-10 03:04:12','Done by the setup program\nMandatory\nVisible (during the setup)',101),(106,'combodo-backoffice-darkmoon-theme','3.2.0','2024-09-10 03:04:12','Done by the setup program\nMandatory\nHidden (selected automatically)',101),(107,'combodo-backoffice-fullmoon-high-contrast-theme','3.2.0','2024-09-10 03:04:12','Done by the setup program\nMandatory\nHidden (selected automatically)',101),(108,'combodo-backoffice-fullmoon-protanopia-deuteranopia-theme','3.2.0','2024-09-10 03:04:12','Done by the setup program\nMandatory\nHidden (selected automatically)',101),(109,'combodo-backoffice-fullmoon-tritanopia-theme','3.2.0','2024-09-10 03:04:12','Done by the setup program\nMandatory\nHidden (selected automatically)',101),(110,'itop-backup','3.2.0','2024-09-10 03:04:12','Done by the setup program\nMandatory\nHidden (selected automatically)',101),(111,'itop-config','3.2.0','2024-09-10 03:04:12','Done by the setup program\nMandatory\nHidden (selected automatically)',101),(112,'itop-files-information','3.2.0','2024-09-10 03:04:12','Done by the setup program\nOptional\nHidden (selected automatically)',101),(113,'itop-portal-base','3.2.0','2024-09-10 03:04:12','Done by the setup program\nMandatory\nHidden (selected automatically)',101),(114,'itop-profiles-itil','3.2.0','2024-09-10 03:04:12','Done by the setup program\nMandatory\nHidden (selected automatically)',101),(115,'itop-sla-computation','3.2.0','2024-09-10 03:04:12','Done by the setup program\nMandatory\nHidden (selected automatically)',101),(116,'itop-structure','3.2.0','2024-09-10 03:04:12','Done by the setup program\nMandatory\nHidden (selected automatically)',101),(117,'itop-welcome-itil','3.2.0','2024-09-10 03:04:12','Done by the setup program\nMandatory\nHidden (selected automatically)',101),(118,'authent-token','2.1.7','2024-09-10 03:04:12','Done by the setup program\nMandatory\nHidden (selected automatically)\nDepends on module: itop-welcome-itil/2.7.0||itop-structure/3.0.0',101),(119,'teemip-framework','3.2.0','2024-09-10 03:04:12','Done by the setup program\nMandatory\nHidden (selected automatically)\nDepends on module: itop-config-mgmt/3.1.0',101),(120,'teemip-webservices','3.2.0','2024-09-10 03:04:12','Done by the setup program\nMandatory\nHidden (selected automatically)\nDepends on module: teemip-ip-mgmt/3.2.0',101),(121,'combodo-db-tools','3.2.0','2024-09-10 03:04:12','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-structure/3.0.0',101),(122,'combodo-password-expiration','1.0.2','2024-09-10 03:04:12','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: authent-local/2.7.0',101),(123,'combodo-webhook-integration','1.4.0','2024-09-10 03:04:12','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-structure/3.2.0',101),(124,'itop-attachments','3.2.0','2024-09-10 03:04:12','Done by the setup program\nOptional\nVisible (during the setup)',101),(125,'itop-config-mgmt','3.2.0','2024-09-10 03:04:12','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-structure/2.7.1',101),(126,'itop-core-update','3.2.0','2024-09-10 03:04:12','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-files-information/2.7.0\nDepends on module: combodo-db-tools/2.7.0',101),(127,'itop-hub-connector','3.2.0','2024-09-10 03:04:12','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.4.0',101),(128,'itop-oauth-client','3.2.0','2024-09-10 03:04:12','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-welcome-itil/3.1.0,',101),(129,'itop-themes-compat','3.2.0','2024-09-10 03:04:12','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-structure/3.1.0',101),(130,'itop-tickets','3.2.0','2024-09-10 03:04:12','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-structure/2.7.1',101),(131,'itop-datacenter-mgmt','3.2.0','2024-09-10 03:04:12','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.2.0',101),(132,'itop-endusers-devices','3.2.0','2024-09-10 03:04:12','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.2.0',101),(133,'itop-storage-mgmt','3.2.0','2024-09-10 03:04:12','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.4.0',101),(134,'itop-virtualization-mgmt','3.2.0','2024-09-10 03:04:12','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.4.0',101),(135,'itop-bridge-cmdb-ticket','3.2.0','2024-09-10 03:04:12','Done by the setup program\nOptional\nHidden (selected automatically)\nDepends on module: itop-config-mgmt/2.7.1\nDepends on module: itop-tickets/2.7.0',101),(136,'itop-bridge-virtualization-storage','3.2.0','2024-09-10 03:04:12','Done by the setup program\nOptional\nHidden (selected automatically)\nDepends on module: itop-storage-mgmt/2.2.0\nDepends on module: itop-virtualization-mgmt/2.2.0',101),(137,'itop-service-mgmt','3.2.0','2024-09-10 03:04:12','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-tickets/2.0.0',101),(138,'itop-bridge-cmdb-services','3.2.0','2024-09-10 03:04:12','Done by the setup program\nOptional\nHidden (selected automatically)\nDepends on module: itop-config-mgmt/2.7.1\nDepends on module: itop-service-mgmt/2.7.1 || itop-service-mgmt-provider/2.7.1',101),(139,'itop-bridge-datacenter-mgmt-services','3.2.0','2024-09-10 03:04:12','Done by the setup program\nOptional\nHidden (selected automatically)\nDepends on module: itop-config-mgmt/2.7.1\nDepends on module: itop-service-mgmt/2.7.1 || itop-service-mgmt-provider/2.7.1\nDepends on module: itop-datacenter-mgmt/3.1.0',101),(140,'itop-bridge-endusers-devices-services','3.2.0','2024-09-10 03:04:12','Done by the setup program\nOptional\nHidden (selected automatically)\nDepends on module: itop-config-mgmt/2.7.1\nDepends on module: itop-service-mgmt/2.7.1 || itop-service-mgmt-provider/2.7.1\nDepends on module: itop-endusers-devices/3.1.0',101),(141,'itop-bridge-storage-mgmt-services','3.2.0','2024-09-10 03:04:12','Done by the setup program\nOptional\nHidden (selected automatically)\nDepends on module: itop-config-mgmt/2.7.1\nDepends on module: itop-service-mgmt/2.7.1 || itop-service-mgmt-provider/2.7.1\nDepends on module: itop-storage-mgmt/3.1.0',101),(142,'itop-bridge-virtualization-mgmt-services','3.2.0','2024-09-10 03:04:12','Done by the setup program\nOptional\nHidden (selected automatically)\nDepends on module: itop-config-mgmt/2.7.1\nDepends on module: itop-service-mgmt/2.7.1 || itop-service-mgmt-provider/2.7.1\nDepends on module: itop-virtualization-mgmt/3.1.0',101),(143,'itop-request-mgmt','3.2.0','2024-09-10 03:04:12','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-tickets/2.4.0',101),(144,'itop-portal','3.2.0','2024-09-10 03:04:12','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-portal-base/2.7.0',101),(145,'itop-change-mgmt','3.2.0','2024-09-10 03:04:12','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.2.0\nDepends on module: itop-tickets/2.0.0',101),(146,'teemip-ip-discovery-collector','3.1.2','2024-09-10 03:04:12','Done by the setup program\nOptional\nVisible (during the setup)',101),(147,'teemip-ip-mgmt','3.2.0','2024-09-10 03:04:12','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-tickets/3.1.0\nDepends on module: teemip-framework/3.2.0\nDepends on module: teemip-network-mgmt/3.2.0',101),(148,'teemip-newsroom-provider','1.2.0','2024-09-10 03:04:12','Done by the setup program\nOptional\nHidden (selected automatically)\nDepends on module: teemip-ip-mgmt/3.2.0',101),(149,'teemip-network-mgmt','3.2.0','2024-09-10 03:04:12','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: teemip-framework/3.2.0',101),(150,'teemip-ipv6-mgmt','3.2.0','2024-09-10 03:04:12','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: teemip-ip-mgmt/3.2.0',101),(151,'teemip-config-mgmt-adaptor','3.2.0','2024-09-10 03:04:12','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/3.1.0\nDepends on module: teemip-ip-mgmt/3.2.0',101),(152,'teemip-datacenter-mgmt-adaptor','3.2.0','2024-09-10 03:04:12','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-datacenter-mgmt/3.1.0\nDepends on module: teemip-ip-mgmt/3.2.0\nDepends on module: teemip-config-mgmt-adaptor/3.2.0',101),(153,'teemip-endusers-devices-adaptor','3.2.0','2024-09-10 03:04:12','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-endusers-devices/3.1.0\nDepends on module: teemip-ip-mgmt/3.2.0\nDepends on module: teemip-config-mgmt-adaptor/3.2.0',101),(154,'teemip-storage-mgmt-adaptor','3.2.0','2024-09-10 03:04:12','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-storage-mgmt/3.1.0\nDepends on module: teemip-ip-mgmt/3.2.0\nDepends on module: teemip-config-mgmt-adaptor/3.2.0',101),(155,'teemip-virtualization-mgmt-adaptor','3.2.0','2024-09-10 03:04:12','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/3.1.0\nDepends on module: itop-virtualization-mgmt/3.1.0\nDepends on module: teemip-ip-mgmt/3.2.0\nDepends on module: teemip-config-mgmt-adaptor/3.2.0',101);
/*!40000 ALTER TABLE `priv_module_install` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_oauth_client`
--

DROP TABLE IF EXISTS `priv_oauth_client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_oauth_client` (
  `id` int NOT NULL AUTO_INCREMENT,
  `provider` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `status` enum('active','inactive') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'inactive',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `client_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `client_secret` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `refresh_token` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `refresh_token_expiration` datetime DEFAULT NULL,
  `token` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `token_expiration` datetime DEFAULT NULL,
  `redirect_url` varchar(2048) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'OAuthClient',
  PRIMARY KEY (`id`),
  KEY `provider` (`provider`(95)),
  KEY `name` (`name`(95)),
  KEY `finalclass` (`finalclass`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_oauth_client`
--

LOCK TABLES `priv_oauth_client` WRITE;
/*!40000 ALTER TABLE `priv_oauth_client` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_oauth_client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_oauth_client_azure`
--

DROP TABLE IF EXISTS `priv_oauth_client_azure`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_oauth_client_azure` (
  `id` int NOT NULL AUTO_INCREMENT,
  `scope` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `advanced_scope` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `used_scope` enum('advanced','simple') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'simple',
  `used_for_smtp` enum('no','yes') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `tenant` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'common',
  PRIMARY KEY (`id`),
  FULLTEXT KEY `scope` (`scope`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_oauth_client_azure`
--

LOCK TABLES `priv_oauth_client_azure` WRITE;
/*!40000 ALTER TABLE `priv_oauth_client_azure` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_oauth_client_azure` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_oauth_client_google`
--

DROP TABLE IF EXISTS `priv_oauth_client_google`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_oauth_client_google` (
  `id` int NOT NULL AUTO_INCREMENT,
  `scope` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `advanced_scope` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `used_scope` enum('advanced','simple') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'simple',
  `used_for_smtp` enum('no','yes') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  PRIMARY KEY (`id`),
  FULLTEXT KEY `scope` (`scope`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_oauth_client_google`
--

LOCK TABLES `priv_oauth_client_google` WRITE;
/*!40000 ALTER TABLE `priv_oauth_client_google` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_oauth_client_google` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_ownership_token`
--

DROP TABLE IF EXISTS `priv_ownership_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_ownership_token` (
  `id` int NOT NULL AUTO_INCREMENT,
  `acquired` datetime DEFAULT NULL,
  `last_seen` datetime DEFAULT NULL,
  `obj_class` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `obj_key` int DEFAULT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `user_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `obj_class` (`obj_class`(95)),
  KEY `obj_key` (`obj_key`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_ownership_token`
--

LOCK TABLES `priv_ownership_token` WRITE;
/*!40000 ALTER TABLE `priv_ownership_token` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_ownership_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_personal_token`
--

DROP TABLE IF EXISTS `priv_personal_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_personal_token` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT '0',
  `auth_token_hash` tinyblob,
  `auth_token_salt` tinyblob,
  `application` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `scope` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `expiration_date` datetime DEFAULT NULL,
  `use_count` int DEFAULT '0',
  `last_use_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `application` (`application`(95)),
  FULLTEXT KEY `scope` (`scope`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_personal_token`
--

LOCK TABLES `priv_personal_token` WRITE;
/*!40000 ALTER TABLE `priv_personal_token` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_personal_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_query`
--

DROP TABLE IF EXISTS `priv_query`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_query` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `is_template` enum('yes','no') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `export_count` int DEFAULT '0',
  `export_last_date` datetime DEFAULT NULL,
  `user_id` int DEFAULT '0',
  `realclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Query',
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95)),
  KEY `user_id` (`user_id`),
  KEY `realclass` (`realclass`(95))
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_query`
--

LOCK TABLES `priv_query` WRITE;
/*!40000 ALTER TABLE `priv_query` DISABLE KEYS */;
INSERT INTO `priv_query` VALUES (1,'Agent of the Ticket','Can be used in Notification, to notify the agent of a Ticket.','yes',0,NULL,0,'QueryOQL'),(2,'Agent of the Ticket unless the agent himself triggered the notification','Can be used in Notification, to notify the agent of a Ticket.\n      No email will be send if the person who triggered that notification is the agent himself.\n    ','yes',0,NULL,0,'QueryOQL'),(3,'Caller and Contacts linked to the Ticket','Can be used in Notification, to notify the caller and all contacts associated to a Ticket','yes',0,NULL,0,'QueryOQL'),(4,'Caller of the Ticket','To be used in Notification, to notify the caller of a Ticket','yes',0,NULL,0,'QueryOQL'),(5,'Contacts linked to the Ticket','Can be used in Notification, to notify contacts associated to a Ticket','yes',0,NULL,0,'QueryOQL'),(6,'Manager of the Ticket caller','Can be used in Ticket Notification, to notify the manager of the caller.','yes',0,NULL,0,'QueryOQL'),(7,'Person who triggered the notification','Can be used in Notification, to notify the person whom by their action triggered the notification.\n      If used alone, it returns the person connected to iTop and running that query.\n    ','yes',0,NULL,0,'QueryOQL'),(8,'Team members of the Ticket','Can be used in Notification, to notify the team members, to which the Ticket was dispatched.','yes',0,NULL,0,'QueryOQL'),(9,'Team members of the Ticket other than the agent','Can be used in Notification, to notify the team members, to which the Ticket was dispatched.\n      The agent himself is excluded from that list.\n    ','yes',0,NULL,0,'QueryOQL'),(10,'Team of the Ticket','Can be used in Notification, to notify the team generic email, to which the Ticket was dispatched.','yes',0,NULL,0,'QueryOQL'),(11,'Contacts of a Functional CI','Can be used in Notification, to notify the Contacts linked to the Functional CI.','yes',0,NULL,0,'QueryOQL'),(12,'Contacts of a Service','Can be used in Notification, to notify the Contacts linked to the Service.','yes',0,NULL,0,'QueryOQL'),(13,'Contacts of a Contract','Can be used in Notification, to notify the Contacts linked to the Contract.','yes',0,NULL,0,'QueryOQL');
/*!40000 ALTER TABLE `priv_query` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_query_oql`
--

DROP TABLE IF EXISTS `priv_query_oql`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_query_oql` (
  `id` int NOT NULL AUTO_INCREMENT,
  `oql` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `fields` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_query_oql`
--

LOCK TABLES `priv_query_oql` WRITE;
/*!40000 ALTER TABLE `priv_query_oql` DISABLE KEYS */;
INSERT INTO `priv_query_oql` VALUES (1,'SELECT Person WHERE id=:this->agent_id','id,email'),(2,'SELECT Person WHERE id=:this->agent_id AND id != :current_contact_id','id,email'),(3,'SELECT Contact AS C JOIN lnkContactToTicket AS L ON L.contact_id=C.id WHERE L.ticket_id=:this->id\n      UNION\n      SELECT Person WHERE id=:this->caller_id\n    ','id,email'),(4,'SELECT Person WHERE id=:this->caller_id','id,email'),(5,'SELECT Contact AS C JOIN lnkContactToTicket AS L ON L.contact_id=C.id WHERE L.ticket_id=:this->id','id,email'),(6,'SELECT Person AS manager JOIN Person AS employee ON employee.manager_id = manager.id WHERE employee.id=:this->caller_id','id,email'),(7,'SELECT Person WHERE id = :current_contact_id','id,email'),(8,'SELECT Person AS P JOIN lnkPersonToTeam AS L ON L.person_id=P.id\n      WHERE L.team_id = :this->team_id\n    ','id,email'),(9,'SELECT Person AS P JOIN lnkPersonToTeam AS L ON L.person_id=P.id\n      WHERE L.team_id = :this->team_id AND P.id != :this->agent_id\n    ','id,email'),(10,'SELECT Team WHERE id = :this->team_id','id,email'),(11,'SELECT Contact AS C JOIN lnkContactToFunctionalCI AS L ON L.contact_id=C.id\n      WHERE L.functionalci_id = :this->id\n    ','id,email'),(12,'SELECT Contact AS C JOIN lnkContactToService AS L ON L.contact_id=C.id\n      WHERE L.service_id = :this->id\n    ','id,email'),(13,'SELECT Contact AS C JOIN lnkContactToContract AS L ON L.contact_id=C.id\n      WHERE L.contract_id = :this->id\n    ','id,email');
/*!40000 ALTER TABLE `priv_query_oql` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_shortcut`
--

DROP TABLE IF EXISTS `priv_shortcut`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_shortcut` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT '0',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `context` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `realclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Shortcut',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `name` (`name`(95)),
  KEY `realclass` (`realclass`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_shortcut`
--

LOCK TABLES `priv_shortcut` WRITE;
/*!40000 ALTER TABLE `priv_shortcut` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_shortcut` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_shortcut_oql`
--

DROP TABLE IF EXISTS `priv_shortcut_oql`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_shortcut_oql` (
  `id` int NOT NULL AUTO_INCREMENT,
  `oql` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `auto_reload` enum('none','custom') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'none',
  `auto_reload_sec` int DEFAULT '60',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_shortcut_oql`
--

LOCK TABLES `priv_shortcut_oql` WRITE;
/*!40000 ALTER TABLE `priv_shortcut_oql` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_shortcut_oql` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_sync_att`
--

DROP TABLE IF EXISTS `priv_sync_att`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_sync_att` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sync_source_id` int DEFAULT '0',
  `attcode` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `update` tinyint(1) DEFAULT '1',
  `reconcile` tinyint(1) DEFAULT '0',
  `update_policy` enum('master_locked','master_unlocked','write_if_empty') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'master_locked',
  `finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'SynchroAttribute',
  PRIMARY KEY (`id`),
  KEY `sync_source_id` (`sync_source_id`),
  KEY `attcode` (`attcode`(95)),
  KEY `finalclass` (`finalclass`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_sync_att`
--

LOCK TABLES `priv_sync_att` WRITE;
/*!40000 ALTER TABLE `priv_sync_att` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_sync_att` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_sync_att_extkey`
--

DROP TABLE IF EXISTS `priv_sync_att_extkey`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_sync_att_extkey` (
  `id` int NOT NULL AUTO_INCREMENT,
  `reconciliation_attcode` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_sync_att_extkey`
--

LOCK TABLES `priv_sync_att_extkey` WRITE;
/*!40000 ALTER TABLE `priv_sync_att_extkey` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_sync_att_extkey` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_sync_att_linkset`
--

DROP TABLE IF EXISTS `priv_sync_att_linkset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_sync_att_linkset` (
  `id` int NOT NULL AUTO_INCREMENT,
  `row_separator` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '|',
  `attribute_separator` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT ';',
  `value_separator` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT ':',
  `attribute_qualifier` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '''',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_sync_att_linkset`
--

LOCK TABLES `priv_sync_att_linkset` WRITE;
/*!40000 ALTER TABLE `priv_sync_att_linkset` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_sync_att_linkset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_sync_datasource`
--

DROP TABLE IF EXISTS `priv_sync_datasource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_sync_datasource` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `status` enum('implementation','production','obsolete') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'implementation',
  `user_id` int DEFAULT '0',
  `notify_contact_id` int DEFAULT '0',
  `scope_class` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'lnkTriggerAction',
  `database_table_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `scope_restriction` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `full_load_periodicity` int unsigned DEFAULT NULL,
  `reconciliation_policy` enum('use_primary_key','use_attributes') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'use_attributes',
  `action_on_zero` enum('create','error') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'create',
  `action_on_one` enum('update','error') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'update',
  `action_on_multiple` enum('take_first','create','error') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'error',
  `delete_policy` enum('ignore','delete','update','update_then_delete') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'ignore',
  `delete_policy_update` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `delete_policy_retention` int unsigned DEFAULT NULL,
  `user_delete_policy` enum('everybody','administrators','nobody') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'nobody',
  `url_icon` varchar(2048) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `url_application` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95)),
  KEY `user_id` (`user_id`),
  KEY `notify_contact_id` (`notify_contact_id`),
  KEY `scope_class` (`scope_class`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_sync_datasource`
--

LOCK TABLES `priv_sync_datasource` WRITE;
/*!40000 ALTER TABLE `priv_sync_datasource` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_sync_datasource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_sync_log`
--

DROP TABLE IF EXISTS `priv_sync_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_sync_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sync_source_id` int DEFAULT '0',
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `status` enum('running','completed','error') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'running',
  `status_curr_job` int DEFAULT '0',
  `status_curr_pos` int DEFAULT '0',
  `stats_nb_replica_seen` int DEFAULT '0',
  `stats_nb_replica_total` int DEFAULT '0',
  `stats_nb_obj_deleted` int DEFAULT '0',
  `stats_deleted_errors` int DEFAULT '0',
  `stats_nb_obj_obsoleted` int DEFAULT '0',
  `stats_nb_obj_obsoleted_errors` int DEFAULT '0',
  `stats_nb_obj_created` int DEFAULT '0',
  `stats_nb_obj_created_errors` int DEFAULT '0',
  `stats_nb_obj_created_warnings` int DEFAULT '0',
  `stats_nb_obj_updated` int DEFAULT '0',
  `stats_nb_obj_updated_errors` int DEFAULT '0',
  `stats_nb_obj_updated_warnings` int DEFAULT '0',
  `stats_nb_obj_unchanged_warnings` int DEFAULT '0',
  `stats_nb_replica_reconciled_errors` int DEFAULT '0',
  `stats_nb_replica_disappeared_no_action` int DEFAULT '0',
  `stats_nb_obj_new_updated` int DEFAULT '0',
  `stats_nb_obj_new_updated_warnings` int DEFAULT '0',
  `stats_nb_obj_new_unchanged` int DEFAULT '0',
  `stats_nb_obj_new_unchanged_warnings` int DEFAULT '0',
  `last_error` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `traces` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `memory_usage_peak` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sync_source_id` (`sync_source_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_sync_log`
--

LOCK TABLES `priv_sync_log` WRITE;
/*!40000 ALTER TABLE `priv_sync_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_sync_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_sync_replica`
--

DROP TABLE IF EXISTS `priv_sync_replica`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_sync_replica` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sync_source_id` int DEFAULT '0',
  `dest_id` int DEFAULT '0',
  `dest_class` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `status_last_seen` datetime DEFAULT NULL,
  `status` enum('new','synchronized','modified','orphan','obsolete') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'new',
  `status_dest_creator` tinyint(1) DEFAULT '0',
  `status_last_error` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `status_last_warning` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `info_creation_date` datetime DEFAULT NULL,
  `info_last_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sync_source_id` (`sync_source_id`),
  KEY `dest_class` (`dest_class`(95)),
  KEY `dest_class_dest_id` (`dest_class`(95),`dest_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_sync_replica`
--

LOCK TABLES `priv_sync_replica` WRITE;
/*!40000 ALTER TABLE `priv_sync_replica` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_sync_replica` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_tagfielddata`
--

DROP TABLE IF EXISTS `priv_tagfielddata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_tagfielddata` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `label` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `obj_class` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `obj_attcode` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `label` (`label`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_tagfielddata`
--

LOCK TABLES `priv_tagfielddata` WRITE;
/*!40000 ALTER TABLE `priv_tagfielddata` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_tagfielddata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_temporary_object_descriptor`
--

DROP TABLE IF EXISTS `priv_temporary_object_descriptor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_temporary_object_descriptor` (
  `id` int NOT NULL AUTO_INCREMENT,
  `expiration_date` datetime DEFAULT NULL,
  `temp_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `item_class` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `item_id` int DEFAULT '0',
  `creation_date` datetime DEFAULT NULL,
  `host_class` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `host_id` int DEFAULT '0',
  `host_att_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `operation` enum('create','delete') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'create',
  PRIMARY KEY (`id`),
  KEY `temp_id` (`temp_id`(95)),
  KEY `item_class` (`item_class`(95)),
  KEY `item_class_item_id` (`item_class`(95),`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_temporary_object_descriptor`
--

LOCK TABLES `priv_temporary_object_descriptor` WRITE;
/*!40000 ALTER TABLE `priv_temporary_object_descriptor` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_temporary_object_descriptor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_trigger`
--

DROP TABLE IF EXISTS `priv_trigger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_trigger` (
  `id` int NOT NULL AUTO_INCREMENT,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `context` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `complement` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `subscription_policy` enum('allow_no_channel','force_at_least_one_channel','force_all_channels') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'allow_no_channel',
  `realclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Trigger',
  PRIMARY KEY (`id`),
  KEY `description` (`description`(95)),
  KEY `realclass` (`realclass`(95)),
  FULLTEXT KEY `context` (`context`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_trigger`
--

LOCK TABLES `priv_trigger` WRITE;
/*!40000 ALTER TABLE `priv_trigger` DISABLE KEYS */;
INSERT INTO `priv_trigger` VALUES (1,'Person mentioned on User','','class restriction: User','force_at_least_one_channel','TriggerOnObjectMention'),(2,'Person mentioned on Ticket','','class restriction: Ticket','force_at_least_one_channel','TriggerOnObjectMention'),(3,'Person mentioned on WorkOrder','','class restriction: WorkOrder','force_at_least_one_channel','TriggerOnObjectMention');
/*!40000 ALTER TABLE `priv_trigger` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_trigger_onattblobdownload`
--

DROP TABLE IF EXISTS `priv_trigger_onattblobdownload`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_trigger_onattblobdownload` (
  `id` int NOT NULL AUTO_INCREMENT,
  `realclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'TriggerOnAttributeBlobDownload',
  PRIMARY KEY (`id`),
  KEY `realclass` (`realclass`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_trigger_onattblobdownload`
--

LOCK TABLES `priv_trigger_onattblobdownload` WRITE;
/*!40000 ALTER TABLE `priv_trigger_onattblobdownload` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_trigger_onattblobdownload` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_trigger_onattdownload`
--

DROP TABLE IF EXISTS `priv_trigger_onattdownload`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_trigger_onattdownload` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_trigger_onattdownload`
--

LOCK TABLES `priv_trigger_onattdownload` WRITE;
/*!40000 ALTER TABLE `priv_trigger_onattdownload` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_trigger_onattdownload` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_trigger_onobjcreate`
--

DROP TABLE IF EXISTS `priv_trigger_onobjcreate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_trigger_onobjcreate` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_trigger_onobjcreate`
--

LOCK TABLES `priv_trigger_onobjcreate` WRITE;
/*!40000 ALTER TABLE `priv_trigger_onobjcreate` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_trigger_onobjcreate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_trigger_onobjdelete`
--

DROP TABLE IF EXISTS `priv_trigger_onobjdelete`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_trigger_onobjdelete` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_trigger_onobjdelete`
--

LOCK TABLES `priv_trigger_onobjdelete` WRITE;
/*!40000 ALTER TABLE `priv_trigger_onobjdelete` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_trigger_onobjdelete` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_trigger_onobject`
--

DROP TABLE IF EXISTS `priv_trigger_onobject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_trigger_onobject` (
  `id` int NOT NULL AUTO_INCREMENT,
  `target_class` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'ApplicationSolution',
  `filter` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `realclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'TriggerOnObject',
  PRIMARY KEY (`id`),
  KEY `target_class` (`target_class`(95)),
  KEY `realclass` (`realclass`(95))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_trigger_onobject`
--

LOCK TABLES `priv_trigger_onobject` WRITE;
/*!40000 ALTER TABLE `priv_trigger_onobject` DISABLE KEYS */;
INSERT INTO `priv_trigger_onobject` VALUES (1,'User','','TriggerOnObjectMention'),(2,'Ticket','','TriggerOnObjectMention'),(3,'WorkOrder','','TriggerOnObjectMention');
/*!40000 ALTER TABLE `priv_trigger_onobject` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_trigger_onobjmention`
--

DROP TABLE IF EXISTS `priv_trigger_onobjmention`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_trigger_onobjmention` (
  `id` int NOT NULL AUTO_INCREMENT,
  `mentioned_filter` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_trigger_onobjmention`
--

LOCK TABLES `priv_trigger_onobjmention` WRITE;
/*!40000 ALTER TABLE `priv_trigger_onobjmention` DISABLE KEYS */;
INSERT INTO `priv_trigger_onobjmention` VALUES (1,'SELECT `Person` FROM Person AS `Person` WHERE ((`status` = \'active\') AND ((`org_id` = :current_contact->org_id) OR (`org_id` = :this->org_id)))'),(2,'SELECT `Person` FROM Person AS `Person` WHERE ((`status` = \'active\') AND ((`org_id` = :current_contact->org_id) OR (`org_id` = :this->org_id)))'),(3,'SELECT `Person` FROM Person AS `Person` WHERE ((`status` = \'active\') AND (`org_id` = :current_contact->org_id))');
/*!40000 ALTER TABLE `priv_trigger_onobjmention` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_trigger_onobjupdate`
--

DROP TABLE IF EXISTS `priv_trigger_onobjupdate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_trigger_onobjupdate` (
  `id` int NOT NULL AUTO_INCREMENT,
  `target_attcodes` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  FULLTEXT KEY `target_attcodes` (`target_attcodes`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_trigger_onobjupdate`
--

LOCK TABLES `priv_trigger_onobjupdate` WRITE;
/*!40000 ALTER TABLE `priv_trigger_onobjupdate` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_trigger_onobjupdate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_trigger_onportalupdate`
--

DROP TABLE IF EXISTS `priv_trigger_onportalupdate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_trigger_onportalupdate` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_trigger_onportalupdate`
--

LOCK TABLES `priv_trigger_onportalupdate` WRITE;
/*!40000 ALTER TABLE `priv_trigger_onportalupdate` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_trigger_onportalupdate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_trigger_onstatechange`
--

DROP TABLE IF EXISTS `priv_trigger_onstatechange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_trigger_onstatechange` (
  `id` int NOT NULL AUTO_INCREMENT,
  `state` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `realclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'TriggerOnStateChange',
  PRIMARY KEY (`id`),
  KEY `realclass` (`realclass`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_trigger_onstatechange`
--

LOCK TABLES `priv_trigger_onstatechange` WRITE;
/*!40000 ALTER TABLE `priv_trigger_onstatechange` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_trigger_onstatechange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_trigger_onstateenter`
--

DROP TABLE IF EXISTS `priv_trigger_onstateenter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_trigger_onstateenter` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_trigger_onstateenter`
--

LOCK TABLES `priv_trigger_onstateenter` WRITE;
/*!40000 ALTER TABLE `priv_trigger_onstateenter` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_trigger_onstateenter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_trigger_onstateleave`
--

DROP TABLE IF EXISTS `priv_trigger_onstateleave`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_trigger_onstateleave` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_trigger_onstateleave`
--

LOCK TABLES `priv_trigger_onstateleave` WRITE;
/*!40000 ALTER TABLE `priv_trigger_onstateleave` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_trigger_onstateleave` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_trigger_onwatermark`
--

DROP TABLE IF EXISTS `priv_trigger_onwatermark`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_trigger_onwatermark` (
  `id` int NOT NULL AUTO_INCREMENT,
  `org_id` int DEFAULT '0',
  `target_class` enum('IPv4Subnet','IPv4Range','IPv6Range') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'IPv4Subnet',
  `event` enum('cross_high','cross_low') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'cross_high',
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_trigger_onwatermark`
--

LOCK TABLES `priv_trigger_onwatermark` WRITE;
/*!40000 ALTER TABLE `priv_trigger_onwatermark` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_trigger_onwatermark` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_trigger_threshold`
--

DROP TABLE IF EXISTS `priv_trigger_threshold`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_trigger_threshold` (
  `id` int NOT NULL AUTO_INCREMENT,
  `stop_watch_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `threshold_index` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  FULLTEXT KEY `stop_watch_code` (`stop_watch_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_trigger_threshold`
--

LOCK TABLES `priv_trigger_threshold` WRITE;
/*!40000 ALTER TABLE `priv_trigger_threshold` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_trigger_threshold` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_urp_profiles`
--

DROP TABLE IF EXISTS `priv_urp_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_urp_profiles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95))
) ENGINE=InnoDB AUTO_INCREMENT=5324 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_urp_profiles`
--

LOCK TABLES `priv_urp_profiles` WRITE;
/*!40000 ALTER TABLE `priv_urp_profiles` DISABLE KEYS */;
INSERT INTO `priv_urp_profiles` VALUES (1,'Administrator','Has the rights on everything (bypassing any control)'),(2,'Portal user','Has the rights to access to the user portal. People having this profile will not be allowed to access the standard application, they will be automatically redirected to the user portal.'),(3,'Configuration Manager','Person in charge of the documentation of the managed CIs'),(4,'Service Desk Agent','Person in charge of creating incident reports'),(5,'Support Agent','Person analyzing and solving the current incidents'),(6,'Problem Manager','Person analyzing and solving the current problems'),(7,'Change Implementor','Person executing the changes'),(8,'Change Supervisor','Person responsible for the overall change execution'),(9,'Change Approver','Person who could be impacted by some changes'),(10,'Service Manager','Person responsible for the service delivered to the [internal] customer'),(11,'Document author','Any person who could contribute to documentation'),(12,'Portal power user','Users having this profile will have the rights to see all the tickets for a customer in the portal. Must be used in conjunction with other profiles (e.g. Portal User).'),(20,'Hostmaster','Person handling the IP space and looking after the IP changes'),(1024,'REST Services User','Only users having this profile are allowed to use the REST Web Services (unless \'secure_rest_services\' is set to false\n          in the configuration file).\n        '),(5323,'CMDB Guest','Person with read only rights (no bulk read allowed) on CMDB and IP objects (only)');
/*!40000 ALTER TABLE `priv_urp_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_urp_userorg`
--

DROP TABLE IF EXISTS `priv_urp_userorg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_urp_userorg` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userid` int DEFAULT '0',
  `allowed_org_id` int DEFAULT '0',
  `reason` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `allowed_org_id` (`allowed_org_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_urp_userorg`
--

LOCK TABLES `priv_urp_userorg` WRITE;
/*!40000 ALTER TABLE `priv_urp_userorg` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_urp_userorg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_urp_userprofile`
--

DROP TABLE IF EXISTS `priv_urp_userprofile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_urp_userprofile` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userid` int DEFAULT '0',
  `profileid` int DEFAULT '0',
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `profileid` (`profileid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_urp_userprofile`
--

LOCK TABLES `priv_urp_userprofile` WRITE;
/*!40000 ALTER TABLE `priv_urp_userprofile` DISABLE KEYS */;
INSERT INTO `priv_urp_userprofile` VALUES (1,1,1,'By definition, the administrator must have the administrator profile');
/*!40000 ALTER TABLE `priv_urp_userprofile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_user`
--

DROP TABLE IF EXISTS `priv_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `contactid` int DEFAULT '0',
  `login` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `language` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'EN US',
  `status` enum('enabled','disabled') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'enabled',
  `log` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `log_index` blob,
  `finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'User',
  PRIMARY KEY (`id`),
  KEY `contactid` (`contactid`),
  KEY `login` (`login`(95)),
  KEY `language` (`language`(95)),
  KEY `finalclass` (`finalclass`(95))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_user`
--

LOCK TABLES `priv_user` WRITE;
/*!40000 ALTER TABLE `priv_user` DISABLE KEYS */;
INSERT INTO `priv_user` VALUES (1,1,'admin','EN US','enabled','',_binary 'a:0:{}','UserLocal');
/*!40000 ALTER TABLE `priv_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_user_ldap`
--

DROP TABLE IF EXISTS `priv_user_ldap`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_user_ldap` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ldap_server` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_user_ldap`
--

LOCK TABLES `priv_user_ldap` WRITE;
/*!40000 ALTER TABLE `priv_user_ldap` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_user_ldap` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_user_local`
--

DROP TABLE IF EXISTS `priv_user_local`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_user_local` (
  `id` int NOT NULL AUTO_INCREMENT,
  `password_hash` tinyblob,
  `password_salt` tinyblob,
  `expiration` enum('can_expire','never_expire','force_expire','otp_expire') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'never_expire',
  `password_renewed_date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_user_local`
--

LOCK TABLES `priv_user_local` WRITE;
/*!40000 ALTER TABLE `priv_user_local` DISABLE KEYS */;
INSERT INTO `priv_user_local` VALUES (1,_binary '$2y$10$u19hcc9S1C8fqq4rn2X6A.VCzmUHAhcyWIGK9i4vmTTbCfyx9myr.','','never_expire','2024-09-22');
/*!40000 ALTER TABLE `priv_user_local` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_user_token`
--

DROP TABLE IF EXISTS `priv_user_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_user_token` (
  `id` int NOT NULL AUTO_INCREMENT,
  `auth_token_hash` tinyblob,
  `auth_token_salt` tinyblob,
  `scope` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  FULLTEXT KEY `scope` (`scope`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_user_token`
--

LOCK TABLES `priv_user_token` WRITE;
/*!40000 ALTER TABLE `priv_user_token` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_user_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_welcome_popup_acknowledge`
--

DROP TABLE IF EXISTS `priv_welcome_popup_acknowledge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_welcome_popup_acknowledge` (
  `id` int NOT NULL AUTO_INCREMENT,
  `message_uuid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `user_id` int DEFAULT '0',
  `acknowledge_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_welcome_popup_acknowledge`
--

LOCK TABLES `priv_welcome_popup_acknowledge` WRITE;
/*!40000 ALTER TABLE `priv_welcome_popup_acknowledge` DISABLE KEYS */;
INSERT INTO `priv_welcome_popup_acknowledge` VALUES (1,'Combodo\\iTop\\Application\\WelcomePopup\\Provider\\DefaultProvider::320_01_Welcome',1,'2024-09-10 00:38:47'),(2,'Combodo\\iTop\\Application\\WelcomePopup\\Provider\\DefaultProvider::320_02_Newsroom',1,'2024-09-10 00:38:49'),(3,'Combodo\\iTop\\Application\\WelcomePopup\\Provider\\DefaultProvider::320_03_NotificationsCenter',1,'2024-09-10 00:38:51'),(4,'Combodo\\iTop\\Application\\WelcomePopup\\Provider\\DefaultProvider::320_04_PowerfulNotifications_AdminOnly',1,'2024-09-10 00:38:53'),(5,'Combodo\\iTop\\Application\\WelcomePopup\\Provider\\DefaultProvider::320_05_A11yThemes',1,'2024-09-10 00:38:56');
/*!40000 ALTER TABLE `priv_welcome_popup_acknowledge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `providercontract`
--

DROP TABLE IF EXISTS `providercontract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `providercontract` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sla` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `coverage` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `providercontract`
--

LOCK TABLES `providercontract` WRITE;
/*!40000 ALTER TABLE `providercontract` DISABLE KEYS */;
/*!40000 ALTER TABLE `providercontract` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rack`
--

DROP TABLE IF EXISTS `rack`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rack` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nb_u` int DEFAULT NULL,
  `macaddress` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `ipaddress_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `ipaddress_id` (`ipaddress_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rack`
--

LOCK TABLES `rack` WRITE;
/*!40000 ALTER TABLE `rack` DISABLE KEYS */;
/*!40000 ALTER TABLE `rack` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `remoteapplicationconnection`
--

DROP TABLE IF EXISTS `remoteapplicationconnection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `remoteapplicationconnection` (
  `id` int NOT NULL AUTO_INCREMENT,
  `remoteapplicationtype_id` int DEFAULT '0',
  `environment` enum('1-development','2-test','3-production') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '2-test',
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'RemoteApplicationConnection',
  PRIMARY KEY (`id`),
  KEY `remoteapplicationtype_id` (`remoteapplicationtype_id`),
  KEY `finalclass` (`finalclass`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `remoteapplicationconnection`
--

LOCK TABLES `remoteapplicationconnection` WRITE;
/*!40000 ALTER TABLE `remoteapplicationconnection` DISABLE KEYS */;
/*!40000 ALTER TABLE `remoteapplicationconnection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `remoteapplicationtype`
--

DROP TABLE IF EXISTS `remoteapplicationtype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `remoteapplicationtype` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `remoteapplicationtype`
--

LOCK TABLES `remoteapplicationtype` WRITE;
/*!40000 ALTER TABLE `remoteapplicationtype` DISABLE KEYS */;
INSERT INTO `remoteapplicationtype` VALUES (1),(2),(3),(4),(5),(6);
/*!40000 ALTER TABLE `remoteapplicationtype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `remoteitopconnection`
--

DROP TABLE IF EXISTS `remoteitopconnection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `remoteitopconnection` (
  `id` int NOT NULL AUTO_INCREMENT,
  `auth_user` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `auth_pwd` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `version` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '1.3',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `remoteitopconnection`
--

LOCK TABLES `remoteitopconnection` WRITE;
/*!40000 ALTER TABLE `remoteitopconnection` DISABLE KEYS */;
/*!40000 ALTER TABLE `remoteitopconnection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `remoteitopconnectiontoken`
--

DROP TABLE IF EXISTS `remoteitopconnectiontoken`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `remoteitopconnectiontoken` (
  `id` int NOT NULL AUTO_INCREMENT,
  `version` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '1.3',
  `token` tinyblob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `remoteitopconnectiontoken`
--

LOCK TABLES `remoteitopconnectiontoken` WRITE;
/*!40000 ALTER TABLE `remoteitopconnectiontoken` DISABLE KEYS */;
/*!40000 ALTER TABLE `remoteitopconnectiontoken` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sanswitch`
--

DROP TABLE IF EXISTS `sanswitch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sanswitch` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sanswitch`
--

LOCK TABLES `sanswitch` WRITE;
/*!40000 ALTER TABLE `sanswitch` DISABLE KEYS */;
/*!40000 ALTER TABLE `sanswitch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `server`
--

DROP TABLE IF EXISTS `server`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `server` (
  `id` int NOT NULL AUTO_INCREMENT,
  `osfamily_id` int DEFAULT '0',
  `osversion_id` int DEFAULT '0',
  `oslicence_id` int DEFAULT '0',
  `cpu` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `ram` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `osfamily_id` (`osfamily_id`),
  KEY `osversion_id` (`osversion_id`),
  KEY `oslicence_id` (`oslicence_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `server`
--

LOCK TABLES `server` WRITE;
/*!40000 ALTER TABLE `server` DISABLE KEYS */;
INSERT INTO `server` VALUES (3,0,48,0,'',''),(19,28,35,0,'',''),(20,25,0,0,'',''),(21,24,0,0,'','');
/*!40000 ALTER TABLE `server` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service`
--

DROP TABLE IF EXISTS `service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `service` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `org_id` int DEFAULT '0',
  `servicefamily_id` int DEFAULT '0',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `status` enum('implementation','production','obsolete') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon_data` longblob,
  `icon_mimetype` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon_filename` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon_downloads_count` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95)),
  KEY `org_id` (`org_id`),
  KEY `servicefamily_id` (`servicefamily_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service`
--

LOCK TABLES `service` WRITE;
/*!40000 ALTER TABLE `service` DISABLE KEYS */;
/*!40000 ALTER TABLE `service` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `servicefamily`
--

DROP TABLE IF EXISTS `servicefamily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `servicefamily` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `icon_data` longblob,
  `icon_mimetype` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon_filename` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon_downloads_count` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `servicefamily`
--

LOCK TABLES `servicefamily` WRITE;
/*!40000 ALTER TABLE `servicefamily` DISABLE KEYS */;
/*!40000 ALTER TABLE `servicefamily` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `servicesubcategory`
--

DROP TABLE IF EXISTS `servicesubcategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `servicesubcategory` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `service_id` int DEFAULT '0',
  `request_type` enum('incident','service_request') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'incident',
  `status` enum('implementation','production','obsolete') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95)),
  KEY `service_id` (`service_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `servicesubcategory`
--

LOCK TABLES `servicesubcategory` WRITE;
/*!40000 ALTER TABLE `servicesubcategory` DISABLE KEYS */;
/*!40000 ALTER TABLE `servicesubcategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sla`
--

DROP TABLE IF EXISTS `sla`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sla` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `org_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95)),
  KEY `org_id` (`org_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sla`
--

LOCK TABLES `sla` WRITE;
/*!40000 ALTER TABLE `sla` DISABLE KEYS */;
/*!40000 ALTER TABLE `sla` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `slt`
--

DROP TABLE IF EXISTS `slt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `slt` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `priority` enum('1','2','3','4') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `request_type` enum('incident','service_request') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metric` enum('tto','ttr') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `value` int DEFAULT NULL,
  `unit` enum('hours','minutes') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `slt`
--

LOCK TABLES `slt` WRITE;
/*!40000 ALTER TABLE `slt` DISABLE KEYS */;
/*!40000 ALTER TABLE `slt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `software`
--

DROP TABLE IF EXISTS `software`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `software` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `vendor` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `version` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `type` enum('DBServer','Middleware','OtherSoftware','PCSoftware','WebServer') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95)),
  KEY `version` (`version`(95))
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `software`
--

LOCK TABLES `software` WRITE;
/*!40000 ALTER TABLE `software` DISABLE KEYS */;
INSERT INTO `software` VALUES (1,'Apache','Apache','2.0','WebServer'),(2,'Simple DNS Plus','UNKNOWN','UNKNOWN','Middleware'),(3,'Microsoft Windows Kerberos','UNKNOWN','UNKNOWN','Middleware'),(4,'Microsoft Windows RPC','UNKNOWN','UNKNOWN','Middleware'),(5,'Microsoft Windows netbios-ssn','UNKNOWN','UNKNOWN','Middleware'),(6,'Windows Active Directory LDAP','Microsoft','UNKNOWN','Middleware'),(7,'Windows Server 2019 Standard','Microsoft','17763','Middleware'),(8,'ssl/https','UNKNOWN','UNKNOWN','WebServer'),(9,'Apache httpd  ((Ubuntu) OpenSSL/3.0.13)','Apache','2.4.58','WebServer'),(10,'Microsoft IIS httpd','Microsoft','10.0','WebServer'),(11,'kpasswd5','Microsoft','5','Middleware'),(12,'Windows RPC over HTTP','Microsoft','1.0','Middleware'),(13,'Microsoft Terminal Services','Microsoft','UNKNOWN','Middleware'),(14,'Microsoft HTTPAPI','Microsoft','httpd 2.0','Middleware'),(15,'OpenSSH','Ubuntu','9.6p1','Middleware'),(16,'OpenLDAP','Linux','2.2.X - 2.3.X','Middleware'),(17,'CUPS','UNIX','2.4','Middleware'),(18,'Golang net/http server','UNKNOWN','UNKNOWN','WebServer'),(19,'Windows Server 2022 Standard','Microsoft','20348','Middleware'),(20,'Microsoft Windows 7 - 10 microsoft-ds','Microsoft','UNKNOWN','Middleware'),(21,'VNC','Microsoft','3.8','Middleware'),(22,'OpenSSH','Debian 5','9.7p1','Middleware'),(23,'xrdp','Linux','UNKNOWN','Middleware'),(24,'Microsoft Windows Server 2008','Microsoft','R2 - 2012','Middleware');
/*!40000 ALTER TABLE `software` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `softwareinstance`
--

DROP TABLE IF EXISTS `softwareinstance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `softwareinstance` (
  `id` int NOT NULL AUTO_INCREMENT,
  `functionalci_id` int DEFAULT '0',
  `software_id` int DEFAULT '0',
  `softwarelicence_id` int DEFAULT '0',
  `path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `status` enum('active','inactive') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'SoftwareInstance',
  PRIMARY KEY (`id`),
  KEY `functionalci_id` (`functionalci_id`),
  KEY `software_id` (`software_id`),
  KEY `softwarelicence_id` (`softwarelicence_id`),
  KEY `finalclass` (`finalclass`(95))
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `softwareinstance`
--

LOCK TABLES `softwareinstance` WRITE;
/*!40000 ALTER TABLE `softwareinstance` DISABLE KEYS */;
INSERT INTO `softwareinstance` VALUES (4,3,1,0,'','active','WebServer'),(24,20,1,0,'','active','WebServer'),(25,19,2,0,'','active','Middleware'),(26,19,3,0,'','active','Middleware'),(27,19,4,0,'','active','Middleware'),(28,19,5,0,'',NULL,'Middleware'),(29,19,6,0,'','active','Middleware'),(30,19,7,0,'','active','Middleware'),(31,21,8,0,'','active','WebServer'),(32,20,9,0,'','active','WebServer'),(33,22,10,0,'','active','WebServer'),(34,19,11,0,'','active','Middleware'),(35,19,12,0,'',NULL,'Middleware'),(36,19,13,0,'','active','Middleware'),(37,19,14,0,'',NULL,'Middleware'),(38,20,15,0,'','active','Middleware'),(39,20,16,0,'','active','Middleware'),(40,20,17,0,'','active','Middleware'),(41,20,18,0,'','active','WebServer'),(42,21,15,0,'','active','Middleware'),(43,22,4,0,'','active','Middleware'),(44,22,5,0,'','active','Middleware'),(45,22,19,0,'','active','Middleware'),(46,22,13,0,'',NULL,'Middleware'),(47,10,4,0,'','active','Middleware'),(48,10,5,0,'','active','Middleware'),(49,10,20,0,'','active','Middleware'),(50,10,13,0,'','active','Middleware'),(51,8,4,0,'','active','Middleware'),(52,8,5,0,'','active','Middleware'),(53,8,20,0,'','active','Middleware'),(54,10,21,0,'','active','Middleware'),(55,8,13,0,'','active','Middleware'),(56,8,21,0,'','active','Middleware'),(57,16,4,0,'','active','Middleware'),(58,16,5,0,'','active','Middleware'),(59,16,20,0,'','active','Middleware'),(60,16,20,0,'','active','Middleware'),(61,16,21,0,'','active','Middleware'),(62,15,4,0,'','active','Middleware'),(63,15,5,0,'','active','Middleware'),(64,15,20,0,'','active','Middleware'),(65,15,13,0,'','active','Middleware'),(66,15,21,0,'','active','Middleware'),(67,7,4,0,'','active','Middleware'),(68,7,5,0,'','active','Middleware'),(69,7,20,0,'','active','Middleware'),(70,7,13,0,'','active','Middleware'),(71,7,21,0,'','active','Middleware'),(72,12,4,0,'','active','Middleware'),(73,12,5,0,'','active','Middleware'),(74,12,20,0,'','active','Middleware'),(75,12,13,0,'','active','Middleware'),(76,12,21,0,'','active','Middleware'),(77,6,22,0,'',NULL,'Middleware'),(78,6,23,0,'','active','Middleware'),(79,13,4,0,'','active','Middleware'),(80,13,5,0,'','active','Middleware'),(81,13,5,0,'','active','Middleware'),(82,13,13,0,'',NULL,'Middleware'),(83,13,21,0,'','active','Middleware'),(84,9,4,0,'','active','Middleware'),(85,9,5,0,'','active','Middleware'),(86,9,5,0,'','active','Middleware'),(87,9,13,0,'','active','Middleware'),(88,9,21,0,'','active','Middleware'),(89,11,4,0,'','active','Middleware'),(90,11,5,0,'','active','Middleware'),(91,11,20,0,'','active','Middleware'),(92,11,13,0,'','active','Middleware'),(93,11,21,0,'','active','Middleware'),(94,5,4,0,'','active','Middleware'),(95,5,5,0,'','active','Middleware'),(96,5,24,0,'','active','Middleware'),(97,5,13,0,'','active','Middleware'),(98,14,4,0,'','active','Middleware'),(99,14,5,0,'','active','Middleware'),(100,14,13,0,'','active','Middleware'),(101,14,20,0,'','active','Middleware'),(102,14,21,0,'','active','Middleware');
/*!40000 ALTER TABLE `softwareinstance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `softwarelicence`
--

DROP TABLE IF EXISTS `softwarelicence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `softwarelicence` (
  `id` int NOT NULL AUTO_INCREMENT,
  `software_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `software_id` (`software_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `softwarelicence`
--

LOCK TABLES `softwarelicence` WRITE;
/*!40000 ALTER TABLE `softwarelicence` DISABLE KEYS */;
/*!40000 ALTER TABLE `softwarelicence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `softwarepatch`
--

DROP TABLE IF EXISTS `softwarepatch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `softwarepatch` (
  `id` int NOT NULL AUTO_INCREMENT,
  `software_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `software_id` (`software_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `softwarepatch`
--

LOCK TABLES `softwarepatch` WRITE;
/*!40000 ALTER TABLE `softwarepatch` DISABLE KEYS */;
/*!40000 ALTER TABLE `softwarepatch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `storagesystem`
--

DROP TABLE IF EXISTS `storagesystem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `storagesystem` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `storagesystem`
--

LOCK TABLES `storagesystem` WRITE;
/*!40000 ALTER TABLE `storagesystem` DISABLE KEYS */;
/*!40000 ALTER TABLE `storagesystem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subnet`
--

DROP TABLE IF EXISTS `subnet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subnet` (
  `id` int NOT NULL AUTO_INCREMENT,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `subnet_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `org_id` int DEFAULT '0',
  `ip` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `ip_mask` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`),
  KEY `ip` (`ip`(95)),
  KEY `ip_mask` (`ip_mask`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subnet`
--

LOCK TABLES `subnet` WRITE;
/*!40000 ALTER TABLE `subnet` DISABLE KEYS */;
/*!40000 ALTER TABLE `subnet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tablet`
--

DROP TABLE IF EXISTS `tablet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tablet` (
  `id` int NOT NULL AUTO_INCREMENT,
  `macaddress` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `ipaddress_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `ipaddress_id` (`ipaddress_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tablet`
--

LOCK TABLES `tablet` WRITE;
/*!40000 ALTER TABLE `tablet` DISABLE KEYS */;
/*!40000 ALTER TABLE `tablet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tape`
--

DROP TABLE IF EXISTS `tape`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tape` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `size` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `tapelibrary_id` int DEFAULT '0',
  `obsolescence_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95)),
  KEY `tapelibrary_id` (`tapelibrary_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tape`
--

LOCK TABLES `tape` WRITE;
/*!40000 ALTER TABLE `tape` DISABLE KEYS */;
/*!40000 ALTER TABLE `tape` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tapelibrary`
--

DROP TABLE IF EXISTS `tapelibrary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tapelibrary` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tapelibrary`
--

LOCK TABLES `tapelibrary` WRITE;
/*!40000 ALTER TABLE `tapelibrary` DISABLE KEYS */;
/*!40000 ALTER TABLE `tapelibrary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team`
--

DROP TABLE IF EXISTS `team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `team` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team`
--

LOCK TABLES `team` WRITE;
/*!40000 ALTER TABLE `team` DISABLE KEYS */;
/*!40000 ALTER TABLE `team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `telephonyci`
--

DROP TABLE IF EXISTS `telephonyci`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `telephonyci` (
  `id` int NOT NULL AUTO_INCREMENT,
  `phonenumber` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'TelephonyCI',
  PRIMARY KEY (`id`),
  KEY `finalclass` (`finalclass`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `telephonyci`
--

LOCK TABLES `telephonyci` WRITE;
/*!40000 ALTER TABLE `telephonyci` DISABLE KEYS */;
/*!40000 ALTER TABLE `telephonyci` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket`
--

DROP TABLE IF EXISTS `ticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ticket` (
  `id` int NOT NULL AUTO_INCREMENT,
  `operational_status` enum('closed','ongoing','resolved') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'ongoing',
  `ref` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `org_id` int DEFAULT '0',
  `caller_id` int DEFAULT '0',
  `team_id` int DEFAULT '0',
  `agent_id` int DEFAULT '0',
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `description_format` enum('text','html') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'text',
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `last_update` datetime DEFAULT NULL,
  `close_date` datetime DEFAULT NULL,
  `private_log` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `private_log_index` blob,
  `finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Ticket',
  PRIMARY KEY (`id`),
  KEY `operational_status` (`operational_status`),
  KEY `ref` (`ref`(95)),
  KEY `org_id` (`org_id`),
  KEY `caller_id` (`caller_id`),
  KEY `team_id` (`team_id`),
  KEY `agent_id` (`agent_id`),
  KEY `finalclass` (`finalclass`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket`
--

LOCK TABLES `ticket` WRITE;
/*!40000 ALTER TABLE `ticket` DISABLE KEYS */;
/*!40000 ALTER TABLE `ticket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket_change`
--

DROP TABLE IF EXISTS `ticket_change`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ticket_change` (
  `id` int NOT NULL AUTO_INCREMENT,
  `status` enum('new','rejected','assigned','planned','approved','closed') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'new',
  `category` enum('application','hardware','network','other','software','system') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'hardware',
  `reject_reason` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `changemanager_id` int DEFAULT '0',
  `parent_id` int DEFAULT '0',
  `creation_date` datetime DEFAULT NULL,
  `approval_date` datetime DEFAULT NULL,
  `fallback_plan` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `outage` enum('no','yes') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  PRIMARY KEY (`id`),
  KEY `changemanager_id` (`changemanager_id`),
  KEY `parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_change`
--

LOCK TABLES `ticket_change` WRITE;
/*!40000 ALTER TABLE `ticket_change` DISABLE KEYS */;
/*!40000 ALTER TABLE `ticket_change` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket_request`
--

DROP TABLE IF EXISTS `ticket_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ticket_request` (
  `id` int NOT NULL AUTO_INCREMENT,
  `status` enum('new','waiting_for_approval','approved','rejected','assigned','pending','escalated_tto','escalated_ttr','resolved','closed') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'new',
  `request_type` enum('incident','service_request') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `impact` enum('1','2','3') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '1',
  `priority` enum('1','2','3','4') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '4',
  `urgency` enum('1','2','3','4') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '4',
  `origin` enum('chat','in_person','mail','monitoring','phone','portal') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'phone',
  `approver_id` int DEFAULT '0',
  `service_id` int DEFAULT '0',
  `servicesubcategory_id` int DEFAULT '0',
  `escalation_flag` enum('no','yes') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `escalation_reason` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `assignment_date` datetime DEFAULT NULL,
  `resolution_date` datetime DEFAULT NULL,
  `last_pending_date` datetime DEFAULT NULL,
  `cumulatedpending_timespent` int unsigned DEFAULT NULL,
  `cumulatedpending_started` datetime DEFAULT NULL,
  `cumulatedpending_laststart` datetime DEFAULT NULL,
  `cumulatedpending_stopped` datetime DEFAULT NULL,
  `tto_timespent` int unsigned DEFAULT NULL,
  `tto_started` datetime DEFAULT NULL,
  `tto_laststart` datetime DEFAULT NULL,
  `tto_stopped` datetime DEFAULT NULL,
  `tto_75_deadline` datetime DEFAULT NULL,
  `tto_75_passed` tinyint unsigned DEFAULT NULL,
  `tto_75_triggered` tinyint(1) DEFAULT NULL,
  `tto_75_overrun` int unsigned DEFAULT NULL,
  `tto_100_deadline` datetime DEFAULT NULL,
  `tto_100_passed` tinyint unsigned DEFAULT NULL,
  `tto_100_triggered` tinyint(1) DEFAULT NULL,
  `tto_100_overrun` int unsigned DEFAULT NULL,
  `ttr_timespent` int unsigned DEFAULT NULL,
  `ttr_started` datetime DEFAULT NULL,
  `ttr_laststart` datetime DEFAULT NULL,
  `ttr_stopped` datetime DEFAULT NULL,
  `ttr_75_deadline` datetime DEFAULT NULL,
  `ttr_75_passed` tinyint unsigned DEFAULT NULL,
  `ttr_75_triggered` tinyint(1) DEFAULT NULL,
  `ttr_75_overrun` int unsigned DEFAULT NULL,
  `ttr_100_deadline` datetime DEFAULT NULL,
  `ttr_100_passed` tinyint unsigned DEFAULT NULL,
  `ttr_100_triggered` tinyint(1) DEFAULT NULL,
  `ttr_100_overrun` int unsigned DEFAULT NULL,
  `time_spent` int unsigned DEFAULT NULL,
  `resolution_code` enum('assistance','bug fixed','hardware repair','other','software patch','system update','training') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'assistance',
  `solution` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `solution_format` enum('text','html') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'text',
  `pending_reason` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `parent_request_id` int DEFAULT '0',
  `parent_change_id` int DEFAULT '0',
  `public_log` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `public_log_index` blob,
  `user_satisfaction` enum('1','2','3','4') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '1',
  `user_commment` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `approver_id` (`approver_id`),
  KEY `service_id` (`service_id`),
  KEY `servicesubcategory_id` (`servicesubcategory_id`),
  KEY `parent_request_id` (`parent_request_id`),
  KEY `parent_change_id` (`parent_change_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_request`
--

LOCK TABLES `ticket_request` WRITE;
/*!40000 ALTER TABLE `ticket_request` DISABLE KEYS */;
/*!40000 ALTER TABLE `ticket_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `typology`
--

DROP TABLE IF EXISTS `typology`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `typology` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Typology',
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95)),
  KEY `finalclass` (`finalclass`(95))
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `typology`
--

LOCK TABLES `typology` WRITE;
/*!40000 ALTER TABLE `typology` DISABLE KEYS */;
INSERT INTO `typology` VALUES (1,'iTop','RemoteApplicationType'),(2,'Slack','RemoteApplicationType'),(3,'Rocket.Chat','RemoteApplicationType'),(4,'Google Chat','RemoteApplicationType'),(5,'Microsoft Teams','RemoteApplicationType'),(6,'Other / Generic','RemoteApplicationType'),(7,'Acer','Brand'),(8,'Apple','Brand'),(9,'Asus','Brand'),(10,'Cisco','Brand'),(11,'Dell','Brand'),(12,'HP Inc','Brand'),(13,'HPE','Brand'),(14,'IBM','Brand'),(15,'Lenovo','Brand'),(16,'Razer','Brand'),(17,'Samsung','Brand'),(18,'Sony','Brand'),(19,'Toshiba','Brand'),(20,'Arch','OSFamily'),(21,'Debian','OSFamily'),(22,'Oracle Linux','OSFamily'),(23,'Red Hat','OSFamily'),(24,'Ubuntu','OSFamily'),(25,'Ubuntu server','OSFamily'),(26,'vCenter Server','OSFamily'),(27,'Windows','OSFamily'),(28,'Windows server','OSFamily'),(29,'10','OSVersion'),(30,'11','OSVersion'),(31,'11.5','OSVersion'),(32,'18.04 LTS','OSVersion'),(33,'20.04 LTS','OSVersion'),(34,'20.04 LTS','OSVersion'),(35,'2019','OSVersion'),(36,'2022','OSVersion'),(37,'22.04 LTS','OSVersion'),(38,'22.04 LTS','OSVersion'),(39,'6.7','OSVersion'),(40,'9','OSVersion'),(41,'9.1','OSVersion'),(42,'Roling release','OSVersion'),(43,'Network IP','IPUsage'),(44,'Gateway','IPUsage'),(45,'Broadcast','IPUsage'),(46,'Server_Network','IPBlockType'),(47,'Core_Switch','NetworkDeviceType'),(48,'Linux Ubuntu 22.04','OSVersion');
/*!40000 ALTER TABLE `typology` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `virtualdevice`
--

DROP TABLE IF EXISTS `virtualdevice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `virtualdevice` (
  `id` int NOT NULL AUTO_INCREMENT,
  `status` enum('stock','implementation','production','obsolete') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'production',
  `finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'VirtualDevice',
  PRIMARY KEY (`id`),
  KEY `finalclass` (`finalclass`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `virtualdevice`
--

LOCK TABLES `virtualdevice` WRITE;
/*!40000 ALTER TABLE `virtualdevice` DISABLE KEYS */;
/*!40000 ALTER TABLE `virtualdevice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `virtualhost`
--

DROP TABLE IF EXISTS `virtualhost`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `virtualhost` (
  `id` int NOT NULL AUTO_INCREMENT,
  `finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'VirtualHost',
  PRIMARY KEY (`id`),
  KEY `finalclass` (`finalclass`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `virtualhost`
--

LOCK TABLES `virtualhost` WRITE;
/*!40000 ALTER TABLE `virtualhost` DISABLE KEYS */;
/*!40000 ALTER TABLE `virtualhost` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `virtualmachine`
--

DROP TABLE IF EXISTS `virtualmachine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `virtualmachine` (
  `id` int NOT NULL AUTO_INCREMENT,
  `virtualhost_id` int DEFAULT '0',
  `osfamily_id` int DEFAULT '0',
  `osversion_id` int DEFAULT '0',
  `oslicence_id` int DEFAULT '0',
  `cpu` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `ram` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `managementip` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `managementip_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `virtualhost_id` (`virtualhost_id`),
  KEY `osfamily_id` (`osfamily_id`),
  KEY `osversion_id` (`osversion_id`),
  KEY `oslicence_id` (`oslicence_id`),
  KEY `managementip_id` (`managementip_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `virtualmachine`
--

LOCK TABLES `virtualmachine` WRITE;
/*!40000 ALTER TABLE `virtualmachine` DISABLE KEYS */;
/*!40000 ALTER TABLE `virtualmachine` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vlan`
--

DROP TABLE IF EXISTS `vlan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vlan` (
  `id` int NOT NULL AUTO_INCREMENT,
  `vlan_tag` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `org_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `vlan_tag` (`vlan_tag`(95)),
  KEY `org_id` (`org_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vlan`
--

LOCK TABLES `vlan` WRITE;
/*!40000 ALTER TABLE `vlan` DISABLE KEYS */;
/*!40000 ALTER TABLE `vlan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vrf`
--

DROP TABLE IF EXISTS `vrf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vrf` (
  `id` int NOT NULL AUTO_INCREMENT,
  `route_dist` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `route_trgt` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vrf`
--

LOCK TABLES `vrf` WRITE;
/*!40000 ALTER TABLE `vrf` DISABLE KEYS */;
/*!40000 ALTER TABLE `vrf` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wanlink`
--

DROP TABLE IF EXISTS `wanlink`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wanlink` (
  `id` int NOT NULL AUTO_INCREMENT,
  `status` enum('implementation','obsolete','production','stock') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'production',
  `location_id1` int DEFAULT '0',
  `location_id2` int DEFAULT '0',
  `type_id` int DEFAULT '0',
  `rate` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `burst_rate` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `underlying_rate` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `networkinterface_id1` int DEFAULT '0',
  `networkinterface_id2` int DEFAULT '0',
  `carrier_id` int DEFAULT '0',
  `carrier_ref` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `internal_reference` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `purchase_date` date DEFAULT NULL,
  `renewal_date` date DEFAULT NULL,
  `decommissioning_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `location_id1` (`location_id1`),
  KEY `location_id2` (`location_id2`),
  KEY `type_id` (`type_id`),
  KEY `networkinterface_id1` (`networkinterface_id1`),
  KEY `networkinterface_id2` (`networkinterface_id2`),
  KEY `carrier_id` (`carrier_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wanlink`
--

LOCK TABLES `wanlink` WRITE;
/*!40000 ALTER TABLE `wanlink` DISABLE KEYS */;
/*!40000 ALTER TABLE `wanlink` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wantype`
--

DROP TABLE IF EXISTS `wantype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wantype` (
  `id` int NOT NULL AUTO_INCREMENT,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wantype`
--

LOCK TABLES `wantype` WRITE;
/*!40000 ALTER TABLE `wantype` DISABLE KEYS */;
/*!40000 ALTER TABLE `wantype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webapplication`
--

DROP TABLE IF EXISTS `webapplication`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webapplication` (
  `id` int NOT NULL AUTO_INCREMENT,
  `webserver_id` int DEFAULT '0',
  `url` varchar(2048) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `webserver_id` (`webserver_id`)
) ENGINE=InnoDB AUTO_INCREMENT=110 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webapplication`
--

LOCK TABLES `webapplication` WRITE;
/*!40000 ALTER TABLE `webapplication` DISABLE KEYS */;
INSERT INTO `webapplication` VALUES (103,24,'https://observer.megaquagga.local/itop'),(104,24,'https://observer.megaquagga.local/zabbix'),(105,24,'https://observer.megaquagga.local/nagios'),(106,24,'https://observer.megaquagga.local:9090'),(107,24,'https://observer.megaquagga.local/icingaweb2'),(108,24,'https://observer.megaquagga.local:3000'),(109,31,'https://wazuh-siem.megaquagga.local');
/*!40000 ALTER TABLE `webapplication` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webserver`
--

DROP TABLE IF EXISTS `webserver`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webserver` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webserver`
--

LOCK TABLES `webserver` WRITE;
/*!40000 ALTER TABLE `webserver` DISABLE KEYS */;
INSERT INTO `webserver` VALUES (4),(24),(31),(32),(33),(41);
/*!40000 ALTER TABLE `webserver` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workorder`
--

DROP TABLE IF EXISTS `workorder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `workorder` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `status` enum('closed','open') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'open',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `ticket_id` int DEFAULT '0',
  `team_id` int DEFAULT '0',
  `owner_id` int DEFAULT '0',
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `log` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `log_index` blob,
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95)),
  KEY `ticket_id` (`ticket_id`),
  KEY `team_id` (`team_id`),
  KEY `owner_id` (`owner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workorder`
--

LOCK TABLES `workorder` WRITE;
/*!40000 ALTER TABLE `workorder` DISABLE KEYS */;
/*!40000 ALTER TABLE `workorder` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-03-22  0:28:38
